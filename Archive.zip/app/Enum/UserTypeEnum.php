<?php
namespace App\Enum;

class UserTypeEnum {
    const SYSTEM = 'system';
    const COMPANY = 'company';
    const CANDIDATE = 'candidate';
}