<?php

namespace App\Http\Middleware;

use Closure;
use App\Enum\UserTypeEnum;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class OwnerMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->user() || auth()->user()->user_type != UserTypeEnum::SYSTEM) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }
        return $next($request);
    }
}
