import { usePage } from "@inertiajs/vue3";
import { U as UserTypeEnum } from "./isSystemUser-D-zJOoLX.js";
const isCandidateUser = () => {
  const { auth } = usePage().props;
  if (!auth.user) {
    return false;
  }
  const userType = auth.user.user_type || "";
  return userType === UserTypeEnum.CANDIDATE;
};
export {
  isCandidateUser as i
};
