import { defineComponent, mergeProps, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { S as SectionTitle } from "./SectionTitle-qF5u6qV8.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { F as FormFilePicker } from "./FormFilePicker-BtfvB5iT.js";
import { usePage, useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./IconRounded-RF1xkXym.js";
import "./colors-K3EOgMMA.js";
import "./isSystemUser-D-zJOoLX.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PersonalInfo",
  __ssrInlineRender: true,
  setup(__props) {
    const personalInfo = usePage().props.personalInfo ?? null;
    const genderType = [
      { id: "", label: "Select Gender" },
      { id: "Male", label: "Male" },
      { id: "Female", label: "Female" },
      { id: "Other", label: "Other" }
    ];
    const maritalStatus = [
      { id: "", label: "Select Marital Status" },
      { id: "Single", label: "Single" },
      { id: "Maried", label: "Maried" },
      { id: "Divorced", label: "Divorced" },
      { id: "Widowed", label: "Widowed" }
    ];
    const religionStatus = [
      { id: "", label: "Select Religion" },
      { id: "Islam", label: "Islam" },
      { id: "Hindhu", label: "Hindhu" },
      { id: "Christian", label: "Christian" }
    ];
    const form = useForm({
      "id": 0,
      "user_id": usePage().props.auth.user.id,
      "father_name": "",
      "mother_name": "",
      "dob": "",
      "gender": genderType[0].id,
      "marital_status": maritalStatus[0].id,
      "nationality": "Bangladeshi",
      "religion": religionStatus[0].id,
      "present_address": "",
      "permanent_address": "",
      "alt_email": "",
      "phone": "",
      "image": "",
      _method: "post"
    });
    if (personalInfo) {
      form.id = personalInfo.id;
      form.father_name = personalInfo.father_name;
      form.mother_name = personalInfo.mother_name;
      form.dob = personalInfo.dob;
      form.gender = personalInfo.gender;
      form.marital_status = personalInfo.marital_status;
      form.nationality = personalInfo.nationality;
      form.religion = personalInfo.religion;
      form.present_address = personalInfo.present_address;
      form.permanent_address = personalInfo.permanent_address;
      form.alt_email = personalInfo.alt_email;
      form.phone = personalInfo.phone;
      form._method = "put";
    }
    const submit = () => {
      if (form.id == 0) {
        create();
      } else {
        update();
      }
    };
    const create = () => {
      form.transform((data) => ({
        ...data,
        terms: form.terms && form.terms.length
      })).post(route("resume.storePersonalInfo"));
    };
    const update = () => {
      form.transform((data) => ({
        ...data,
        terms: form.terms && form.terms.length
      })).post(route("resume.updatePersonalInfo", form.id));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(CardBox, mergeProps({
        class: "w-1/2",
        "is-form": "",
        onSubmit: submit
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(FormValidationErrors, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(FormSuccess, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionTitle, { title: "Personal Information" }, null, _parent2, _scopeId));
            if (unref(personalInfo) && unref(personalInfo).image) {
              _push2(`<div class="mb-10"${_scopeId}><img${ssrRenderAttr("src", unref(personalInfo).image)} width="300"${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex"${_scopeId}><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Father Name",
              "label-for": "father-name",
              help: "Please write your father name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).father_name,
                    "onUpdate:modelValue": ($event) => unref(form).father_name = $event,
                    id: "father-name",
                    icon: "fas fa-user",
                    type: "text",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).father_name,
                      "onUpdate:modelValue": ($event) => unref(form).father_name = $event,
                      id: "father-name",
                      icon: "fas fa-user",
                      type: "text",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Mother Name",
              "label-for": "mother-name",
              help: "Please write your mother name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).mother_name,
                    "onUpdate:modelValue": ($event) => unref(form).mother_name = $event,
                    id: "mother-name",
                    icon: "fas fa-user",
                    type: "text",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).mother_name,
                      "onUpdate:modelValue": ($event) => unref(form).mother_name = $event,
                      id: "mother-name",
                      icon: "fas fa-user",
                      type: "text",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="flex"${_scopeId}><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Date of Birth",
              "label-for": "dob",
              help: "Please write your date of birth"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).dob,
                    "onUpdate:modelValue": ($event) => unref(form).dob = $event,
                    id: "dob",
                    icon: "fas fa-user",
                    type: "date",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).dob,
                      "onUpdate:modelValue": ($event) => unref(form).dob = $event,
                      id: "dob",
                      icon: "fas fa-user",
                      type: "date",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, { label: "Gender" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).gender,
                    "onUpdate:modelValue": ($event) => unref(form).gender = $event,
                    icon: "fas fa-list",
                    options: genderType
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).gender,
                      "onUpdate:modelValue": ($event) => unref(form).gender = $event,
                      icon: "fas fa-list",
                      options: genderType
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="flex"${_scopeId}><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Marital Status",
              help: "Select your marital status."
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).marital_status,
                    "onUpdate:modelValue": ($event) => unref(form).marital_status = $event,
                    icon: "fas fa-list",
                    options: maritalStatus
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).marital_status,
                      "onUpdate:modelValue": ($event) => unref(form).marital_status = $event,
                      icon: "fas fa-list",
                      options: maritalStatus
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Nationality",
              "label-for": "nationality",
              help: "Please write your nationality"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).nationality,
                    "onUpdate:modelValue": ($event) => unref(form).nationality = $event,
                    id: "nationality",
                    icon: "fas fa-globe-asia",
                    type: "text",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).nationality,
                      "onUpdate:modelValue": ($event) => unref(form).nationality = $event,
                      id: "nationality",
                      icon: "fas fa-globe-asia",
                      type: "text",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="flex"${_scopeId}><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Religion",
              help: "Select your religion."
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).religion,
                    "onUpdate:modelValue": ($event) => unref(form).religion = $event,
                    icon: "fas fa-list",
                    options: religionStatus
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).religion,
                      "onUpdate:modelValue": ($event) => unref(form).religion = $event,
                      icon: "fas fa-list",
                      options: religionStatus
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Present Address",
              "label-for": "present-address",
              help: "Please enter your present address"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).present_address,
                    "onUpdate:modelValue": ($event) => unref(form).present_address = $event,
                    id: "present-address",
                    icon: "fas fa-map-marker",
                    autocomplete: "address",
                    type: "address",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).present_address,
                      "onUpdate:modelValue": ($event) => unref(form).present_address = $event,
                      id: "present-address",
                      icon: "fas fa-map-marker",
                      autocomplete: "address",
                      type: "address",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(FormField, {
              label: "Permanent Address",
              "label-for": "permanent-address",
              help: "Please enter your permanent address"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).permanent_address,
                    "onUpdate:modelValue": ($event) => unref(form).permanent_address = $event,
                    id: "permanent-address",
                    icon: "fas fa-map-marker",
                    autocomplete: "address",
                    type: "address",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).permanent_address,
                      "onUpdate:modelValue": ($event) => unref(form).permanent_address = $event,
                      id: "permanent-address",
                      icon: "fas fa-map-marker",
                      autocomplete: "address",
                      type: "address",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="flex"${_scopeId}><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Phone Number",
              "label-for": "phone",
              help: "Please enter your company phone"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).phone,
                    "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                    id: "phone",
                    icon: "fas fa-phone",
                    autocomplete: "phone",
                    type: "tel",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).phone,
                      "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                      id: "phone",
                      icon: "fas fa-phone",
                      autocomplete: "phone",
                      type: "tel",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="w-1/2 p-1"${_scopeId}>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Email",
              "label-for": "email",
              help: "Please enter your email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormControl, {
                    modelValue: unref(form).alt_email,
                    "onUpdate:modelValue": ($event) => unref(form).alt_email = $event,
                    id: "email",
                    icon: "fas fa-envelope",
                    autocomplete: "email",
                    type: "email",
                    required: ""
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormControl, {
                      modelValue: unref(form).alt_email,
                      "onUpdate:modelValue": ($event) => unref(form).alt_email = $event,
                      id: "email",
                      icon: "fas fa-envelope",
                      autocomplete: "email",
                      type: "email",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(FormField, {
              label: "Photo",
              help: "Max 500kb"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(FormFilePicker, {
                    label: "Upload Photo",
                    color: "success",
                    "onUpdate:modelValue": ($event) => unref(form).image = $event
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(FormFilePicker, {
                      label: "Upload Photo",
                      color: "success",
                      "onUpdate:modelValue": ($event) => unref(form).image = $event
                    }, null, 8, ["onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(BaseDivider, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(BaseButtons, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(BaseButtonLink, {
                    type: "submit",
                    color: "info",
                    label: "Save",
                    class: { "opacity-25": unref(form).processing },
                    disabled: unref(form).processing
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(BaseButtonLink, {
                      type: "submit",
                      color: "info",
                      label: "Save",
                      class: { "opacity-25": unref(form).processing },
                      disabled: unref(form).processing
                    }, null, 8, ["class", "disabled"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(FormValidationErrors),
              createVNode(FormSuccess),
              createVNode(SectionTitle, { title: "Personal Information" }),
              unref(personalInfo) && unref(personalInfo).image ? (openBlock(), createBlock("div", {
                key: 0,
                class: "mb-10"
              }, [
                createVNode("img", {
                  src: unref(personalInfo).image,
                  width: "300"
                }, null, 8, ["src"])
              ])) : createCommentVNode("", true),
              createVNode("div", { class: "flex" }, [
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Father Name",
                    "label-for": "father-name",
                    help: "Please write your father name"
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).father_name,
                        "onUpdate:modelValue": ($event) => unref(form).father_name = $event,
                        id: "father-name",
                        icon: "fas fa-user",
                        type: "text",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Mother Name",
                    "label-for": "mother-name",
                    help: "Please write your mother name"
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).mother_name,
                        "onUpdate:modelValue": ($event) => unref(form).mother_name = $event,
                        id: "mother-name",
                        icon: "fas fa-user",
                        type: "text",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ])
              ]),
              createVNode("div", { class: "flex" }, [
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Date of Birth",
                    "label-for": "dob",
                    help: "Please write your date of birth"
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).dob,
                        "onUpdate:modelValue": ($event) => unref(form).dob = $event,
                        id: "dob",
                        icon: "fas fa-user",
                        type: "date",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, { label: "Gender" }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).gender,
                        "onUpdate:modelValue": ($event) => unref(form).gender = $event,
                        icon: "fas fa-list",
                        options: genderType
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ])
              ]),
              createVNode("div", { class: "flex" }, [
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Marital Status",
                    help: "Select your marital status."
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).marital_status,
                        "onUpdate:modelValue": ($event) => unref(form).marital_status = $event,
                        icon: "fas fa-list",
                        options: maritalStatus
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Nationality",
                    "label-for": "nationality",
                    help: "Please write your nationality"
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).nationality,
                        "onUpdate:modelValue": ($event) => unref(form).nationality = $event,
                        id: "nationality",
                        icon: "fas fa-globe-asia",
                        type: "text",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ])
              ]),
              createVNode("div", { class: "flex" }, [
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Religion",
                    help: "Select your religion."
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).religion,
                        "onUpdate:modelValue": ($event) => unref(form).religion = $event,
                        icon: "fas fa-list",
                        options: religionStatus
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ])
              ]),
              createVNode(FormField, {
                label: "Present Address",
                "label-for": "present-address",
                help: "Please enter your present address"
              }, {
                default: withCtx(() => [
                  createVNode(FormControl, {
                    modelValue: unref(form).present_address,
                    "onUpdate:modelValue": ($event) => unref(form).present_address = $event,
                    id: "present-address",
                    icon: "fas fa-map-marker",
                    autocomplete: "address",
                    type: "address",
                    required: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                _: 1
              }),
              createVNode(FormField, {
                label: "Permanent Address",
                "label-for": "permanent-address",
                help: "Please enter your permanent address"
              }, {
                default: withCtx(() => [
                  createVNode(FormControl, {
                    modelValue: unref(form).permanent_address,
                    "onUpdate:modelValue": ($event) => unref(form).permanent_address = $event,
                    id: "permanent-address",
                    icon: "fas fa-map-marker",
                    autocomplete: "address",
                    type: "address",
                    required: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                _: 1
              }),
              createVNode("div", { class: "flex" }, [
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Phone Number",
                    "label-for": "phone",
                    help: "Please enter your company phone"
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).phone,
                        "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                        id: "phone",
                        icon: "fas fa-phone",
                        autocomplete: "phone",
                        type: "tel",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                createVNode("div", { class: "w-1/2 p-1" }, [
                  createVNode(FormField, {
                    label: "Email",
                    "label-for": "email",
                    help: "Please enter your email"
                  }, {
                    default: withCtx(() => [
                      createVNode(FormControl, {
                        modelValue: unref(form).alt_email,
                        "onUpdate:modelValue": ($event) => unref(form).alt_email = $event,
                        id: "email",
                        icon: "fas fa-envelope",
                        autocomplete: "email",
                        type: "email",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ])
              ]),
              createVNode(FormField, {
                label: "Photo",
                help: "Max 500kb"
              }, {
                default: withCtx(() => [
                  createVNode(FormFilePicker, {
                    label: "Upload Photo",
                    color: "success",
                    "onUpdate:modelValue": ($event) => unref(form).image = $event
                  }, null, 8, ["onUpdate:modelValue"])
                ]),
                _: 1
              }),
              createVNode(BaseDivider),
              createVNode(BaseButtons, null, {
                default: withCtx(() => [
                  createVNode(BaseButtonLink, {
                    type: "submit",
                    color: "info",
                    label: "Save",
                    class: { "opacity-25": unref(form).processing },
                    disabled: unref(form).processing
                  }, null, 8, ["class", "disabled"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Resume/Tabs/PersonalInfo.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
