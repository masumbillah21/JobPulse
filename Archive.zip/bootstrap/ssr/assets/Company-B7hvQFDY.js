import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { P as Pagination } from "./Pagination-BiZgXXz6.js";
import { usePage, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$4 } from "./JobSection--NNnfjnx.js";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./FormField-ePZgxXzs.js";
import "./FormControl-DwHkIb1m.js";
import "./main-C5vGb8af.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Company",
  __ssrInlineRender: true,
  props: {
    storageUrl: String
  },
  setup(__props) {
    const jobsData = usePage().props.jobsData;
    const companyData = usePage().props.companyData;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(companyData).name
            }, null, _parent2, _scopeId));
            if (unref(jobsData)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                bgImage: unref(companyData).logo,
                backgroundSize: "contain"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: unref(companyData).name
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: unref(companyData).name
                      }, null, 8, ["title"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<section class="pb-20 bg-gray-100"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="flex flex-wrap"${_scopeId}><div class="lg:pt-12 pt-6 w-full px-4"${_scopeId}><div class="w-full lg:w-6/12 px-4 ml-auto mr-auto text-center text-slate-800 mb-5"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                title: unref(companyData).name
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="relative flex flex-col min-w-0 break-words bg-white text-slate-900 w-full mb-8 py-10 px-3 shadow-lg rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$4, {
                jobList: unref(jobsData).data,
                allJobs: unref(jobsData).data,
                displayTotal: 10
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(Pagination, {
                class: "mt-6 text-white",
                links: (_a = unref(jobsData)) == null ? void 0 : _a.links
              }, null, _parent2, _scopeId));
              _push2(`</div></div></div></div></section></main>`);
            } else {
              _push2(`<main class="mt-40"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="items-center justify-center flex flex-wrap"${_scopeId}><div class="w-full ml-auto mr-auto px-4"${_scopeId}><h3 class="text-4xl font-semibold"${_scopeId}>Coming Soon</h3></div></div></div></main>`);
            }
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(companyData).name
              }, null, 8, ["title"]),
              unref(jobsData) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, {
                  bgImage: unref(companyData).logo,
                  backgroundSize: "contain"
                }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$3, {
                      title: unref(companyData).name
                    }, null, 8, ["title"])
                  ]),
                  _: 1
                }, 8, ["bgImage"]),
                createVNode("section", { class: "pb-20 bg-gray-100" }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "flex flex-wrap" }, [
                      createVNode("div", { class: "lg:pt-12 pt-6 w-full px-4" }, [
                        createVNode("div", { class: "w-full lg:w-6/12 px-4 ml-auto mr-auto text-center text-slate-800 mb-5" }, [
                          createVNode(_sfc_main$3, {
                            title: unref(companyData).name
                          }, null, 8, ["title"])
                        ]),
                        createVNode("div", { class: "relative flex flex-col min-w-0 break-words bg-white text-slate-900 w-full mb-8 py-10 px-3 shadow-lg rounded-lg" }, [
                          createVNode(_sfc_main$4, {
                            jobList: unref(jobsData).data,
                            allJobs: unref(jobsData).data,
                            displayTotal: 10
                          }, null, 8, ["jobList", "allJobs"]),
                          createVNode(Pagination, {
                            class: "mt-6 text-white",
                            links: (_b = unref(jobsData)) == null ? void 0 : _b.links
                          }, null, 8, ["links"])
                        ])
                      ])
                    ])
                  ])
                ])
              ])) : (openBlock(), createBlock("main", {
                key: 1,
                class: "mt-40"
              }, [
                createVNode("div", { class: "container mx-auto px-4" }, [
                  createVNode("div", { class: "items-center justify-center flex flex-wrap" }, [
                    createVNode("div", { class: "w-full ml-auto mr-auto px-4" }, [
                      createVNode("h3", { class: "text-4xl font-semibold" }, "Coming Soon")
                    ])
                  ])
                ])
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Job/Company.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
