import { mergeProps, unref, useSSRContext, computed, withCtx, renderSlot, ref, onMounted, onBeforeUnmount, createVNode, resolveDynamicComponent, openBlock, createBlock, createCommentVNode, toDisplayString, createTextVNode, useSlots, defineComponent, withModifiers } from "vue";
import { ssrRenderAttrs, ssrRenderSlot, ssrRenderAttr, ssrRenderComponent, ssrRenderVNode, ssrRenderClass, ssrInterpolate, ssrRenderList, ssrRenderSlotInner, ssrRenderStyle } from "vue/server-renderer";
import { usePage, Link, router } from "@inertiajs/vue3";
import { u as useDarkModeStore } from "./darkMode-Dj6n3w0i.js";
import { _ as _sfc_main$g } from "./BaseIcon-C4zrUKd9.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { g as getButtonColor, c as colorsOutline, a as colorsBgLight } from "./colors-K3EOgMMA.js";
import { _ as _sfc_main$h } from "./ApplicationLogo-DFQaU58l.js";
import { _ as _sfc_main$i } from "./BaseLevel-D_z-LHoc.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { i as isSystemUser } from "./isSystemUser-D-zJOoLX.js";
const containerMaxW = "xl:max-w-screen xl:mx-auto";
const _sfc_main$f = {
  __name: "SectionMain",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: ["p-6", unref(containerMaxW)]
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</section>`);
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/SectionMain.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const SectionMain = _sfc_main$f;
const menuNavBar = [
  {
    isCurrentUser: true,
    menu: [
      {
        icon: "fas fa-user",
        label: "My Profile",
        route: "profile.edit"
      },
      {
        isDivider: true
      },
      {
        icon: "fas fa-sign-out-alt",
        label: "Log Out",
        isLogout: true
      }
    ]
  },
  {
    icon: "fas fa-globe",
    label: "Site",
    isDesktopNoLabel: true,
    isSite: true
  },
  {
    icon: "fas fa-sync-alt",
    label: "Cache",
    isDesktopNoLabel: true,
    isCache: true
  },
  {
    icon: "fas fa-sun",
    label: "Light/Dark",
    isDesktopNoLabel: true,
    isToggleLightDark: true
  }
];
const menuNavBarAdmin = [
  {
    isCurrentUser: true,
    menu: [
      {
        icon: "fas fa-user",
        label: "My Profile",
        route: "admin.profile.edit"
      },
      {
        label: "Settings",
        icon: "fas fa-cogs",
        route: "admin.settings.index",
        permission: "settings.view"
      },
      {
        isDivider: true
      },
      {
        icon: "fas fa-sign-out-alt",
        label: "Log Out",
        isLogout: true
      }
    ]
  },
  {
    icon: "fas fa-globe",
    label: "Site",
    isDesktopNoLabel: true,
    isSite: true
  },
  {
    icon: "fas fa-sync-alt",
    label: "Cache",
    isDesktopNoLabel: true,
    isCache: true
  },
  {
    icon: "fas fa-sun",
    label: "Light/Dark",
    isDesktopNoLabel: true,
    isToggleLightDark: true
  }
];
const menuAside = [
  {
    label: "Dashboard",
    icon: "fas fa-desktop",
    route: "dashboard",
    permission: "dashboard.view",
    is_plugin: false
  },
  {
    label: "Employees",
    icon: "fas fa-users",
    permission: "employee.view",
    is_plugin: true,
    plugin_id: 2,
    menu: [
      {
        route: "employee.index",
        icon: "fas fa-users",
        label: "All Employees",
        permission: "employee.view"
      },
      {
        route: "employee.create",
        icon: "fas fa-plus",
        label: "Add Employee",
        permission: "employee.create"
      }
    ]
  },
  {
    label: "Company Profile",
    icon: "fas fa-building",
    route: "company.create",
    permission: "company.create",
    is_plugin: false
  },
  {
    label: "Resume",
    icon: "fas fa-file",
    route: "resume.index",
    permission: "resume.view",
    is_plugin: false
  },
  {
    label: "Jobs",
    icon: "fas fa-sliders-h",
    permission: "jobs.view",
    is_plugin: false,
    menu: [
      {
        route: "jobs.index",
        icon: "fas fa-sliders-h",
        label: "All Jobs",
        permission: "jobs.view"
      },
      {
        route: "jobs.create",
        icon: "fas fa-plus",
        label: "Add Job",
        permission: "jobs.create"
      }
    ]
  },
  {
    label: "Blogs",
    icon: "fas fa-folder",
    permission: "blogs.view",
    is_plugin: true,
    plugin_id: 1,
    menu: [
      {
        route: "blogs.index",
        icon: "fas fa-folder",
        label: "All Blogs",
        permission: "blogs.view"
      },
      {
        route: "blogs.create",
        icon: "fas fa-plus",
        label: "Add Blog",
        permission: "blogs.create"
      }
    ]
  },
  {
    label: "Candidates",
    icon: "fas fa-users",
    route: "jobs.cadidates.list",
    permission: "candidate.view.list",
    is_plugin: false
  },
  {
    label: "Applications",
    icon: "fas fa-users",
    route: "jobs.applications.list",
    permission: "application.view.list",
    is_plugin: false
  },
  {
    label: "Plugins",
    icon: "fas fa-building",
    route: "plugins.index",
    permission: "plugin.view",
    is_plugin: false
  }
];
const menuAsideAdmin = [
  {
    label: "Dashboard",
    icon: "fas fa-desktop",
    route: "admin.dashboard",
    permission: "dashboard.view",
    is_plugin: false
  },
  {
    label: "Employees",
    icon: "fas fa-users",
    permission: "employee.view",
    is_plugin: true,
    plugin_id: 2,
    menu: [
      {
        route: "admin.employee.index",
        icon: "fas fa-users",
        label: "All Employees",
        permission: "employee.view"
      },
      {
        route: "admin.employee.create",
        icon: "fas fa-plus",
        label: "Add Employee",
        permission: "employee.create"
      }
    ]
  },
  {
    label: "Company Profile",
    icon: "fas fa-building",
    route: "admin.company.create",
    permission: "company.create",
    is_plugin: false
  },
  {
    label: "Company List",
    icon: "fas fa-building",
    route: "admin.company.index",
    permission: "company.view",
    is_plugin: false
  },
  {
    label: "User List",
    icon: "fas fa-users",
    route: "admin.users.list",
    permission: "users.list.view",
    is_plugin: false
  },
  {
    label: "Roles",
    icon: "fas fa-users-cog",
    permission: "role.view",
    is_plugin: false,
    menu: [
      {
        route: "admin.roles.index",
        icon: "fas fa-users-cog",
        label: "All Roles",
        permission: "role.view"
      },
      {
        route: "admin.roles.create",
        icon: "fas fa-plus",
        label: "Add Role",
        permission: "role.create"
      }
    ]
  },
  {
    label: "Permissions",
    icon: "fas fa-key",
    permission: "permissions.view",
    is_plugin: false,
    menu: [
      {
        route: "admin.permissions.index",
        icon: "fas fa-key",
        label: "All Permissions",
        permission: "permissions.view"
      },
      {
        route: "admin.permissions.create",
        icon: "fas fa-plus",
        label: "Add Permission",
        permission: "permissions.view"
      }
    ]
  },
  {
    label: "Resume",
    icon: "fas fa-file",
    route: "admin.resume.index",
    permission: "resume.view",
    is_plugin: false
  },
  {
    label: "Jobs",
    icon: "fas fa-sliders-h",
    permission: "jobs.view",
    is_plugin: false,
    menu: [
      {
        route: "admin.jobs.index",
        icon: "fas fa-sliders-h",
        label: "All Jobs",
        permission: "jobs.view"
      },
      {
        route: "admin.jobs.create",
        icon: "fas fa-plus",
        label: "Add Job",
        permission: "jobs.create"
      }
    ]
  },
  {
    label: "Jobs List",
    icon: "fas fa-sliders-h",
    permission: "jobs.view.list",
    is_plugin: false,
    menu: [
      {
        route: "admin.jobs.list",
        icon: "fas fa-list",
        label: "Job Lists",
        permission: "jobs.view.list"
      },
      {
        route: "admin.jobs.categories.index",
        icon: "fas fa-list",
        label: "Job Categories",
        permission: "job.categories.view"
      }
    ]
  },
  {
    label: "Candidates",
    icon: "fas fa-users",
    route: "admin.jobs.cadidates.list",
    permission: "candidate.view.list",
    is_plugin: false
  },
  {
    label: "Applications",
    icon: "fas fa-users",
    route: "admin.jobs.applications.list",
    permission: "application.view.list",
    is_plugin: false
  },
  {
    label: "Pages",
    icon: "fas fa-folder",
    permission: "pages.view",
    is_plugin: false,
    menu: [
      {
        route: "admin.pages.index",
        icon: "fas fa-folder",
        label: "All Pages",
        permission: "pages.view"
      },
      {
        route: "admin.pages.create",
        icon: "fas fa-plus",
        label: "Add Page",
        permission: "pages.create"
      }
    ]
  },
  {
    label: "Blogs",
    icon: "fas fa-folder",
    permission: "blogs.view",
    is_plugin: true,
    plugin_id: 1,
    menu: [
      {
        route: "admin.blogs.index",
        icon: "fas fa-folder",
        label: "All Blogs",
        permission: "blogs.view"
      },
      {
        route: "admin.blogs.create",
        icon: "fas fa-plus",
        label: "Add Blog",
        permission: "blogs.create"
      },
      {
        route: "admin.categories.index",
        icon: "fas fa-list",
        label: "Categories",
        permission: "categories.view"
      },
      {
        route: "admin.tags.index",
        icon: "fas fa-list",
        label: "Tags",
        permission: "tags.view"
      }
    ]
  },
  {
    label: "Plugins",
    icon: "fas fa-folder",
    permission: "plugin.view",
    is_plugin: false,
    menu: [
      {
        label: "All Plugins",
        icon: "fas fa-building",
        route: "admin.plugins.index",
        permission: "plugin.view"
      },
      {
        route: "admin.plugins.create",
        icon: "fas fa-plus",
        label: "Add Plugin",
        permission: "plugin.create",
        plugin: "0"
      }
    ]
  }
];
const _sfc_main$e = {
  __name: "UserAvatar",
  __ssrInlineRender: true,
  props: {
    username: {
      type: String,
      required: true
    },
    avatar: {
      type: String,
      default: null
    },
    api: {
      type: String,
      default: "avataaars"
    }
  },
  setup(__props) {
    const props = __props;
    const avatar = computed(
      () => props.avatar ?? `https://api.dicebear.com/7.x/${props.api}/svg?seed=${props.username.replace(
        /[^a-z0-9]+/gi,
        "-"
      )}.svg`
    );
    const username = computed(() => props.username);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><img${ssrRenderAttr("src", avatar.value)}${ssrRenderAttr("alt", username.value)} class="rounded-full block h-auto w-full max-w-full bg-gray-100 dark:bg-slate-800">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/UserAvatar.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const _sfc_main$d = {
  __name: "UserAvatarCurrentUser",
  __ssrInlineRender: true,
  setup(__props) {
    const userName = computed(() => usePage().props.auth.user.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$e, mergeProps({
        username: userName.value,
        api: "initials"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
          } else {
            return [
              renderSlot(_ctx.$slots, "default")
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/UserAvatarCurrentUser.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const _sfc_main$c = {
  __name: "NavBarItem",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      required: true
    }
  },
  emits: ["menu-click"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const itemHref = computed(() => props.item.route ? route(props.item.route) : props.item.href);
    const is = computed(() => {
      if (props.item.href) {
        return "a";
      }
      if (props.item.route) {
        return Link;
      }
      return "div";
    });
    const componentClass = computed(() => {
      const base = [
        isDropdownActive.value ? `navbar-item-label-active dark:text-slate-400` : `navbar-item-label dark:text-white dark:hover:text-slate-400`,
        props.item.menu ? "lg:py-2 lg:px-3" : "py-2 px-3"
      ];
      if (props.item.isDesktopNoLabel) {
        base.push("lg:w-16", "lg:justify-center");
      }
      return base;
    });
    const itemLabel = computed(
      () => props.item.isCurrentUser ? usePage().props.auth.user.name : props.item.label
    );
    const isDropdownActive = ref(false);
    const menuClick = (event) => {
      emit("menu-click", event, props.item);
      if (props.item.menu) {
        isDropdownActive.value = !isDropdownActive.value;
      }
    };
    const menuClickDropdown = (event, item) => {
      emit("menu-click", event, item);
    };
    const root = ref(null);
    const forceClose = (event) => {
      if (root.value && !root.value.contains(event.target)) {
        isDropdownActive.value = false;
      }
    };
    onMounted(() => {
      if (props.item.menu) {
        window.addEventListener("click", forceClose);
      }
    });
    onBeforeUnmount(() => {
      if (props.item.menu) {
        window.removeEventListener("click", forceClose);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.item.isDivider) {
        _push(ssrRenderComponent(BaseDivider, mergeProps({ "nav-bar": "" }, _attrs), null, _parent));
      } else {
        ssrRenderVNode(_push, createVNode(resolveDynamicComponent(is.value), mergeProps({
          ref_key: "root",
          ref: root,
          class: ["block lg:flex items-center relative cursor-pointer", componentClass.value],
          href: itemHref.value,
          target: __props.item.target ?? null,
          onClick: menuClick
        }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="${ssrRenderClass([{
                "bg-gray-100 dark:bg-slate-800 lg:bg-transparent lg:dark:bg-transparent p-3 lg:p-0": __props.item.menu
              }, "flex items-center"])}"${_scopeId}>`);
              if (__props.item.isCurrentUser) {
                _push2(ssrRenderComponent(_sfc_main$d, { class: "w-6 h-6 mr-3 inline-flex" }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              if (__props.item.icon) {
                _push2(ssrRenderComponent(_sfc_main$g, {
                  path: __props.item.icon,
                  class: "transition-colors dark:text-white"
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`<span class="${ssrRenderClass([{ "lg:hidden": __props.item.isDesktopNoLabel && __props.item.icon }, "px-2 transition-colors dark:text-white"])}"${_scopeId}>${ssrInterpolate(itemLabel.value)}</span>`);
              if (__props.item.menu) {
                _push2(ssrRenderComponent(_sfc_main$g, {
                  path: isDropdownActive.value ? "fas fa-chevron-up" : "fas fa-chevron-down",
                  class: "hidden lg:inline-flex transition-colors dark:text-white"
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
              if (__props.item.menu) {
                _push2(`<div class="${ssrRenderClass([{ "lg:hidden": !isDropdownActive.value }, "text-sm border-b border-gray-100 lg:border lg:bg-white lg:absolute lg:top-full lg:left-0 lg:min-w-full lg:z-20 lg:rounded-lg lg:shadow-lg lg:dark:bg-slate-800 dark:border-slate-700"])}"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$b, {
                  menu: __props.item.menu,
                  onMenuClick: menuClickDropdown
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("div", {
                  class: ["flex items-center", {
                    "bg-gray-100 dark:bg-slate-800 lg:bg-transparent lg:dark:bg-transparent p-3 lg:p-0": __props.item.menu
                  }]
                }, [
                  __props.item.isCurrentUser ? (openBlock(), createBlock(_sfc_main$d, {
                    key: 0,
                    class: "w-6 h-6 mr-3 inline-flex"
                  })) : createCommentVNode("", true),
                  __props.item.icon ? (openBlock(), createBlock(_sfc_main$g, {
                    key: 1,
                    path: __props.item.icon,
                    class: "transition-colors dark:text-white"
                  }, null, 8, ["path"])) : createCommentVNode("", true),
                  createVNode("span", {
                    class: ["px-2 transition-colors dark:text-white", { "lg:hidden": __props.item.isDesktopNoLabel && __props.item.icon }]
                  }, toDisplayString(itemLabel.value), 3),
                  __props.item.menu ? (openBlock(), createBlock(_sfc_main$g, {
                    key: 2,
                    path: isDropdownActive.value ? "fas fa-chevron-up" : "fas fa-chevron-down",
                    class: "hidden lg:inline-flex transition-colors dark:text-white"
                  }, null, 8, ["path"])) : createCommentVNode("", true)
                ], 2),
                __props.item.menu ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: ["text-sm border-b border-gray-100 lg:border lg:bg-white lg:absolute lg:top-full lg:left-0 lg:min-w-full lg:z-20 lg:rounded-lg lg:shadow-lg lg:dark:bg-slate-800 dark:border-slate-700", { "lg:hidden": !isDropdownActive.value }]
                }, [
                  createVNode(_sfc_main$b, {
                    menu: __props.item.menu,
                    onMenuClick: menuClickDropdown
                  }, null, 8, ["menu"])
                ], 2)) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }), _parent);
      }
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NavBarItem.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const _sfc_main$b = {
  __name: "NavBarMenuList",
  __ssrInlineRender: true,
  props: {
    menu: {
      type: Array,
      default: () => []
    }
  },
  emits: ["menu-click"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const menuClick = (event, item) => {
      emit("menu-click", event, item);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      ssrRenderList(__props.menu, (item, index) => {
        _push(ssrRenderComponent(_sfc_main$c, {
          key: index,
          item,
          onMenuClick: menuClick
        }, null, _parent));
      });
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NavBarMenuList.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const _sfc_main$a = {
  __name: "NavBarItemPlain",
  __ssrInlineRender: true,
  props: {
    display: {
      type: String,
      default: "flex"
    },
    useMargin: Boolean
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: [[__props.display, __props.useMargin ? "my-2 mx-3" : "py-2 px-3"], "navbar-item-label items-center cursor-pointer dark:text-white dark:hover:text-slate-400"]
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NavBarItemPlain.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const _sfc_main$9 = {
  __name: "NavBar",
  __ssrInlineRender: true,
  props: {
    menu: {
      type: Array,
      required: true
    }
  },
  emits: ["menu-click"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const menuClick = (event, item) => {
      emit("menu-click", event, item);
    };
    const isMenuNavBarActive = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "top-0 inset-x-0 fixed bg-gray-50 h-14 z-30 transition-position w-screen lg:w-auto dark:bg-slate-800" }, _attrs))}><div class="${ssrRenderClass([unref(containerMaxW), "flex lg:items-stretch"])}"><div class="flex flex-1 items-stretch h-14">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div><div class="flex-none items-stretch flex h-14 lg:hidden">`);
      _push(ssrRenderComponent(_sfc_main$a, {
        onClick: ($event) => isMenuNavBarActive.value = !isMenuNavBarActive.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$g, {
              path: isMenuNavBarActive.value ? "fas fa-times" : "fas fa-ellipsis-v",
              size: "24"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$g, {
                path: isMenuNavBarActive.value ? "fas fa-times" : "fas fa-ellipsis-v",
                size: "24"
              }, null, 8, ["path"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="${ssrRenderClass([[isMenuNavBarActive.value ? "block" : "hidden"], "max-h-screen-menu overflow-y-auto lg:overflow-visible absolute w-screen top-14 left-0 bg-gray-50 shadow-lg lg:w-auto lg:flex lg:static lg:shadow-none dark:bg-slate-800"])}">`);
      _push(ssrRenderComponent(_sfc_main$b, {
        menu: __props.menu,
        onMenuClick: menuClick
      }, null, _parent));
      _push(`</div></div></nav>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NavBar.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const _sfc_main$8 = {
  __name: "AsideMenuItem",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      required: true
    },
    isDropdownList: Boolean
  },
  emits: ["menu-click"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const hasColor = computed(() => props.item && props.item.color);
    computed(
      () => hasColor.value ? "" : "aside-menu-item-active font-bold"
    );
    const darkModeStore = useDarkModeStore();
    const itemHref = computed(() => props.item.route ? route(props.item.route) : props.item.href);
    const activeInactiveStyle = computed(
      () => props.item.route && route().current(props.item.route) ? darkModeStore.asideMenuItemActiveStyle : ""
    );
    const isDropdownActive = ref(false);
    const componentClass = computed(() => [
      props.isDropdownList ? "py-3 px-6 text-sm" : "py-3",
      hasColor.value ? getButtonColor(props.item.color, false, true) : `aside-menu-item dark:text-slate-300 dark:hover:text-white`
    ]);
    const hasDropdown = computed(() => !!props.item.menu);
    const menuClick = (event) => {
      emit("menu-click", event, props.item);
      if (hasDropdown.value) {
        isDropdownActive.value = !isDropdownActive.value;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(_attrs)}>`);
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(__props.item.route ? unref(Link) : "a"), {
        href: itemHref.value,
        target: __props.item.target ?? null,
        class: ["flex cursor-pointer", componentClass.value],
        onClick: menuClick
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (__props.item.icon) {
              _push2(ssrRenderComponent(_sfc_main$g, {
                path: __props.item.icon,
                class: ["flex-none", activeInactiveStyle.value],
                w: "w-16",
                size: 18
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`<span class="${ssrRenderClass([[
              { "pr-12": !hasDropdown.value },
              activeInactiveStyle.value
            ], "grow text-ellipsis line-clamp-1"])}"${_scopeId}>${ssrInterpolate(__props.item.label)}</span>`);
            if (hasDropdown.value) {
              _push2(ssrRenderComponent(_sfc_main$g, {
                path: isDropdownActive.value ? "fas fa-minus" : "fas fa-plus",
                class: ["flex-none", activeInactiveStyle.value],
                w: "w-12"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              __props.item.icon ? (openBlock(), createBlock(_sfc_main$g, {
                key: 0,
                path: __props.item.icon,
                class: ["flex-none", activeInactiveStyle.value],
                w: "w-16",
                size: 18
              }, null, 8, ["path", "class"])) : createCommentVNode("", true),
              createVNode("span", {
                class: ["grow text-ellipsis line-clamp-1", [
                  { "pr-12": !hasDropdown.value },
                  activeInactiveStyle.value
                ]]
              }, toDisplayString(__props.item.label), 3),
              hasDropdown.value ? (openBlock(), createBlock(_sfc_main$g, {
                key: 1,
                path: isDropdownActive.value ? "fas fa-minus" : "fas fa-plus",
                class: ["flex-none", activeInactiveStyle.value],
                w: "w-12"
              }, null, 8, ["path", "class"])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }), _parent);
      if (hasDropdown.value) {
        _push(ssrRenderComponent(_sfc_main$7, {
          menu: __props.item.menu,
          class: ["aside-menu-dropdown", isDropdownActive.value ? "block dark:bg-slate-800/50" : "hidden"],
          "is-dropdown-list": ""
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</li>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/AsideMenuItem.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = {
  __name: "AsideMenuList",
  __ssrInlineRender: true,
  props: {
    isDropdownList: Boolean,
    menu: {
      type: Array,
      required: true
    }
  },
  emits: ["menu-click"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const menuClick = (event, item) => {
      emit("menu-click", event, item);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ul${ssrRenderAttrs(_attrs)}><!--[-->`);
      ssrRenderList(__props.menu, (item, index) => {
        _push(ssrRenderComponent(_sfc_main$8, {
          key: index,
          item,
          "is-dropdown-list": __props.isDropdownList,
          onMenuClick: menuClick
        }, null, _parent));
      });
      _push(`<!--]--></ul>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/AsideMenuList.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "AsideMenuLayer",
  __ssrInlineRender: true,
  props: {
    menu: {
      type: Array,
      required: true
    }
  },
  emits: ["menu-click", "aside-lg-close-click"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const logoutItem = computed(() => ({
      label: "Logout",
      icon: "fas fa-sign-out-alt",
      color: "info",
      isLogout: true
    }));
    const menuClick = (event, item) => {
      emit("menu-click", event, item);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<aside${ssrRenderAttrs(mergeProps({
        id: "aside",
        class: "lg:py-2 lg:pl-2 w-72 fixed flex z-40 top-0 h-screen transition-position overflow-hidden"
      }, _attrs))}><div class="aside lg:rounded-2xl flex-1 flex flex-col overflow-hidden dark:bg-slate-900"><div class="aside-brand flex flex-row h-14 items-center justify-between dark:bg-slate-900"><div class="text-center flex-1 lg:text-left lg:pl-6 xl:text-center xl:pl-0">`);
      _push(ssrRenderComponent(_sfc_main$h, {
        class: "mx-auto",
        logoSize: "200"
      }, null, _parent));
      _push(`</div><button class="hidden lg:inline-block xl:hidden p-3">`);
      _push(ssrRenderComponent(_sfc_main$g, { path: "fas fa-times" }, null, _parent));
      _push(`</button></div><div class="flex-1 overflow-y-auto overflow-x-hidden aside-scrollbars dark:aside-scrollbars-[slate]">`);
      _push(ssrRenderComponent(_sfc_main$7, {
        menu: __props.menu,
        onMenuClick: menuClick
      }, null, _parent));
      _push(`</div><ul>`);
      _push(ssrRenderComponent(_sfc_main$8, {
        item: logoutItem.value,
        onMenuClick: menuClick
      }, null, _parent));
      _push(`</ul></div></aside>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/AsideMenuLayer.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "OverlayLayer",
  __ssrInlineRender: true,
  props: {
    zIndex: {
      type: String,
      default: "z-50"
    },
    type: {
      type: String,
      default: "flex"
    }
  },
  emits: ["overlay-click"],
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: [[__props.type, __props.zIndex], "items-center flex-col justify-center overflow-hidden fixed inset-0"]
      }, _attrs))}><div class="overlay absolute inset-0 bg-gradient-to-tr opacity-90 dark:from-gray-700 dark:via-gray-900 dark:to-gray-700"></div>`);
      ssrRenderSlotInner(_ctx.$slots, "default", {}, null, _push, _parent, null, true);
      _push(`</div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/OverlayLayer.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "AsideMenu",
  __ssrInlineRender: true,
  props: {
    menu: {
      type: Array,
      required: true
    },
    isAsideMobileExpanded: Boolean,
    isAsideLgActive: Boolean
  },
  emits: ["menu-click", "aside-lg-close-click"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const menuClick = (event, item) => {
      emit("menu-click", event, item);
    };
    const asideLgCloseClick = (event) => {
      emit("aside-lg-close-click", event);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_sfc_main$6, {
        menu: __props.menu,
        class: [
          __props.isAsideMobileExpanded ? "left-0" : "-left-60 lg:left-0",
          { "lg:hidden xl:flex": !__props.isAsideLgActive }
        ],
        onMenuClick: menuClick,
        onAsideLgCloseClick: asideLgCloseClick
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$5, {
        style: __props.isAsideLgActive ? null : { display: "none" },
        "z-index": "z-30",
        onOverlayClick: asideLgCloseClick
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/AsideMenu.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "FooterBar",
  __ssrInlineRender: true,
  setup(__props) {
    const year = (/* @__PURE__ */ new Date()).getFullYear();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<footer${ssrRenderAttrs(mergeProps({
        class: ["py-2 px-6", unref(containerMaxW)]
      }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$i, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="text-center"${_scopeId}> © ${ssrInterpolate(unref(year))} All rights reserved, H. M. Masum Billah `);
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "text-center" }, [
                createTextVNode(" © " + toDisplayString(unref(year)) + " All rights reserved, H. M. Masum Billah ", 1),
                renderSlot(_ctx.$slots, "default")
              ])
            ];
          }
        }),
        _: 3
      }, _parent));
      _push(`</footer>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FooterBar.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "NotificationBar",
  __ssrInlineRender: true,
  props: {
    icon: {
      type: String,
      default: null
    },
    outline: Boolean,
    color: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const componentClass = computed(
      () => props.outline ? colorsOutline[props.color] : colorsBgLight[props.color]
    );
    const isDismissed = ref(false);
    const dismiss = () => {
      isDismissed.value = true;
    };
    const slots = useSlots();
    const hasRightSlot = computed(() => slots.right);
    return (_ctx, _push, _parent, _attrs) => {
      if (!isDismissed.value) {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: [componentClass.value, "px-3 py-6 md:py-3 mb-6 last:mb-0 border rounded-lg transition-colors duration-150"]
        }, _attrs))}>`);
        _push(ssrRenderComponent(_sfc_main$i, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex flex-col md:flex-row items-center"${_scopeId}>`);
              if (__props.icon) {
                _push2(ssrRenderComponent(_sfc_main$g, {
                  path: __props.icon,
                  w: "w-10 md:w-5",
                  h: "h-10 md:h-5",
                  size: "24",
                  class: "md:mr-2"
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`<span class="text-center md:text-left md:py-2"${_scopeId}>`);
              ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
              _push2(`</span></div>`);
              if (hasRightSlot.value) {
                ssrRenderSlot(_ctx.$slots, "right", {}, null, _push2, _parent2, _scopeId);
              } else {
                _push2(ssrRenderComponent(BaseButtonLink, {
                  icon: "fas fa-times",
                  small: "",
                  "rounded-full": "",
                  color: "white",
                  onClick: dismiss
                }, null, _parent2, _scopeId));
              }
            } else {
              return [
                createVNode("div", { class: "flex flex-col md:flex-row items-center" }, [
                  __props.icon ? (openBlock(), createBlock(_sfc_main$g, {
                    key: 0,
                    path: __props.icon,
                    w: "w-10 md:w-5",
                    h: "h-10 md:h-5",
                    size: "24",
                    class: "md:mr-2"
                  }, null, 8, ["path"])) : createCommentVNode("", true),
                  createVNode("span", { class: "text-center md:text-left md:py-2" }, [
                    renderSlot(_ctx.$slots, "default")
                  ])
                ]),
                hasRightSlot.value ? renderSlot(_ctx.$slots, "right", { key: 0 }) : (openBlock(), createBlock(BaseButtonLink, {
                  key: 1,
                  icon: "fas fa-times",
                  small: "",
                  "rounded-full": "",
                  color: "white",
                  onClick: dismiss
                }))
              ];
            }
          }),
          _: 3
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NotificationBar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "CacheCleanMessage",
  __ssrInlineRender: true,
  props: {
    message: {
      type: String,
      required: true
    },
    icon: {
      type: String,
      default: null
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      if (__props.message) {
        _push(ssrRenderComponent(_sfc_main$2, {
          class: "mx-10 my-1",
          color: "info",
          icon: __props.icon
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<b${_scopeId}>Cache:</b> ${ssrInterpolate(__props.message)}`);
            } else {
              return [
                createVNode("b", null, "Cache:"),
                createTextVNode(" " + toDisplayString(__props.message), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/CacheCleanMessage.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const hasPermission = (name) => {
  const { auth } = usePage().props;
  const userPermissions = auth.permissions || [];
  return userPermissions.some((p) => p.permission === name);
};
const layoutAsidePadding = "xl:pl-72";
const _sfc_main = {
  __name: "LayoutAuthenticated",
  __ssrInlineRender: true,
  setup(__props) {
    const darkModeStore = useDarkModeStore();
    const message = ref("");
    let filteredItems = filterItems(isSystemUser() ? menuAsideAdmin : menuAside);
    const navBar = isSystemUser() ? menuNavBarAdmin : menuNavBar;
    function filterItems(items) {
      return items.reduce((filtered, item) => {
        if (hasPermission(item.permission)) {
          if (item.menu) {
            const filteredMenu = filterItems(item.menu);
            if (filteredMenu.length > 0) {
              filtered.push({ ...item, menu: filteredMenu });
            }
          } else {
            filtered.push(item);
          }
        }
        return filtered;
      }, []);
    }
    if (!isSystemUser()) {
      filteredItems = filteredItems.filter((item) => {
        if (item.is_plugin === true && usePage().props.auth.features) {
          const features = usePage().props.auth.features;
          return features.includes(item.plugin_id);
        }
        return true;
      });
    }
    router.on("navigate", () => {
      isAsideMobileExpanded.value = false;
      isAsideLgActive.value = false;
    });
    const isAsideMobileExpanded = ref(false);
    const isAsideLgActive = ref(false);
    const menuClick = (event, item) => {
      if (item.isToggleLightDark) {
        darkModeStore.set(!darkModeStore.isEnabled);
      }
      if (item.isLogout) {
        router.post(route("logout"));
      }
      if (item.isCache) {
        clearCache();
      }
      if (item.isSite) {
        router.get(route("home"));
      }
    };
    const showMessage = (msg) => {
      message.value = msg;
      setTimeout(() => {
        message.value = "";
      }, 5e3);
    };
    const clearCache = async () => {
      try {
        const routeName = isSystemUser() ? "admin.cache.clear" : "cache.clear";
        await router.get(route(routeName));
        showMessage("Cache cleared successfully");
      } catch (error) {
        showMessage("Failed to clear cache " + error);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: {
          "overflow-hidden lg:overflow-visible": isAsideMobileExpanded.value
        }
      }, _attrs))}><div class="${ssrRenderClass([[layoutAsidePadding, { "ml-72 lg:ml-0": isAsideMobileExpanded.value }], "pt-14 min-h-screen w-screen transition-position lg:w-auto bg-gray-50 dark:bg-slate-800 dark:text-slate-100"])}">`);
      _push(ssrRenderComponent(_sfc_main$9, {
        menu: unref(navBar),
        class: [layoutAsidePadding, { "ml-60 lg:ml-0": isAsideMobileExpanded.value }],
        onMenuClick: menuClick
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$a, {
              display: "flex lg:hidden",
              onClick: ($event) => isAsideMobileExpanded.value = !isAsideMobileExpanded.value
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$g, {
                    path: isAsideMobileExpanded.value ? "fas fa-caret-square-left" : "fas fa-caret-square-right",
                    size: "24"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$g, {
                      path: isAsideMobileExpanded.value ? "fas fa-caret-square-left" : "fas fa-caret-square-right",
                      size: "24"
                    }, null, 8, ["path"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$a, {
              display: "hidden lg:flex xl:hidden",
              onClick: ($event) => isAsideLgActive.value = true
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$g, {
                    path: "fas fa-bars",
                    size: "24"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$g, {
                      path: "fas fa-bars",
                      size: "24"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$a, {
                display: "flex lg:hidden",
                onClick: withModifiers(($event) => isAsideMobileExpanded.value = !isAsideMobileExpanded.value, ["prevent"])
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$g, {
                    path: isAsideMobileExpanded.value ? "fas fa-caret-square-left" : "fas fa-caret-square-right",
                    size: "24"
                  }, null, 8, ["path"])
                ]),
                _: 1
              }, 8, ["onClick"]),
              createVNode(_sfc_main$a, {
                display: "hidden lg:flex xl:hidden",
                onClick: withModifiers(($event) => isAsideLgActive.value = true, ["prevent"])
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$g, {
                    path: "fas fa-bars",
                    size: "24"
                  })
                ]),
                _: 1
              }, 8, ["onClick"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        "is-aside-mobile-expanded": isAsideMobileExpanded.value,
        "is-aside-lg-active": isAsideLgActive.value,
        menu: unref(filteredItems),
        onMenuClick: menuClick,
        onAsideLgCloseClick: ($event) => isAsideLgActive.value = false
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        message: message.value,
        icon: "fas fa-sync-alt"
      }, null, _parent));
      _push(`<div style="${ssrRenderStyle({ "min-height": "90vh" })}">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
      _push(ssrRenderComponent(_sfc_main$3, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/LayoutAuthenticated.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const LayoutAuthenticated = _sfc_main;
export {
  LayoutAuthenticated as L,
  SectionMain as S,
  _sfc_main$5 as _,
  hasPermission as h
};
