import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { P as Pagination } from "./Pagination-BiZgXXz6.js";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { _ as _sfc_main$4 } from "./PostGrid-Din_eeNu.js";
import { usePage, Head } from "@inertiajs/vue3";
import { C as ComingSoon } from "./ComingSoon-DuRr8gR7.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    storageUrl: String
  },
  setup(__props) {
    const blogPageData = usePage().props.blogPageData;
    const blogsList = usePage().props.blogsList;
    const blogConents = {
      banner: ""
    };
    if (blogPageData) {
      blogPageData.contents.forEach((item) => {
        if (item.slug === "banner") {
          blogConents.banner = item.data[0];
        }
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Blog" }, null, _parent2, _scopeId));
            if (unref(blogPageData)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                bgImage: unref(blogPageData).featured_image
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: blogConents.banner.title,
                      description: blogConents.banner.description,
                      subtitle: blogConents.banner.subtitle
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: blogConents.banner.title,
                        description: blogConents.banner.description,
                        subtitle: blogConents.banner.subtitle
                      }, null, 8, ["title", "description", "subtitle"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<section class="relative py-20 bg-gray-200"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="grid gap-x-8 gap-y-4 grid-cols-3"${_scopeId}><!--[-->`);
              ssrRenderList((_a = unref(blogsList)) == null ? void 0 : _a.data, (post, index) => {
                _push2(`<div class="bg-gray-100 text-center rounded"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$4, { post }, null, _parent2, _scopeId));
                _push2(`</div>`);
              });
              _push2(`<!--]--></div>`);
              _push2(ssrRenderComponent(Pagination, {
                class: "mt-6",
                links: (_b = unref(blogsList)) == null ? void 0 : _b.links
              }, null, _parent2, _scopeId));
              _push2(`</div></section></main>`);
            } else {
              _push2(ssrRenderComponent(ComingSoon, null, null, _parent2, _scopeId));
            }
          } else {
            return [
              createVNode(unref(Head), { title: "Blog" }),
              unref(blogPageData) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, {
                  bgImage: unref(blogPageData).featured_image
                }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$3, {
                      title: blogConents.banner.title,
                      description: blogConents.banner.description,
                      subtitle: blogConents.banner.subtitle
                    }, null, 8, ["title", "description", "subtitle"])
                  ]),
                  _: 1
                }, 8, ["bgImage"]),
                createVNode("section", { class: "relative py-20 bg-gray-200" }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "grid gap-x-8 gap-y-4 grid-cols-3" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList((_c = unref(blogsList)) == null ? void 0 : _c.data, (post, index) => {
                        return openBlock(), createBlock("div", {
                          key: index,
                          class: "bg-gray-100 text-center rounded"
                        }, [
                          createVNode(_sfc_main$4, { post }, null, 8, ["post"])
                        ]);
                      }), 128))
                    ]),
                    createVNode(Pagination, {
                      class: "mt-6",
                      links: (_d = unref(blogsList)) == null ? void 0 : _d.links
                    }, null, 8, ["links"])
                  ])
                ])
              ])) : (openBlock(), createBlock(ComingSoon, { key: 1 }))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Blog/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
