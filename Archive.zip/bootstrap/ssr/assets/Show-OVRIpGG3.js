import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, Fragment, createCommentVNode, toDisplayString, createTextVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { _ as _sfc_main$4 } from "./InputError-VJquj49g.js";
import { i as isCandidateUser } from "./isCandidateUser-C4fFP75s.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./colors-K3EOgMMA.js";
import "./BaseIcon-C4zrUKd9.js";
import "./main-C5vGb8af.js";
import "pinia";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  setup(__props) {
    const authUser = usePage().props.auth.user;
    const jobDetail = usePage().props.jobDetail;
    const isApplied = usePage().props.isApplied;
    const form = useForm({
      id: jobDetail == null ? void 0 : jobDetail.id,
      expected_salary: ""
    });
    const submit = () => {
      form.post(route("job.apply"), {
        onSuccess: () => {
          form.reset();
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: (_a = unref(jobDetail)) == null ? void 0 : _a.title
            }, null, _parent2, _scopeId));
            if (unref(jobDetail)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, null, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  var _a2, _b2;
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: (_a2 = unref(jobDetail)) == null ? void 0 : _a2.title
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: (_b2 = unref(jobDetail)) == null ? void 0 : _b2.title
                      }, null, 8, ["title"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<section class="relative py-20 bg-gray-200 dark:bg-slate-800"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="flex justify-center"${_scopeId}><div class="my-2 w-9/12 mr-3 text-black bg-white dark:bg-gray-100 rounded p-5 shadow"${_scopeId}><h2 class="text-3xl font-semibold"${_scopeId}>Title: ${ssrInterpolate((_b = unref(jobDetail)) == null ? void 0 : _b.title)}</h2><hr class="mb-2"${_scopeId}><h2 class="text-xl font-semibold"${_scopeId}>About Company</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_c = unref(jobDetail)) == null ? void 0 : _c.company.description)}</p><h2 class="text-xl font-semibold"${_scopeId}>Web</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_d = unref(jobDetail)) == null ? void 0 : _d.company.website)}</p><h2 class="text-xl font-semibold"${_scopeId}>Location</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_e = unref(jobDetail)) == null ? void 0 : _e.location)}</p><h2 class="text-xl font-semibold"${_scopeId}>Description</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_f = unref(jobDetail)) == null ? void 0 : _f.description)}</p><h2 class="text-xl font-semibold"${_scopeId}>Requirements</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_g = unref(jobDetail)) == null ? void 0 : _g.requirements)}</p><h2 class="text-xl font-semibold"${_scopeId}>Responsibilities</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_h = unref(jobDetail)) == null ? void 0 : _h.responsibilities)}</p><h2 class="text-xl font-semibold"${_scopeId}>Job type</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_i = unref(jobDetail)) == null ? void 0 : _i.job_type)}</p><h2 class="text-xl font-semibold"${_scopeId}>Salary</h2><p class="mb-2"${_scopeId}>৳${ssrInterpolate((_j = unref(jobDetail)) == null ? void 0 : _j.salary)}</p><h2 class="text-xl font-semibold"${_scopeId}>Facilities</h2><p class="mb-2"${_scopeId}>${ssrInterpolate((_k = unref(jobDetail)) == null ? void 0 : _k.facilities)}</p></div><div class="flex flex-col justify-between my-2 w-3/12 mr-3 text-black bg-white dark:bg-gray-100 rounded p-5 shadow"${_scopeId}><div${_scopeId}><p class="text-xl mb-1"${_scopeId}><span class="font-bold"${_scopeId}>Post By:</span> ${ssrInterpolate((_l = unref(jobDetail)) == null ? void 0 : _l.user.name)}</p><p class="text-xl mb-1"${_scopeId}><span class="font-bold"${_scopeId}>Posted on:</span> ${ssrInterpolate((_m = unref(jobDetail)) == null ? void 0 : _m.created_at)}</p><p class="text-xl mb-1"${_scopeId}><span class="font-bold"${_scopeId}>Closing on:</span> <span class="text-red-800"${_scopeId}>${ssrInterpolate((_n = unref(jobDetail)) == null ? void 0 : _n.closing_date)}</span></p></div>`);
              if (unref(authUser) && unref(isCandidateUser)()) {
                _push2(ssrRenderComponent(CardBox, {
                  class: "my-24 w-full",
                  "is-form": "",
                  onSubmit: submit
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      if (!unref(isApplied)) {
                        _push3(`<!--[-->`);
                        _push3(ssrRenderComponent(FormField, { label: "Expected Salary" }, {
                          default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(ssrRenderComponent(FormControl, {
                                icon: "fas fa-dollar-sign",
                                modelValue: unref(form).expected_salary,
                                "onUpdate:modelValue": ($event) => unref(form).expected_salary = $event,
                                type: "text"
                              }, null, _parent4, _scopeId3));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  icon: "fas fa-dollar-sign",
                                  modelValue: unref(form).expected_salary,
                                  "onUpdate:modelValue": ($event) => unref(form).expected_salary = $event,
                                  type: "text"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent3, _scopeId2));
                        _push3(ssrRenderComponent(_sfc_main$4, {
                          class: "mt-2",
                          message: unref(form).errors.expected_salary
                        }, null, _parent3, _scopeId2));
                        _push3(ssrRenderComponent(BaseDivider, null, null, _parent3, _scopeId2));
                        _push3(ssrRenderComponent(BaseButtons, null, {
                          default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(ssrRenderComponent(BaseButtonLink, {
                                icon: "far fa-save",
                                type: "submit",
                                color: "info",
                                label: "Apply",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, _parent4, _scopeId3));
                            } else {
                              return [
                                createVNode(BaseButtonLink, {
                                  icon: "far fa-save",
                                  type: "submit",
                                  color: "info",
                                  label: "Apply",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["class", "disabled"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent3, _scopeId2));
                        if (unref(form).recentlySuccessful) {
                          _push3(`<p class="text-sm text-gray-600 dark:text-gray-400"${_scopeId2}>Applied.</p>`);
                        } else {
                          _push3(`<!---->`);
                        }
                        _push3(`<!--]-->`);
                      } else {
                        _push3(`<p class="text-xl font-semibold text-green-800"${_scopeId2}>You Already Applied.</p>`);
                      }
                    } else {
                      return [
                        !unref(isApplied) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                          createVNode(FormField, { label: "Expected Salary" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                icon: "fas fa-dollar-sign",
                                modelValue: unref(form).expected_salary,
                                "onUpdate:modelValue": ($event) => unref(form).expected_salary = $event,
                                type: "text"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.expected_salary
                          }, null, 8, ["message"]),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                icon: "far fa-save",
                                type: "submit",
                                color: "info",
                                label: "Apply",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["class", "disabled"])
                            ]),
                            _: 1
                          }),
                          unref(form).recentlySuccessful ? (openBlock(), createBlock("p", {
                            key: 0,
                            class: "text-sm text-gray-600 dark:text-gray-400"
                          }, "Applied.")) : createCommentVNode("", true)
                        ], 64)) : (openBlock(), createBlock("p", {
                          key: 1,
                          class: "text-xl font-semibold text-green-800"
                        }, "You Already Applied."))
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<div class="text-center"${_scopeId}>`);
                _push2(ssrRenderComponent(BaseButtonLink, {
                  icon: "far fa-save",
                  type: "button",
                  color: "danger",
                  label: "Login To Apply",
                  routeName: "login"
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              }
              _push2(`</div></div></div></section></main>`);
            } else {
              _push2(`<main class="mt-40"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="items-center justify-center flex flex-wrap"${_scopeId}><div class="w-full ml-auto mr-auto px-4"${_scopeId}><h3 class="text-4xl font-semibold"${_scopeId}>Not Found</h3></div></div></div></main>`);
            }
          } else {
            return [
              createVNode(unref(Head), {
                title: (_o = unref(jobDetail)) == null ? void 0 : _o.title
              }, null, 8, ["title"]),
              unref(jobDetail) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, null, {
                  default: withCtx(() => {
                    var _a2;
                    return [
                      createVNode(_sfc_main$3, {
                        title: (_a2 = unref(jobDetail)) == null ? void 0 : _a2.title
                      }, null, 8, ["title"])
                    ];
                  }),
                  _: 1
                }),
                createVNode("section", { class: "relative py-20 bg-gray-200 dark:bg-slate-800" }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "flex justify-center" }, [
                      createVNode("div", { class: "my-2 w-9/12 mr-3 text-black bg-white dark:bg-gray-100 rounded p-5 shadow" }, [
                        createVNode("h2", { class: "text-3xl font-semibold" }, "Title: " + toDisplayString((_p = unref(jobDetail)) == null ? void 0 : _p.title), 1),
                        createVNode("hr", { class: "mb-2" }),
                        createVNode("h2", { class: "text-xl font-semibold" }, "About Company"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_q = unref(jobDetail)) == null ? void 0 : _q.company.description), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Web"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_r = unref(jobDetail)) == null ? void 0 : _r.company.website), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Location"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_s = unref(jobDetail)) == null ? void 0 : _s.location), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Description"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_t = unref(jobDetail)) == null ? void 0 : _t.description), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Requirements"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_u = unref(jobDetail)) == null ? void 0 : _u.requirements), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Responsibilities"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_v = unref(jobDetail)) == null ? void 0 : _v.responsibilities), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Job type"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_w = unref(jobDetail)) == null ? void 0 : _w.job_type), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Salary"),
                        createVNode("p", { class: "mb-2" }, "৳" + toDisplayString((_x = unref(jobDetail)) == null ? void 0 : _x.salary), 1),
                        createVNode("h2", { class: "text-xl font-semibold" }, "Facilities"),
                        createVNode("p", { class: "mb-2" }, toDisplayString((_y = unref(jobDetail)) == null ? void 0 : _y.facilities), 1)
                      ]),
                      createVNode("div", { class: "flex flex-col justify-between my-2 w-3/12 mr-3 text-black bg-white dark:bg-gray-100 rounded p-5 shadow" }, [
                        createVNode("div", null, [
                          createVNode("p", { class: "text-xl mb-1" }, [
                            createVNode("span", { class: "font-bold" }, "Post By:"),
                            createTextVNode(" " + toDisplayString((_z = unref(jobDetail)) == null ? void 0 : _z.user.name), 1)
                          ]),
                          createVNode("p", { class: "text-xl mb-1" }, [
                            createVNode("span", { class: "font-bold" }, "Posted on:"),
                            createTextVNode(" " + toDisplayString((_A = unref(jobDetail)) == null ? void 0 : _A.created_at), 1)
                          ]),
                          createVNode("p", { class: "text-xl mb-1" }, [
                            createVNode("span", { class: "font-bold" }, "Closing on:"),
                            createTextVNode(),
                            createVNode("span", { class: "text-red-800" }, toDisplayString((_B = unref(jobDetail)) == null ? void 0 : _B.closing_date), 1)
                          ])
                        ]),
                        unref(authUser) && unref(isCandidateUser)() ? (openBlock(), createBlock(CardBox, {
                          key: 0,
                          class: "my-24 w-full",
                          "is-form": "",
                          onSubmit: withModifiers(submit, ["prevent"])
                        }, {
                          default: withCtx(() => [
                            !unref(isApplied) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                              createVNode(FormField, { label: "Expected Salary" }, {
                                default: withCtx(() => [
                                  createVNode(FormControl, {
                                    icon: "fas fa-dollar-sign",
                                    modelValue: unref(form).expected_salary,
                                    "onUpdate:modelValue": ($event) => unref(form).expected_salary = $event,
                                    type: "text"
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.expected_salary
                              }, null, 8, ["message"]),
                              createVNode(BaseDivider),
                              createVNode(BaseButtons, null, {
                                default: withCtx(() => [
                                  createVNode(BaseButtonLink, {
                                    icon: "far fa-save",
                                    type: "submit",
                                    color: "info",
                                    label: "Apply",
                                    class: { "opacity-25": unref(form).processing },
                                    disabled: unref(form).processing
                                  }, null, 8, ["class", "disabled"])
                                ]),
                                _: 1
                              }),
                              unref(form).recentlySuccessful ? (openBlock(), createBlock("p", {
                                key: 0,
                                class: "text-sm text-gray-600 dark:text-gray-400"
                              }, "Applied.")) : createCommentVNode("", true)
                            ], 64)) : (openBlock(), createBlock("p", {
                              key: 1,
                              class: "text-xl font-semibold text-green-800"
                            }, "You Already Applied."))
                          ]),
                          _: 1
                        })) : (openBlock(), createBlock("div", {
                          key: 1,
                          class: "text-center"
                        }, [
                          createVNode(BaseButtonLink, {
                            icon: "far fa-save",
                            type: "button",
                            color: "danger",
                            label: "Login To Apply",
                            routeName: "login"
                          })
                        ]))
                      ])
                    ])
                  ])
                ])
              ])) : (openBlock(), createBlock("main", {
                key: 1,
                class: "mt-40"
              }, [
                createVNode("div", { class: "container mx-auto px-4" }, [
                  createVNode("div", { class: "items-center justify-center flex flex-wrap" }, [
                    createVNode("div", { class: "w-full ml-auto mr-auto px-4" }, [
                      createVNode("h3", { class: "text-4xl font-semibold" }, "Not Found")
                    ])
                  ])
                ])
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Job/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
