import { defineComponent, withCtx, createVNode, unref, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { usePage, useForm, router } from "@inertiajs/vue3";
import "./colors-K3EOgMMA.js";
import "./BaseIcon-C4zrUKd9.js";
import "./isSystemUser-D-zJOoLX.js";
import "./NotificationBarInCard-Dg146C8Q.js";
import "./IconRounded-RF1xkXym.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "pinia";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Training",
  __ssrInlineRender: true,
  setup(__props) {
    const trainingInfo = usePage().props.trainingInfo;
    const form = useForm({
      "tableRow": [
        {
          id: 0,
          title: "",
          organization: "",
          location: "",
          start_date: "",
          end_date: "",
          description: ""
        }
      ],
      _method: "post"
    });
    if (trainingInfo) {
      form.tableRow = trainingInfo;
    }
    const addRow = () => {
      form.tableRow.push({
        id: 0,
        title: "",
        organization: "",
        location: "",
        start_date: "",
        end_date: "",
        description: ""
      });
    };
    const remove = (index, id) => {
      form.tableRow.splice(index, 1);
      if (id != 0) {
        router.delete(route("resume.deleteTraining", id));
      }
    };
    const submit = (data) => {
      router.post(route("resume.saveTraining"), data);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(SectionTitleLineWithButton, {
        icon: "fas fa-arrow-circle-right",
        title: "Trainig / Certification",
        main: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(BaseButtonLink, {
              icon: "fas fa-plus",
              onClick: addRow,
              label: "Add New",
              color: "contrast",
              "rounded-full": "",
              small: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(BaseButtonLink, {
                icon: "fas fa-plus",
                onClick: addRow,
                label: "Add New",
                color: "contrast",
                "rounded-full": "",
                small: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(CardBox, {
        "is-form": "",
        onSubmit: submit
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(FormValidationErrors, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(FormSuccess, null, null, _parent2, _scopeId));
            _push2(`<table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}> Title </th><th scope="col" class="px-6 py-3"${_scopeId}> Organization </th><th scope="col" class="px-6 py-3"${_scopeId}> Location </th><th scope="col" class="px-6 py-3"${_scopeId}> Start Date </th><th scope="col" class="px-6 py-3"${_scopeId}> End Date </th><th scope="col" class="px-6 py-3"${_scopeId}> Description </th><th scope="col" class="px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(unref(form).tableRow, (row, index) => {
              _push2(`<tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700"${_scopeId}><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.title,
                "onUpdate:modelValue": ($event) => row.title = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.organization,
                "onUpdate:modelValue": ($event) => row.organization = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.location,
                "onUpdate:modelValue": ($event) => row.location = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.start_date,
                "onUpdate:modelValue": ($event) => row.start_date = $event,
                type: "date",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.end_date,
                "onUpdate:modelValue": ($event) => row.end_date = $event,
                type: "date",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.description,
                "onUpdate:modelValue": ($event) => row.description = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(BaseButtonLink, {
                icon: "far fa-save",
                color: "info",
                class: { "opacity-25": unref(form).processing },
                onClick: ($event) => submit(row)
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(BaseButtonLink, {
                icon: "fas fa-minus",
                onClick: ($event) => remove(index, row.id),
                class: "ml-2",
                color: "danger",
                "rounded-full": "",
                small: ""
              }, null, _parent2, _scopeId));
              _push2(`</td></tr>`);
            });
            _push2(`<!--]--></tbody></table>`);
          } else {
            return [
              createVNode(FormValidationErrors),
              createVNode(FormSuccess),
              createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                  createVNode("tr", null, [
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Title "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Organization "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Location "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Start Date "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " End Date "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Description "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Action ")
                  ])
                ]),
                createVNode("tbody", null, [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(form).tableRow, (row, index) => {
                    return openBlock(), createBlock("tr", {
                      key: index,
                      class: "odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700"
                    }, [
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.title,
                          "onUpdate:modelValue": ($event) => row.title = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.organization,
                          "onUpdate:modelValue": ($event) => row.organization = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.location,
                          "onUpdate:modelValue": ($event) => row.location = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.start_date,
                          "onUpdate:modelValue": ($event) => row.start_date = $event,
                          type: "date",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.end_date,
                          "onUpdate:modelValue": ($event) => row.end_date = $event,
                          type: "date",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.description,
                          "onUpdate:modelValue": ($event) => row.description = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(BaseButtonLink, {
                          icon: "far fa-save",
                          color: "info",
                          class: { "opacity-25": unref(form).processing },
                          onClick: ($event) => submit(row)
                        }, null, 8, ["class", "onClick"]),
                        createVNode(BaseButtonLink, {
                          icon: "fas fa-minus",
                          onClick: ($event) => remove(index, row.id),
                          class: "ml-2",
                          color: "danger",
                          "rounded-full": "",
                          small: ""
                        }, null, 8, ["onClick"])
                      ])
                    ]);
                  }), 128))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Resume/Tabs/Training.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
