import { mergeProps, useSSRContext, computed, withCtx, createVNode, openBlock, createBlock, createCommentVNode, withModifiers, renderSlot, withDirectives, vShow } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderSlot, ssrRenderComponent } from "vue/server-renderer";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { _ as _sfc_main$2 } from "./LayoutAuthenticated-DwQaEU0a.js";
const _sfc_main$1 = {
  __name: "CardBoxComponentTitle",
  __ssrInlineRender: true,
  props: {
    title: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-between mb-3" }, _attrs))}><h1 class="text-2xl">${ssrInterpolate(__props.title)}</h1>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/CardBoxComponentTitle.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "CardBoxModal",
  __ssrInlineRender: true,
  props: {
    title: {
      type: String,
      required: true
    },
    button: {
      type: String,
      default: "info"
    },
    buttonLabel: {
      type: String,
      default: "Done"
    },
    hasCancel: Boolean,
    modelValue: {
      type: [String, Number, Boolean],
      default: null
    }
  },
  emits: ["update:modelValue", "cancel", "confirm"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const value = computed({
      get: () => props.modelValue,
      set: (value2) => emit("update:modelValue", value2)
    });
    const confirmCancel = (mode) => {
      value.value = false;
      emit(mode);
    };
    const confirm = () => confirmCancel("confirm");
    const cancel = () => confirmCancel("cancel");
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && value.value) {
        cancel();
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$2, mergeProps({
        style: value.value ? null : { display: "none" },
        onOverlayClick: cancel
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(CardBox, {
              style: value.value ? null : { display: "none" },
              class: "shadow-lg max-h-modal w-11/12 md:w-3/5 lg:w-2/5 xl:w-4/12 z-50",
              "is-modal": ""
            }, {
              footer: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(BaseButtons, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          label: __props.buttonLabel,
                          color: __props.button,
                          onClick: confirm
                        }, null, _parent4, _scopeId3));
                        if (__props.hasCancel) {
                          _push4(ssrRenderComponent(BaseButtonLink, {
                            label: "Cancel",
                            color: __props.button,
                            outline: "",
                            onClick: cancel
                          }, null, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            label: __props.buttonLabel,
                            color: __props.button,
                            onClick: confirm
                          }, null, 8, ["label", "color"]),
                          __props.hasCancel ? (openBlock(), createBlock(BaseButtonLink, {
                            key: 0,
                            label: "Cancel",
                            color: __props.button,
                            outline: "",
                            onClick: cancel
                          }, null, 8, ["color"])) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(BaseButtons, null, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          label: __props.buttonLabel,
                          color: __props.button,
                          onClick: confirm
                        }, null, 8, ["label", "color"]),
                        __props.hasCancel ? (openBlock(), createBlock(BaseButtonLink, {
                          key: 0,
                          label: "Cancel",
                          color: __props.button,
                          outline: "",
                          onClick: cancel
                        }, null, 8, ["color"])) : createCommentVNode("", true)
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$1, { title: __props.title }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (__props.hasCancel) {
                          _push4(ssrRenderComponent(BaseButtonLink, {
                            icon: "far fa-times-circle",
                            color: "whiteDark",
                            small: "",
                            "rounded-full": "",
                            onClick: cancel
                          }, null, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                      } else {
                        return [
                          __props.hasCancel ? (openBlock(), createBlock(BaseButtonLink, {
                            key: 0,
                            icon: "far fa-times-circle",
                            color: "whiteDark",
                            small: "",
                            "rounded-full": "",
                            onClick: withModifiers(cancel, ["prevent"])
                          })) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="space-y-3"${_scopeId2}>`);
                  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push3, _parent3, _scopeId2);
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(_sfc_main$1, { title: __props.title }, {
                      default: withCtx(() => [
                        __props.hasCancel ? (openBlock(), createBlock(BaseButtonLink, {
                          key: 0,
                          icon: "far fa-times-circle",
                          color: "whiteDark",
                          small: "",
                          "rounded-full": "",
                          onClick: withModifiers(cancel, ["prevent"])
                        })) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["title"]),
                    createVNode("div", { class: "space-y-3" }, [
                      renderSlot(_ctx.$slots, "default")
                    ])
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              withDirectives(createVNode(CardBox, {
                class: "shadow-lg max-h-modal w-11/12 md:w-3/5 lg:w-2/5 xl:w-4/12 z-50",
                "is-modal": ""
              }, {
                footer: withCtx(() => [
                  createVNode(BaseButtons, null, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        label: __props.buttonLabel,
                        color: __props.button,
                        onClick: confirm
                      }, null, 8, ["label", "color"]),
                      __props.hasCancel ? (openBlock(), createBlock(BaseButtonLink, {
                        key: 0,
                        label: "Cancel",
                        color: __props.button,
                        outline: "",
                        onClick: cancel
                      }, null, 8, ["color"])) : createCommentVNode("", true)
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_sfc_main$1, { title: __props.title }, {
                    default: withCtx(() => [
                      __props.hasCancel ? (openBlock(), createBlock(BaseButtonLink, {
                        key: 0,
                        icon: "far fa-times-circle",
                        color: "whiteDark",
                        small: "",
                        "rounded-full": "",
                        onClick: withModifiers(cancel, ["prevent"])
                      })) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["title"]),
                  createVNode("div", { class: "space-y-3" }, [
                    renderSlot(_ctx.$slots, "default")
                  ])
                ]),
                _: 3
              }, 512), [
                [vShow, value.value]
              ])
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/CardBoxModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const CardBoxModal = _sfc_main;
export {
  CardBoxModal as C
};
