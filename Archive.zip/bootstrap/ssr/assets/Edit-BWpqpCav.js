import { defineComponent, withCtx, unref, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import _sfc_main$3 from "./DeleteUserForm-D9JWCre1.js";
import _sfc_main$2 from "./UpdatePasswordForm-CxK_6q0W.js";
import _sfc_main$1 from "./UpdateProfileInformationForm-UqpqGFfj.js";
import { Head } from "@inertiajs/vue3";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./BaseButtonLink-BG-sFKCn.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./InputError-VJquj49g.js";
import "./TextInput--LdMoNCR.js";
import "./PrimaryButton-4NJ7Yqx3.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: Boolean,
    status: String
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Profile" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg mb-5"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$1, {
                    "must-verify-email": __props.mustVerifyEmail,
                    status: __props.status,
                    class: "max-w-xl"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg mb-5"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$2, { class: "max-w-xl" }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, { class: "max-w-xl" }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg mb-5" }, [
                      createVNode(_sfc_main$1, {
                        "must-verify-email": __props.mustVerifyEmail,
                        status: __props.status,
                        class: "max-w-xl"
                      }, null, 8, ["must-verify-email", "status"])
                    ]),
                    createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg mb-5" }, [
                      createVNode(_sfc_main$2, { class: "max-w-xl" })
                    ]),
                    createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg" }, [
                      createVNode(_sfc_main$3, { class: "max-w-xl" })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Profile" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg mb-5" }, [
                    createVNode(_sfc_main$1, {
                      "must-verify-email": __props.mustVerifyEmail,
                      status: __props.status,
                      class: "max-w-xl"
                    }, null, 8, ["must-verify-email", "status"])
                  ]),
                  createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg mb-5" }, [
                    createVNode(_sfc_main$2, { class: "max-w-xl" })
                  ]),
                  createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg" }, [
                    createVNode(_sfc_main$3, { class: "max-w-xl" })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Profile/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
