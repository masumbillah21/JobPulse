import { defineComponent, mergeProps, useSSRContext, ref } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle, ssrRenderSlot } from "vue/server-renderer";
import { usePage } from "@inertiajs/vue3";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "SectionTitle",
  __ssrInlineRender: true,
  props: {
    subtitle: {
      type: String,
      default: null
    },
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      default: null
    },
    sectionClass: {
      type: String,
      default: "text-center"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["pr-12", __props.sectionClass]
      }, _attrs))}>`);
      if (__props.subtitle) {
        _push(`<h4>${ssrInterpolate(__props.subtitle)}</h4>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.title) {
        _push(`<h1 class="font-semibold text-5xl">${ssrInterpolate(__props.title)}</h1>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.description) {
        _push(`<p class="mt-4 text-lg">${ssrInterpolate(__props.description)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/SectionTitle.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BannerSection",
  __ssrInlineRender: true,
  props: {
    bgImage: {
      type: String,
      default: "images/job-portal-banner.jpg"
    },
    backgroundSize: {
      type: String,
      default: "cover"
    },
    banerHeight: {
      type: String,
      default: "45vh"
    }
  },
  setup(__props) {
    const urls = usePage().props.urls;
    const props = __props;
    const imageUrl = ref("");
    if (props.bgImage && (props.bgImage.startsWith("http://") || props.bgImage.startsWith("https://"))) {
      imageUrl.value = props.bgImage;
    } else if (props.bgImage && props.bgImage.startsWith("data:")) {
      imageUrl.value = props.bgImage;
    } else {
      imageUrl.value = urls.storeUrl + "/" + props.bgImage;
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "relative pt-16 pb-32 flex content-center items-center justify-center",
        style: `min-height: ${__props.banerHeight};`
      }, _attrs))}><div class="absolute top-0 w-full h-full bg-center bg-cover" style="${ssrRenderStyle([{ "background-repeat": "no-repeat", "background-position": "center" }, "background-image: url(" + imageUrl.value + "); background-size: " + __props.backgroundSize + ";"])}"><span id="blackOverlay" class="w-full h-full absolute opacity-75 bg-black left-0"></span></div><div class="container relative mx-auto"><div class="items-center flex flex-wrap"><div class="w-full lg:w-6/12 px-4 ml-auto mr-auto text-center text-white">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/BannerSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _,
  _sfc_main$1 as a
};
