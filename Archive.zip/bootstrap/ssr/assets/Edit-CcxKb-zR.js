import { defineComponent, withCtx, unref, createVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./IconRounded-RF1xkXym.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  setup(__props) {
    const roleData = usePage().props.role ?? null;
    const permissionList = usePage().props.permissionList ?? null;
    const form = useForm({
      id: 0,
      name: "",
      permissions: [],
      _method: "post"
    });
    if (roleData !== null) {
      form.id = roleData.id;
      form.name = roleData.name;
      form.permissions = roleData.permissions.map((permission) => permission.id);
      form._method = "put";
    }
    const submit = () => {
      if (roleData !== null) {
        update();
      } else {
        create();
      }
    };
    const create = () => {
      form.post(route("admin.roles.store"), {
        onSuccess: () => form.reset()
      });
    };
    const update = () => {
      form.post(route("admin.roles.update", form.id));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(roleData) !== null ? "Edit Role" : "Create Role"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(roleData) !== null ? "Edit Role" : "Create Role",
                    main: ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "roles.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            icon: "far fa-arrow-alt-circle-left",
                            label: "Back",
                            routeName: "roles.index",
                            color: "contrast",
                            "rounded-full": "",
                            small: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="flex justify-center items-center"${_scopeId2}>`);
                  _push3(ssrRenderComponent(CardBox, {
                    class: "my-24 w-9/12",
                    "is-form": "",
                    onSubmit: submit
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormSuccess, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Name",
                          "label-for": "name",
                          help: "Please enter role name"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).name,
                                  "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                  id: "name",
                                  autocomplete: "name",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Permissions",
                          "label-for": "permissions",
                          help: "Please select permissions"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormCheckRadioGroup, {
                                modelValue: unref(form).permissions,
                                "onUpdate:modelValue": ($event) => unref(form).permissions = $event,
                                name: "permissions",
                                options: unref(permissionList)
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormCheckRadioGroup, {
                                  modelValue: unref(form).permissions,
                                  "onUpdate:modelValue": ($event) => unref(form).permissions = $event,
                                  name: "permissions",
                                  options: unref(permissionList)
                                }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtons, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: unref(roleData) !== null ? "Update" : "Create",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(BaseButtonLink, {
                                  type: "submit",
                                  color: "info",
                                  label: unref(roleData) !== null ? "Update" : "Create",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["label", "class", "disabled"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          createVNode(FormField, {
                            label: "Name",
                            "label-for": "name",
                            help: "Please enter role name"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Permissions",
                            "label-for": "permissions",
                            help: "Please select permissions"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormCheckRadioGroup, {
                                modelValue: unref(form).permissions,
                                "onUpdate:modelValue": ($event) => unref(form).permissions = $event,
                                name: "permissions",
                                options: unref(permissionList)
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: unref(roleData) !== null ? "Update" : "Create",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["label", "class", "disabled"])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: unref(roleData) !== null ? "Edit Role" : "Create Role",
                      main: ""
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "roles.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        })
                      ]),
                      _: 1
                    }, 8, ["title"]),
                    createVNode("div", { class: "flex justify-center items-center" }, [
                      createVNode(CardBox, {
                        class: "my-24 w-9/12",
                        "is-form": "",
                        onSubmit: withModifiers(submit, ["prevent"])
                      }, {
                        default: withCtx(() => [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          createVNode(FormField, {
                            label: "Name",
                            "label-for": "name",
                            help: "Please enter role name"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Permissions",
                            "label-for": "permissions",
                            help: "Please select permissions"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormCheckRadioGroup, {
                                modelValue: unref(form).permissions,
                                "onUpdate:modelValue": ($event) => unref(form).permissions = $event,
                                name: "permissions",
                                options: unref(permissionList)
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: unref(roleData) !== null ? "Update" : "Create",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["label", "class", "disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(roleData) !== null ? "Edit Role" : "Create Role"
              }, null, 8, ["title"]),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(roleData) !== null ? "Edit Role" : "Create Role",
                    main: ""
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        icon: "far fa-arrow-alt-circle-left",
                        label: "Back",
                        routeName: "roles.index",
                        color: "contrast",
                        "rounded-full": "",
                        small: ""
                      })
                    ]),
                    _: 1
                  }, 8, ["title"]),
                  createVNode("div", { class: "flex justify-center items-center" }, [
                    createVNode(CardBox, {
                      class: "my-24 w-9/12",
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormSuccess),
                        createVNode(FormField, {
                          label: "Name",
                          "label-for": "name",
                          help: "Please enter role name"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).name,
                              "onUpdate:modelValue": ($event) => unref(form).name = $event,
                              id: "name",
                              autocomplete: "name",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Permissions",
                          "label-for": "permissions",
                          help: "Please select permissions"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormCheckRadioGroup, {
                              modelValue: unref(form).permissions,
                              "onUpdate:modelValue": ($event) => unref(form).permissions = $event,
                              name: "permissions",
                              options: unref(permissionList)
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                          ]),
                          _: 1
                        }),
                        createVNode(BaseDivider),
                        createVNode(BaseButtons, null, {
                          default: withCtx(() => [
                            createVNode(BaseButtonLink, {
                              type: "submit",
                              color: "info",
                              label: unref(roleData) !== null ? "Update" : "Create",
                              class: { "opacity-25": unref(form).processing },
                              disabled: unref(form).processing
                            }, null, 8, ["label", "class", "disabled"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Roles/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
