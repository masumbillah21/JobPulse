import { defineComponent, ref, mergeProps, unref, withCtx, createVNode, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrRenderStyle, ssrRenderSlot } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./ApplicationLogo-DFQaU58l.js";
import { usePage, Link } from "@inertiajs/vue3";
import { i as isSystemUser } from "./isSystemUser-D-zJOoLX.js";
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Navbar",
  __ssrInlineRender: true,
  setup(__props) {
    const showMenu = ref(false);
    const dashboardRoute = isSystemUser() ? "admin.dashboard" : "dashboard";
    const publicPages = usePage().props.publicPages ?? null;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "relative z-50 w-full flex flex-wrap items-center justify-between px-2 py-3" }, _attrs))}><div class="container px-4 mx-auto flex flex-wrap items-center justify-between"><div class="w-full relative flex justify-between lg:w-auto lg:static lg:block lg:justify-start"><button class="cursor-pointer text-xl leading-none px-3 py-1 border border-solid border-transparent rounded bg-transparent block lg:hidden outline-none focus:outline-none" type="button"><i class="text-white dark:text-slate-800 fas fa-bars"></i></button>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("home"),
        class: "text-xl italic font-bold leading-relaxed inline-block mr-4 py-2 whitespace-nowrap uppercase text-stone-800 dark:text-white"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$3, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$3)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="${ssrRenderClass([{ "hidden": !showMenu.value, "block": showMenu.value }, "lg:flex flex-grow items-center bg-white lg:bg-transparent lg:shadow-none"])}"><ul class="flex flex-col lg:flex-row list-none mr-auto"><li class="flex items-center">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("home"),
        class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Home `);
          } else {
            return [
              createTextVNode(" Home ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li>`);
      if (unref(publicPages)) {
        _push(`<!--[-->`);
        ssrRenderList(unref(publicPages), (page) => {
          _push(`<li class="flex items-center">`);
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("public.page", page.slug),
            class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(page.title)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(page.title), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`<li class="flex items-center">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("job"),
        class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Jobs `);
          } else {
            return [
              createTextVNode(" Jobs ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="flex items-center">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("blog"),
        class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Blog `);
          } else {
            return [
              createTextVNode(" Blog ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="flex items-center">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("contact"),
        class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Contact `);
          } else {
            return [
              createTextVNode(" Contact ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul><ul class="flex flex-col lg:flex-row list-none lg:ml-auto">`);
      if (_ctx.$page.props.auth.user) {
        _push(`<li class="flex items-center">`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route(unref(dashboardRoute)),
          class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Dashboard`);
            } else {
              return [
                createTextVNode(" Dashboard")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!--[--><li class="flex items-center">`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("login"),
          class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Log in`);
            } else {
              return [
                createTextVNode(" Log in")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li><li class="flex items-center">`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("register"),
          class: "lg:text-stone-900 lg:hover:text-gray-500 text-gray-800 dark:text-white px-3 py-4 lg:py-2 flex items-center text-xs uppercase font-bold"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Register`);
            } else {
              return [
                createTextVNode(" Register")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li><!--]-->`);
      }
      _push(`</ul></div></div></nav>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/Navbar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    const date = (/* @__PURE__ */ new Date()).getFullYear();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "relative pt-8 pb-6 bg-white dark:bg-slate-800" }, _attrs))}><div class="container mx-auto px-4"><div class="flex flex-wrap"><div class="w-full lg:w-6/12 px-4"><h4 class="text-3xl font-semibold">Let&#39;s keep in touch!</h4><h5 class="text-lg mt-0 mb-2 text-gray-400"> Find us on any of these platforms, we respond 1-2 business days. </h5></div><div class="w-full lg:w-6/12 px-4"><div class="flex flex-wrap items-top mb-6"><div class="w-full lg:w-4/12 px-4 ml-auto"><span class="block uppercase dark:text-gray-100 text-gray-700 text-sm font-semibold mb-2">Follow Me</span><div class="mt-6"><a href="https://facebook.com/masumbillah21" class="bg-white text-blue-600 shadow-lg font-normal h-10 w-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2 px-3 py-2"><i class="flex fab fa-facebook-square"></i></a><a href="https://bd.linkedin.com/in/h-m-masum-billah" class="bg-white text-blue-500 shadow-lg font-normal h-10 w-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2 px-3 py-2"><i class="flex fab fa-linkedin"></i></a><a href="https://github.com/masumbillah21" class="bg-white text-black shadow-lg font-normal h-10 w-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2 px-3 py-2"><i class="flex fab fa-github"></i></a><a href="http://masum-billah.com" class="bg-white text-black shadow-lg font-normal h-10 w-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2 px-3 py-2"><i class="flex fas fa-globe"></i></a></div></div></div></div></div><hr class="my-6 border-gray-400"><div class="flex flex-wrap items-center md:justify-between justify-center"><div class="w-full md:w-4/12 px-4 mx-auto text-center"><div class="text-sm text-gray-600 font-semibold py-1"> © ${ssrInterpolate(unref(date))} JobPulse by <a href="http://www.masum-billah.com" class="text-gray-600 hover:text-gray-900">H. M. Masum Billah</a>. </div></div></div></div></footer>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "LayoutGuest",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-gray-50 dark:bg-slate-800 dark:text-slate-100" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div style="${ssrRenderStyle({ "min-height": "90vh" })}">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/LayoutGuest.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
