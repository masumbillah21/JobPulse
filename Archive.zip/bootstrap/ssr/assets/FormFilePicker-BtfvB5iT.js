import { ssrRenderAttr, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { ref, computed, watch, useSSRContext } from "vue";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
const _sfc_main = {
  __name: "FormFilePicker",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: [Object, File, Array, String],
      default: null
    },
    label: {
      type: String,
      default: null
    },
    icon: {
      type: String,
      default: "fas fa-cloud-upload-alt"
    },
    accept: {
      type: String,
      default: null
    },
    color: {
      type: String,
      default: "info"
    },
    isRoundIcon: Boolean
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const root = ref(null);
    const file = ref(props.modelValue);
    const url = ref(props.modelValue);
    if (file.value && typeof file.value === "object" && file.value instanceof File) {
      url.value = URL.createObjectURL(file.value);
    } else {
      file.value = null;
    }
    const showFilename = computed(() => !props.isRoundIcon && file.value);
    const modelValueProp = computed(() => props.modelValue);
    watch(modelValueProp, (value) => {
      file.value = value;
      if (file.value) {
        url.value = URL.createObjectURL(file.value);
      } else {
        url.value = URL.createObjectURL(url.value);
      }
      if (!value) {
        root.value.input.value = null;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (url.value) {
        _push(`<img${ssrRenderAttr("src", url.value)} alt="" class="mb-2 max-w-52">`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex items-stretch justify-start relative"><label class="inline-flex">`);
      _push(ssrRenderComponent(BaseButtonLink, {
        as: "a",
        class: { "w-12 h-12": __props.isRoundIcon, "rounded-r-none": showFilename.value },
        "icon-size": __props.isRoundIcon ? 24 : void 0,
        label: __props.isRoundIcon ? null : __props.label,
        icon: __props.icon,
        color: __props.color,
        "rounded-full": __props.isRoundIcon
      }, null, _parent));
      _push(`<input type="file" class="absolute top-0 left-0 w-full h-full opacity-0 outline-none cursor-pointer -z-1"${ssrRenderAttr("accept", __props.accept)}></label>`);
      if (showFilename.value) {
        _push(`<div class="px-4 py-2 bg-gray-100 dark:bg-slate-800 border-gray-200 dark:border-slate-700 border rounded-r"><span class="text-ellipsis line-clamp-1">${ssrInterpolate(file.value.name)}</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FormFilePicker.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const FormFilePicker = _sfc_main;
export {
  FormFilePicker as F
};
