import { defineComponent, reactive, ref, computed, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, createTextVNode, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderClass, ssrRenderList, ssrIncludeBooleanAttr, ssrInterpolate } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain, h as hasPermission } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { S as SectionTitle } from "./SectionTitle-qF5u6qV8.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import { C as CardBoxModal } from "./CardBoxModal-Ci16pu_P.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import Vue3Datatable from "@bhplugin/vue3-datatable";
/* empty css               */
import { usePage, Head, router } from "@inertiajs/vue3";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./BaseButtonLink-BG-sFKCn.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./IconRounded-RF1xkXym.js";
import "./BaseButtons-6cEMRrBZ.js";
import "./NotificationBarInCard-Dg146C8Q.js";
import "./main-C5vGb8af.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    const usersList = usePage().props.usersList;
    usersList.forEach(function(obj) {
      obj.status = obj.status == 1 ? true : false;
    });
    const params = reactive({
      current_page: 1,
      pagesize: 10,
      sort_column: "id",
      sort_direction: "asc",
      search: ""
    });
    const isModalDangerActive = ref(false);
    const cols = ref([
      { field: "sl", title: "SL", isUnique: true, type: "number", width: "50px", hide: false },
      { title: "Name", field: "name", hide: false },
      { title: "Email", field: "email", hide: false },
      { title: "Type", field: "type", hide: false },
      { title: "Status", field: "is_active", hide: false },
      { title: "Created", field: "created_at", hide: false },
      { title: "Updated", field: "updated_at", hide: false },
      { title: "Action", field: "action", hide: false }
    ]);
    const rows = ref(usersList.map((user, index) => {
      return {
        sl: index + 1,
        id: user.id,
        name: user.name,
        email: user.email,
        type: user.user_type,
        status: user.is_active == 1 ? true : false,
        is_active: user.is_active == 1 ? "Active" : "Inactive",
        created_at: user.created_at,
        updated_at: user.updated_at
      };
    }));
    const isOpen = ref(false);
    const userId = ref("");
    const changeStatus = () => {
      isModalDangerActive.value = false;
      router.get(route("admin.users.status", userId.value));
    };
    const showModle = (id) => {
      isModalDangerActive.value = true;
      userId.value = id;
    };
    const filterdJobList = computed(() => {
      if (!params.search)
        return usersList.slice(0, params.pagesize);
      const query = params.search.toLowerCase();
      return usersList == null ? void 0 : usersList.filter((item) => item.name.toLowerCase().includes(query));
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "User List" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitle, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: "User List",
                    main: ""
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBoxModal, {
                    modelValue: isModalDangerActive.value,
                    "onUpdate:modelValue": ($event) => isModalDangerActive.value = $event,
                    title: "Warning",
                    button: "danger",
                    onConfirm: changeStatus,
                    buttonLabel: "Change",
                    "has-cancel": ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<p${_scopeId3}>Do you really want to change status?</p>`);
                      } else {
                        return [
                          createVNode("p", null, "Do you really want to change status?")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, {
                    class: "mb-6 relative overflow-x-auto shadow-md sm:rounded-lg",
                    "has-table": ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormSuccess, { class: "pt-5 pl-5" }, null, _parent4, _scopeId3));
                        _push4(`<div class="flex justify-between px-3 pt-4"${_scopeId3}><div class="mb-5 relative"${_scopeId3}><button type="button" class="bg-slate-800 text-white p-2 inline-block rounded"${_scopeId3}> Column Compose <i class="${ssrRenderClass(isOpen.value ? "fa fa-chevron-up" : "fa fa-chevron-down")}" aria-hidden="true"${_scopeId3}></i></button>`);
                        if (isOpen.value) {
                          _push4(`<ul class="absolute left-0 mt-0.5 p-2.5 min-w-[150px] bg-white rounded shadow-md space-y-1 z-10"${_scopeId3}><!--[-->`);
                          ssrRenderList(cols.value, (col) => {
                            _push4(`<li${_scopeId3}><label class="flex items-center gap-2 w-full cursor-pointer text-gray-600 hover:text-black"${_scopeId3}><input type="checkbox" class="form-checkbox"${ssrIncludeBooleanAttr(!col.hide) ? " checked" : ""}${_scopeId3}><span${_scopeId3}>${ssrInterpolate(col.title)}</span></label></li>`);
                          });
                          _push4(`<!--]--></ul>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`</div>`);
                        _push4(ssrRenderComponent(FormControl, {
                          modelValue: params.search,
                          "onUpdate:modelValue": ($event) => params.search = $event,
                          type: "text",
                          placeholder: "Search..."
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                        _push4(ssrRenderComponent(unref(Vue3Datatable), {
                          rows: rows.value,
                          columns: cols.value,
                          sortable: true,
                          sortColumn: params.sort_column,
                          sortDirection: params.sort_direction,
                          search: params.search,
                          columnFilter: true,
                          onChange: filterdJobList.value,
                          cloneHeaderInFooter: true,
                          skin: "bh-table-compact",
                          class: "column-filter p-4",
                          rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                        }, {
                          action: withCtx((data, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<template class="flex"${_scopeId4}>`);
                              if (unref(hasPermission)("users.list.status")) {
                                _push5(ssrRenderComponent(FormCheckRadioGroup, {
                                  modelValue: data.value.status,
                                  "onUpdate:modelValue": ($event) => data.value.status = $event,
                                  name: "status",
                                  type: "switch",
                                  options: { 1: "Active" },
                                  onClick: ($event) => showModle(data.value.id)
                                }, null, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                              _push5(`</template>`);
                            } else {
                              return [
                                createVNode("template", { class: "flex" }, [
                                  unref(hasPermission)("users.list.status") ? (openBlock(), createBlock(FormCheckRadioGroup, {
                                    key: 0,
                                    modelValue: data.value.status,
                                    "onUpdate:modelValue": ($event) => data.value.status = $event,
                                    name: "status",
                                    type: "switch",
                                    options: { 1: "Active" },
                                    onClick: ($event) => showModle(data.value.id)
                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "onClick"])) : createCommentVNode("", true)
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess, { class: "pt-5 pl-5" }),
                          createVNode("div", { class: "flex justify-between px-3 pt-4" }, [
                            createVNode("div", { class: "mb-5 relative" }, [
                              createVNode("button", {
                                type: "button",
                                class: "bg-slate-800 text-white p-2 inline-block rounded",
                                onClick: ($event) => isOpen.value = !isOpen.value
                              }, [
                                createTextVNode(" Column Compose "),
                                createVNode("i", {
                                  class: isOpen.value ? "fa fa-chevron-up" : "fa fa-chevron-down",
                                  "aria-hidden": "true"
                                }, null, 2)
                              ], 8, ["onClick"]),
                              isOpen.value ? (openBlock(), createBlock("ul", {
                                key: 0,
                                class: "absolute left-0 mt-0.5 p-2.5 min-w-[150px] bg-white rounded shadow-md space-y-1 z-10"
                              }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(cols.value, (col) => {
                                  return openBlock(), createBlock("li", {
                                    key: col.field
                                  }, [
                                    createVNode("label", { class: "flex items-center gap-2 w-full cursor-pointer text-gray-600 hover:text-black" }, [
                                      createVNode("input", {
                                        type: "checkbox",
                                        class: "form-checkbox",
                                        checked: !col.hide,
                                        onChange: ($event) => {
                                          var _a;
                                          return col.hide = !((_a = $event.target) == null ? void 0 : _a.checked);
                                        }
                                      }, null, 40, ["checked", "onChange"]),
                                      createVNode("span", null, toDisplayString(col.title), 1)
                                    ])
                                  ]);
                                }), 128))
                              ])) : createCommentVNode("", true)
                            ]),
                            createVNode(FormControl, {
                              modelValue: params.search,
                              "onUpdate:modelValue": ($event) => params.search = $event,
                              type: "text",
                              placeholder: "Search..."
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode(unref(Vue3Datatable), {
                            rows: rows.value,
                            columns: cols.value,
                            sortable: true,
                            sortColumn: params.sort_column,
                            sortDirection: params.sort_direction,
                            search: params.search,
                            columnFilter: true,
                            onChange: filterdJobList.value,
                            cloneHeaderInFooter: true,
                            skin: "bh-table-compact",
                            class: "column-filter p-4",
                            rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                          }, {
                            action: withCtx((data) => [
                              createVNode("template", { class: "flex" }, [
                                unref(hasPermission)("users.list.status") ? (openBlock(), createBlock(FormCheckRadioGroup, {
                                  key: 0,
                                  modelValue: data.value.status,
                                  "onUpdate:modelValue": ($event) => data.value.status = $event,
                                  name: "status",
                                  type: "switch",
                                  options: { 1: "Active" },
                                  onClick: ($event) => showModle(data.value.id)
                                }, null, 8, ["modelValue", "onUpdate:modelValue", "onClick"])) : createCommentVNode("", true)
                              ])
                            ]),
                            _: 1
                          }, 8, ["rows", "columns", "sortColumn", "sortDirection", "search", "onChange"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(SectionTitle, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: "User List",
                      main: ""
                    }),
                    createVNode(CardBoxModal, {
                      modelValue: isModalDangerActive.value,
                      "onUpdate:modelValue": ($event) => isModalDangerActive.value = $event,
                      title: "Warning",
                      button: "danger",
                      onConfirm: changeStatus,
                      buttonLabel: "Change",
                      "has-cancel": ""
                    }, {
                      default: withCtx(() => [
                        createVNode("p", null, "Do you really want to change status?")
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(CardBox, {
                      class: "mb-6 relative overflow-x-auto shadow-md sm:rounded-lg",
                      "has-table": ""
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormSuccess, { class: "pt-5 pl-5" }),
                        createVNode("div", { class: "flex justify-between px-3 pt-4" }, [
                          createVNode("div", { class: "mb-5 relative" }, [
                            createVNode("button", {
                              type: "button",
                              class: "bg-slate-800 text-white p-2 inline-block rounded",
                              onClick: ($event) => isOpen.value = !isOpen.value
                            }, [
                              createTextVNode(" Column Compose "),
                              createVNode("i", {
                                class: isOpen.value ? "fa fa-chevron-up" : "fa fa-chevron-down",
                                "aria-hidden": "true"
                              }, null, 2)
                            ], 8, ["onClick"]),
                            isOpen.value ? (openBlock(), createBlock("ul", {
                              key: 0,
                              class: "absolute left-0 mt-0.5 p-2.5 min-w-[150px] bg-white rounded shadow-md space-y-1 z-10"
                            }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(cols.value, (col) => {
                                return openBlock(), createBlock("li", {
                                  key: col.field
                                }, [
                                  createVNode("label", { class: "flex items-center gap-2 w-full cursor-pointer text-gray-600 hover:text-black" }, [
                                    createVNode("input", {
                                      type: "checkbox",
                                      class: "form-checkbox",
                                      checked: !col.hide,
                                      onChange: ($event) => {
                                        var _a;
                                        return col.hide = !((_a = $event.target) == null ? void 0 : _a.checked);
                                      }
                                    }, null, 40, ["checked", "onChange"]),
                                    createVNode("span", null, toDisplayString(col.title), 1)
                                  ])
                                ]);
                              }), 128))
                            ])) : createCommentVNode("", true)
                          ]),
                          createVNode(FormControl, {
                            modelValue: params.search,
                            "onUpdate:modelValue": ($event) => params.search = $event,
                            type: "text",
                            placeholder: "Search..."
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        createVNode(unref(Vue3Datatable), {
                          rows: rows.value,
                          columns: cols.value,
                          sortable: true,
                          sortColumn: params.sort_column,
                          sortDirection: params.sort_direction,
                          search: params.search,
                          columnFilter: true,
                          onChange: filterdJobList.value,
                          cloneHeaderInFooter: true,
                          skin: "bh-table-compact",
                          class: "column-filter p-4",
                          rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                        }, {
                          action: withCtx((data) => [
                            createVNode("template", { class: "flex" }, [
                              unref(hasPermission)("users.list.status") ? (openBlock(), createBlock(FormCheckRadioGroup, {
                                key: 0,
                                modelValue: data.value.status,
                                "onUpdate:modelValue": ($event) => data.value.status = $event,
                                name: "status",
                                type: "switch",
                                options: { 1: "Active" },
                                onClick: ($event) => showModle(data.value.id)
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "onClick"])) : createCommentVNode("", true)
                            ])
                          ]),
                          _: 1
                        }, 8, ["rows", "columns", "sortColumn", "sortDirection", "search", "onChange"])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "User List" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitle, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: "User List",
                    main: ""
                  }),
                  createVNode(CardBoxModal, {
                    modelValue: isModalDangerActive.value,
                    "onUpdate:modelValue": ($event) => isModalDangerActive.value = $event,
                    title: "Warning",
                    button: "danger",
                    onConfirm: changeStatus,
                    buttonLabel: "Change",
                    "has-cancel": ""
                  }, {
                    default: withCtx(() => [
                      createVNode("p", null, "Do you really want to change status?")
                    ]),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(CardBox, {
                    class: "mb-6 relative overflow-x-auto shadow-md sm:rounded-lg",
                    "has-table": ""
                  }, {
                    default: withCtx(() => [
                      createVNode(FormValidationErrors),
                      createVNode(FormSuccess, { class: "pt-5 pl-5" }),
                      createVNode("div", { class: "flex justify-between px-3 pt-4" }, [
                        createVNode("div", { class: "mb-5 relative" }, [
                          createVNode("button", {
                            type: "button",
                            class: "bg-slate-800 text-white p-2 inline-block rounded",
                            onClick: ($event) => isOpen.value = !isOpen.value
                          }, [
                            createTextVNode(" Column Compose "),
                            createVNode("i", {
                              class: isOpen.value ? "fa fa-chevron-up" : "fa fa-chevron-down",
                              "aria-hidden": "true"
                            }, null, 2)
                          ], 8, ["onClick"]),
                          isOpen.value ? (openBlock(), createBlock("ul", {
                            key: 0,
                            class: "absolute left-0 mt-0.5 p-2.5 min-w-[150px] bg-white rounded shadow-md space-y-1 z-10"
                          }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(cols.value, (col) => {
                              return openBlock(), createBlock("li", {
                                key: col.field
                              }, [
                                createVNode("label", { class: "flex items-center gap-2 w-full cursor-pointer text-gray-600 hover:text-black" }, [
                                  createVNode("input", {
                                    type: "checkbox",
                                    class: "form-checkbox",
                                    checked: !col.hide,
                                    onChange: ($event) => {
                                      var _a;
                                      return col.hide = !((_a = $event.target) == null ? void 0 : _a.checked);
                                    }
                                  }, null, 40, ["checked", "onChange"]),
                                  createVNode("span", null, toDisplayString(col.title), 1)
                                ])
                              ]);
                            }), 128))
                          ])) : createCommentVNode("", true)
                        ]),
                        createVNode(FormControl, {
                          modelValue: params.search,
                          "onUpdate:modelValue": ($event) => params.search = $event,
                          type: "text",
                          placeholder: "Search..."
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode(unref(Vue3Datatable), {
                        rows: rows.value,
                        columns: cols.value,
                        sortable: true,
                        sortColumn: params.sort_column,
                        sortDirection: params.sort_direction,
                        search: params.search,
                        columnFilter: true,
                        onChange: filterdJobList.value,
                        cloneHeaderInFooter: true,
                        skin: "bh-table-compact",
                        class: "column-filter p-4",
                        rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                      }, {
                        action: withCtx((data) => [
                          createVNode("template", { class: "flex" }, [
                            unref(hasPermission)("users.list.status") ? (openBlock(), createBlock(FormCheckRadioGroup, {
                              key: 0,
                              modelValue: data.value.status,
                              "onUpdate:modelValue": ($event) => data.value.status = $event,
                              name: "status",
                              type: "switch",
                              options: { 1: "Active" },
                              onClick: ($event) => showModle(data.value.id)
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "onClick"])) : createCommentVNode("", true)
                          ])
                        ]),
                        _: 1
                      }, 8, ["rows", "columns", "sortColumn", "sortDirection", "search", "onChange"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Users/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
