import { defineComponent, withCtx, createVNode, openBlock, createBlock, createCommentVNode, unref, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderStyle, ssrRenderAttr } from "vue/server-renderer";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { F as FormFilePicker } from "./FormFilePicker-BtfvB5iT.js";
import { usePage } from "@inertiajs/vue3";
import "./main-C5vGb8af.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./IconRounded-RF1xkXym.js";
import "./colors-K3EOgMMA.js";
import "./isSystemUser-D-zJOoLX.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Home",
  __ssrInlineRender: true,
  props: {
    row: {
      type: Object,
      required: true
    },
    sectionIndex: {
      type: Number,
      required: true
    }
  },
  emits: ["toggleSection", "addRow", "removeRow"],
  setup(__props, { emit: __emit }) {
    const urls = usePage().props.urls;
    const emit = __emit;
    const onAddRow = (sectionIndex) => {
      emit("addRow", sectionIndex);
    };
    const onRemoveRow = (sectionIndex, rowIndex) => {
      emit("removeRow", sectionIndex, rowIndex);
    };
    const onToggleSection = (sectionIndex) => {
      emit("toggleSection", sectionIndex);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(SectionTitleLineWithButton, {
        title: __props.row.name,
        main: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(BaseButtonLink, {
              class: "mr-1",
              icon: __props.row.hidden ? "fas fa-chevron-up" : "fas fa-chevron-down",
              onClick: ($event) => onToggleSection(__props.sectionIndex),
              label: __props.row.hidden ? "Show" : "Hide",
              color: "contrast",
              "rounded-full": "",
              small: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(BaseButtonLink, {
                class: "mr-1",
                icon: __props.row.hidden ? "fas fa-chevron-up" : "fas fa-chevron-down",
                onClick: ($event) => onToggleSection(__props.sectionIndex),
                label: __props.row.hidden ? "Show" : "Hide",
                color: "contrast",
                "rounded-full": "",
                small: ""
              }, null, 8, ["icon", "onClick", "label"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(__props.row.data, (data, rowIndex) => {
        _push(`<div style="${ssrRenderStyle(!__props.row.hidden ? null : { display: "none" })}" class="mb-2 flex-col justify-end items-end h-full"><div class="w-full mb-7 p-5 dark:bg-slate-900 bg-gray-100 rounded">`);
        if (__props.row.slug === "slider") {
          _push(ssrRenderComponent(BaseButtons, { class: "mt-auto justify-end" }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(BaseButtonLink, {
                  class: "mr-1",
                  icon: "fas fa-plus",
                  onClick: ($event) => onAddRow(__props.sectionIndex),
                  label: "Add Row",
                  color: "contrast",
                  "rounded-full": "",
                  small: ""
                }, null, _parent2, _scopeId));
                if (rowIndex > 0) {
                  _push2(ssrRenderComponent(BaseButtonLink, {
                    icon: "fas fa-minus",
                    onClick: ($event) => onRemoveRow(__props.sectionIndex, rowIndex),
                    label: "Remove Row",
                    color: "danger",
                    "rounded-full": "",
                    small: ""
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
              } else {
                return [
                  createVNode(BaseButtonLink, {
                    class: "mr-1",
                    icon: "fas fa-plus",
                    onClick: ($event) => onAddRow(__props.sectionIndex),
                    label: "Add Row",
                    color: "contrast",
                    "rounded-full": "",
                    small: ""
                  }, null, 8, ["onClick"]),
                  rowIndex > 0 ? (openBlock(), createBlock(BaseButtonLink, {
                    key: 0,
                    icon: "fas fa-minus",
                    onClick: ($event) => onRemoveRow(__props.sectionIndex, rowIndex),
                    label: "Remove Row",
                    color: "danger",
                    "rounded-full": "",
                    small: ""
                  }, null, 8, ["onClick"])) : createCommentVNode("", true)
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(ssrRenderComponent(FormField, {
          label: "Title: " + data.title,
          "label-for": "headline-" + (rowIndex + __props.sectionIndex)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(FormControl, {
                modelValue: data.title,
                "onUpdate:modelValue": ($event) => data.title = $event,
                id: "headline-" + (rowIndex + __props.sectionIndex),
                placeholder: "Title here",
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(FormControl, {
                  modelValue: data.title,
                  "onUpdate:modelValue": ($event) => data.title = $event,
                  id: "headline-" + (rowIndex + __props.sectionIndex),
                  placeholder: "Title here",
                  type: "text",
                  required: ""
                }, null, 8, ["modelValue", "onUpdate:modelValue", "id"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(FormField, {
          label: "Subtitle",
          "label-for": "subtitle-" + (rowIndex + __props.sectionIndex)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(FormControl, {
                modelValue: data.subtitle,
                "onUpdate:modelValue": ($event) => data.subtitle = $event,
                id: "subtitle-" + (rowIndex + __props.sectionIndex),
                placeholder: "Subtitle here",
                type: "text"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(FormControl, {
                  modelValue: data.subtitle,
                  "onUpdate:modelValue": ($event) => data.subtitle = $event,
                  id: "subtitle-" + (rowIndex + __props.sectionIndex),
                  placeholder: "Subtitle here",
                  type: "text"
                }, null, 8, ["modelValue", "onUpdate:modelValue", "id"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(FormField, {
          label: "Description",
          "label-for": "description-" + (rowIndex + __props.sectionIndex)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(FormControl, {
                modelValue: data.description,
                "onUpdate:modelValue": ($event) => data.description = $event,
                id: "description-" + (rowIndex + __props.sectionIndex),
                placeholder: "Description here",
                type: "textarea",
                required: ""
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(FormControl, {
                  modelValue: data.description,
                  "onUpdate:modelValue": ($event) => data.description = $event,
                  id: "description-" + (rowIndex + __props.sectionIndex),
                  placeholder: "Description here",
                  type: "textarea",
                  required: ""
                }, null, 8, ["modelValue", "onUpdate:modelValue", "id"])
              ];
            }
          }),
          _: 2
        }, _parent));
        if (data.oldImage) {
          _push(`<img${ssrRenderAttr("src", `${unref(urls).storeUrl}/${data.oldImage}`)} width="300" class="block">`);
        } else {
          _push(`<!---->`);
        }
        if (__props.row.slug === "slider") {
          _push(ssrRenderComponent(FormField, {
            label: "Image",
            help: "Max 500kb"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(FormFilePicker, {
                  key: data.imageKey,
                  label: "Upload Image",
                  modelValue: data.image,
                  color: "success",
                  "onUpdate:modelValue": ($event) => data.image = $event
                }, null, _parent2, _scopeId));
              } else {
                return [
                  (openBlock(), createBlock(FormFilePicker, {
                    key: data.imageKey,
                    label: "Upload Image",
                    modelValue: data.image,
                    color: "success",
                    "onUpdate:modelValue": ($event) => data.image = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]))
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      });
      _push(`<!--]--><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Pages/Parts/Home.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
