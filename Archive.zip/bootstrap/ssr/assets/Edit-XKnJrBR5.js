import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { S as SectionTitle } from "./SectionTitle-qF5u6qV8.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { F as FormFilePicker } from "./FormFilePicker-BtfvB5iT.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { i as isSystemUser } from "./isSystemUser-D-zJOoLX.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./IconRounded-RF1xkXym.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  setup(__props) {
    const companyData = usePage().props.companyData;
    const companyTypes = [
      { id: "", label: "Select Company Type" },
      { id: "Business development", label: "Business development" },
      { id: "Marketing", label: "Marketing" },
      { id: "Sales", label: "Sales" },
      { id: "Tech", label: "Tech" }
    ];
    const companySize = [
      { id: "", label: "Select Company Size" },
      { id: "0-10 Employees", label: "0-10 Employees" },
      { id: "11-20 Employees", label: "11-20 Employees" },
      { id: "21-30 Employees", label: "21-30 Employees" },
      { id: "31-40 Employees", label: "31-40 Employees" },
      { id: "41-50 Employees", label: "41-50 Employees" }
    ];
    let form = useForm({
      "id": 0,
      "name": "",
      "description": "",
      "company_type": "",
      "address": "",
      "phone": "",
      "email": "",
      "company_size": "",
      "website": "",
      "logo": "",
      _method: "post"
    });
    if (companyData != null) {
      form.id = companyData.id;
      form.name = companyData.name;
      form.description = companyData.description;
      form.company_type = companyData.company_type;
      form.address = companyData.address;
      form.phone = companyData.phone;
      form.email = companyData.email;
      form.company_size = companyData.company_size;
      form.website = companyData.website;
      form._method = "put";
    }
    const submit = () => {
      if (form.id == 0) {
        create();
      } else {
        update();
      }
    };
    const create = () => {
      const routeName = isSystemUser() ? "admin.company.store" : "company.store";
      form.post(route(routeName), {
        onSuccess: () => form.reset()
      });
    };
    const update = () => {
      const routeName = isSystemUser() ? "admin.company.update" : "company.update";
      form.post(route(routeName, form.id));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Company" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitle, {
                    title: "Company Profile",
                    icon: "far fa-arrow-alt-circle-right"
                  }, null, _parent3, _scopeId2));
                  _push3(`<div class="flex justify-center items-center"${_scopeId2}>`);
                  _push3(ssrRenderComponent(CardBox, {
                    class: "my-24 w-1/2",
                    "is-form": "",
                    onSubmit: submit
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormSuccess, null, null, _parent4, _scopeId3));
                        if (unref(companyData) && unref(companyData).logo) {
                          _push4(`<div class="mb-10"${_scopeId3}><img${ssrRenderAttr("src", unref(companyData).logo)} width="300"${_scopeId3}></div>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(ssrRenderComponent(FormField, {
                          label: "Name",
                          "label-for": "name",
                          help: "Please enter your company name"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                icon: "fas fa-user",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).name,
                                  "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                  id: "name",
                                  icon: "fas fa-user",
                                  autocomplete: "name",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Description",
                          "label-for": "description",
                          help: "Please enter your company description"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).description,
                                "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                id: "description",
                                icon: "fas fa-info",
                                autocomplete: "description",
                                type: "text",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).description,
                                  "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                  id: "description",
                                  icon: "fas fa-info",
                                  autocomplete: "description",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, { label: "Company type" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).company_type,
                                "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                icon: "fas fa-list",
                                options: companyTypes
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).company_type,
                                  "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                  icon: "fas fa-list",
                                  options: companyTypes
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Address",
                          "label-for": "address",
                          help: "Please enter your company address"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).address,
                                "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                id: "address",
                                icon: "fas fa-map-marker",
                                autocomplete: "address",
                                type: "address",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).address,
                                  "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                  id: "address",
                                  icon: "fas fa-map-marker",
                                  autocomplete: "address",
                                  type: "address",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Phone Number",
                          "label-for": "phone",
                          help: "Please enter your company phone"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).phone,
                                "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                id: "phone",
                                icon: "fas fa-phone",
                                autocomplete: "phone",
                                type: "tel",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).phone,
                                  "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                  id: "phone",
                                  icon: "fas fa-phone",
                                  autocomplete: "phone",
                                  type: "tel",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Email",
                          "label-for": "email",
                          help: "Please enter your email"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).email,
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                id: "email",
                                icon: "fas fa-envelope",
                                autocomplete: "email",
                                type: "email",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).email,
                                  "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                  id: "email",
                                  icon: "fas fa-envelope",
                                  autocomplete: "email",
                                  type: "email",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, { label: "Company Size" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).company_size,
                                "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                icon: "fas fa-list",
                                options: companySize
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).company_size,
                                  "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                  icon: "fas fa-list",
                                  options: companySize
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Website",
                          "label-for": "website",
                          help: "Please enter company website"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).website,
                                "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                id: "website",
                                icon: "fas fa-globe",
                                type: "url",
                                autocomplete: "website"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).website,
                                  "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                  id: "website",
                                  icon: "fas fa-globe",
                                  type: "url",
                                  autocomplete: "website"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Logo",
                          help: "Max 500kb"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormFilePicker, {
                                label: "Upload Logo",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).logo = $event
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormFilePicker, {
                                  label: "Upload Logo",
                                  color: "success",
                                  "onUpdate:modelValue": ($event) => unref(form).logo = $event
                                }, null, 8, ["onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtons, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: "Update",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(BaseButtonLink, {
                                  type: "submit",
                                  color: "info",
                                  label: "Update",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["class", "disabled"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          unref(companyData) && unref(companyData).logo ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mb-10"
                          }, [
                            createVNode("img", {
                              src: unref(companyData).logo,
                              width: "300"
                            }, null, 8, ["src"])
                          ])) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Name",
                            "label-for": "name",
                            help: "Please enter your company name"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                icon: "fas fa-user",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Description",
                            "label-for": "description",
                            help: "Please enter your company description"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).description,
                                "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                id: "description",
                                icon: "fas fa-info",
                                autocomplete: "description",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Company type" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).company_type,
                                "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                icon: "fas fa-list",
                                options: companyTypes
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Address",
                            "label-for": "address",
                            help: "Please enter your company address"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).address,
                                "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                id: "address",
                                icon: "fas fa-map-marker",
                                autocomplete: "address",
                                type: "address",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Phone Number",
                            "label-for": "phone",
                            help: "Please enter your company phone"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).phone,
                                "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                id: "phone",
                                icon: "fas fa-phone",
                                autocomplete: "phone",
                                type: "tel",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Email",
                            "label-for": "email",
                            help: "Please enter your email"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).email,
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                id: "email",
                                icon: "fas fa-envelope",
                                autocomplete: "email",
                                type: "email",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Company Size" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).company_size,
                                "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                icon: "fas fa-list",
                                options: companySize
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Website",
                            "label-for": "website",
                            help: "Please enter company website"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).website,
                                "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                id: "website",
                                icon: "fas fa-globe",
                                type: "url",
                                autocomplete: "website"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Logo",
                            help: "Max 500kb"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormFilePicker, {
                                label: "Upload Logo",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).logo = $event
                              }, null, 8, ["onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: "Update",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["class", "disabled"])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitle, {
                      title: "Company Profile",
                      icon: "far fa-arrow-alt-circle-right"
                    }),
                    createVNode("div", { class: "flex justify-center items-center" }, [
                      createVNode(CardBox, {
                        class: "my-24 w-1/2",
                        "is-form": "",
                        onSubmit: withModifiers(submit, ["prevent"])
                      }, {
                        default: withCtx(() => [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          unref(companyData) && unref(companyData).logo ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mb-10"
                          }, [
                            createVNode("img", {
                              src: unref(companyData).logo,
                              width: "300"
                            }, null, 8, ["src"])
                          ])) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Name",
                            "label-for": "name",
                            help: "Please enter your company name"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                icon: "fas fa-user",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Description",
                            "label-for": "description",
                            help: "Please enter your company description"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).description,
                                "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                id: "description",
                                icon: "fas fa-info",
                                autocomplete: "description",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Company type" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).company_type,
                                "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                icon: "fas fa-list",
                                options: companyTypes
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Address",
                            "label-for": "address",
                            help: "Please enter your company address"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).address,
                                "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                id: "address",
                                icon: "fas fa-map-marker",
                                autocomplete: "address",
                                type: "address",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Phone Number",
                            "label-for": "phone",
                            help: "Please enter your company phone"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).phone,
                                "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                id: "phone",
                                icon: "fas fa-phone",
                                autocomplete: "phone",
                                type: "tel",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Email",
                            "label-for": "email",
                            help: "Please enter your email"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).email,
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                id: "email",
                                icon: "fas fa-envelope",
                                autocomplete: "email",
                                type: "email",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Company Size" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).company_size,
                                "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                icon: "fas fa-list",
                                options: companySize
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Website",
                            "label-for": "website",
                            help: "Please enter company website"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).website,
                                "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                id: "website",
                                icon: "fas fa-globe",
                                type: "url",
                                autocomplete: "website"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Logo",
                            help: "Max 500kb"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormFilePicker, {
                                label: "Upload Logo",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).logo = $event
                              }, null, 8, ["onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: "Update",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["class", "disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Company" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitle, {
                    title: "Company Profile",
                    icon: "far fa-arrow-alt-circle-right"
                  }),
                  createVNode("div", { class: "flex justify-center items-center" }, [
                    createVNode(CardBox, {
                      class: "my-24 w-1/2",
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormSuccess),
                        unref(companyData) && unref(companyData).logo ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "mb-10"
                        }, [
                          createVNode("img", {
                            src: unref(companyData).logo,
                            width: "300"
                          }, null, 8, ["src"])
                        ])) : createCommentVNode("", true),
                        createVNode(FormField, {
                          label: "Name",
                          "label-for": "name",
                          help: "Please enter your company name"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).name,
                              "onUpdate:modelValue": ($event) => unref(form).name = $event,
                              id: "name",
                              icon: "fas fa-user",
                              autocomplete: "name",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Description",
                          "label-for": "description",
                          help: "Please enter your company description"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).description,
                              "onUpdate:modelValue": ($event) => unref(form).description = $event,
                              id: "description",
                              icon: "fas fa-info",
                              autocomplete: "description",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, { label: "Company type" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).company_type,
                              "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                              icon: "fas fa-list",
                              options: companyTypes
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Address",
                          "label-for": "address",
                          help: "Please enter your company address"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).address,
                              "onUpdate:modelValue": ($event) => unref(form).address = $event,
                              id: "address",
                              icon: "fas fa-map-marker",
                              autocomplete: "address",
                              type: "address",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Phone Number",
                          "label-for": "phone",
                          help: "Please enter your company phone"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).phone,
                              "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                              id: "phone",
                              icon: "fas fa-phone",
                              autocomplete: "phone",
                              type: "tel",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Email",
                          "label-for": "email",
                          help: "Please enter your email"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).email,
                              "onUpdate:modelValue": ($event) => unref(form).email = $event,
                              id: "email",
                              icon: "fas fa-envelope",
                              autocomplete: "email",
                              type: "email",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, { label: "Company Size" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).company_size,
                              "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                              icon: "fas fa-list",
                              options: companySize
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Website",
                          "label-for": "website",
                          help: "Please enter company website"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).website,
                              "onUpdate:modelValue": ($event) => unref(form).website = $event,
                              id: "website",
                              icon: "fas fa-globe",
                              type: "url",
                              autocomplete: "website"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Logo",
                          help: "Max 500kb"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormFilePicker, {
                              label: "Upload Logo",
                              color: "success",
                              "onUpdate:modelValue": ($event) => unref(form).logo = $event
                            }, null, 8, ["onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(BaseDivider),
                        createVNode(BaseButtons, null, {
                          default: withCtx(() => [
                            createVNode(BaseButtonLink, {
                              type: "submit",
                              color: "info",
                              label: "Update",
                              class: { "opacity-25": unref(form).processing },
                              disabled: unref(form).processing
                            }, null, 8, ["class", "disabled"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Company/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
