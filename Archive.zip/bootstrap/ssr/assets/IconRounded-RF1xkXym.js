import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { a as colorsBgLight, b as colorsText } from "./colors-K3EOgMMA.js";
import { _ as _sfc_main$1 } from "./BaseIcon-C4zrUKd9.js";
const _sfc_main = {
  __name: "IconRounded",
  __ssrInlineRender: true,
  props: {
    icon: {
      type: String,
      required: true
    },
    color: {
      type: String,
      default: null
    },
    w: {
      type: String,
      default: "w-12"
    },
    h: {
      type: String,
      default: "h-12"
    },
    bg: Boolean
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, mergeProps({
        path: __props.icon,
        w: __props.w,
        h: __props.h,
        size: "24",
        class: ["rounded-full", __props.bg ? unref(colorsBgLight)[__props.color] : [unref(colorsText)[__props.color], "bg-gray-50 dark:bg-slate-800"]]
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/IconRounded.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
