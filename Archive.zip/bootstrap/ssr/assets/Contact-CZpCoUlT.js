import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { C as ComingSoon } from "./ComingSoon-DuRr8gR7.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./NotificationBarInCard-Dg146C8Q.js";
import "./colors-K3EOgMMA.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Contact",
  __ssrInlineRender: true,
  props: {
    storageUrl: String
  },
  setup(__props) {
    const contactPageData = usePage().props.contactPageData;
    const form = useForm({
      name: "",
      email: "",
      subject: "",
      message: ""
    });
    const contactContent = {
      banner: "",
      contact_info: ""
    };
    if (contactPageData) {
      contactPageData.contents.forEach((item) => {
        if (item.slug === "banner") {
          contactContent.banner = item.data[0];
        }
        if (item.slug === "contact_info") {
          contactContent.contact_info = item.data;
        }
      });
    }
    const submit = () => {
      form.post(route("contact.email"), {
        onSuccess: () => {
          form.reset();
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(contactPageData).title ?? "Contact"
            }, null, _parent2, _scopeId));
            if (unref(contactPageData)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                bgImage: unref(contactPageData).featured_image
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: unref(contactPageData).title
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: unref(contactPageData).title
                      }, null, 8, ["title"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<section class="pb-20 relative block dark:bg-gray-900"${_scopeId}><div class="container mx-auto px-4 lg:pt-24 lg:pb-64"${_scopeId}><div class="flex flex-wrap text-center justify-center"${_scopeId}><div class="w-full lg:w-6/12 px-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                title: contactContent.banner.title,
                description: contactContent.banner.description,
                subtitle: contactContent.banner.subtitle
              }, null, _parent2, _scopeId));
              _push2(`</div></div><div class="flex flex-wrap"${_scopeId}><!--[-->`);
              ssrRenderList(contactContent.contact_info, (item) => {
                _push2(`<div class="lg:pt-12 pt-6 w-full md:w-4/12 px-4 text-center"${_scopeId}><div class="relative flex flex-col min-w-0 break-words bg-white w-full mb-8 shadow-lg rounded-lg"${_scopeId}><div class="px-4 py-5 flex-auto"${_scopeId}><div class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 mb-5 shadow-lg rounded-full bg-red-400"${_scopeId}><i class="${ssrRenderClass(item.icon)}"${_scopeId}></i></div><h6 class="text-xl font-semibold text-stone-900"${_scopeId}>${ssrInterpolate(item.title)}</h6><p class="mt-2 mb-4 text-gray-600"${_scopeId}>${ssrInterpolate(item.info)}</p></div></div></div>`);
              });
              _push2(`<!--]--></div></div></section><section class="relative block py-24 lg:pt-0 dark:bg-gray-900 dark:text-slate-800"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="flex flex-wrap justify-center lg:-mt-64 -mt-48"${_scopeId}><div class="w-full lg:w-6/12 px-4"${_scopeId}>`);
              _push2(ssrRenderComponent(CardBox, {
                class: "my-24 bg-white dark:bg-white",
                "is-form": "",
                onSubmit: submit
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(FormValidationErrors, null, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(FormSuccess, null, null, _parent3, _scopeId2));
                    _push3(`<h4 class="text-2xl font-semibold text-slate-800"${_scopeId2}>Want to work with us?</h4><p class="leading-relaxed mt-1 mb-4 text-gray-600"${_scopeId2}> Complete this form and we will get back to you in 24 hours. </p>`);
                    _push3(ssrRenderComponent(FormField, {
                      label: "Full Name",
                      "label-for": "name",
                      help: "Please enter your full name"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(FormControl, {
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            id: "name",
                            icon: "fas fa-user",
                            type: "text",
                            required: ""
                          }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(FormControl, {
                              modelValue: unref(form).name,
                              "onUpdate:modelValue": ($event) => unref(form).name = $event,
                              id: "name",
                              icon: "fas fa-user",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(FormField, {
                      label: "Email",
                      "label-for": "email",
                      help: "Please enter your email"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(FormControl, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            id: "email",
                            icon: "fas fa-envelope",
                            type: "email",
                            required: ""
                          }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(FormControl, {
                              modelValue: unref(form).email,
                              "onUpdate:modelValue": ($event) => unref(form).email = $event,
                              id: "email",
                              icon: "fas fa-envelope",
                              type: "email",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(FormField, {
                      label: "Subject",
                      "label-for": "subject",
                      help: "Please enter your subject"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(FormControl, {
                            modelValue: unref(form).subject,
                            "onUpdate:modelValue": ($event) => unref(form).subject = $event,
                            id: "subject",
                            icon: "fas fa-sticky-note",
                            type: "text",
                            required: ""
                          }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(FormControl, {
                              modelValue: unref(form).subject,
                              "onUpdate:modelValue": ($event) => unref(form).subject = $event,
                              id: "subject",
                              icon: "fas fa-sticky-note",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(FormField, {
                      label: "Message",
                      "label-for": "message",
                      help: "Please enter your message"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(FormControl, {
                            modelValue: unref(form).message,
                            "onUpdate:modelValue": ($event) => unref(form).message = $event,
                            id: "message",
                            type: "textarea",
                            required: ""
                          }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(FormControl, {
                              modelValue: unref(form).message,
                              "onUpdate:modelValue": ($event) => unref(form).message = $event,
                              id: "message",
                              type: "textarea",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(BaseDivider, null, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(BaseButtons, null, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(BaseButtonLink, {
                            type: "submit",
                            color: "primary",
                            label: "SENT MESSAGE",
                            class: { "opacity-25": unref(form).processing },
                            disabled: unref(form).processing
                          }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(BaseButtonLink, {
                              type: "submit",
                              color: "primary",
                              label: "SENT MESSAGE",
                              class: { "opacity-25": unref(form).processing },
                              disabled: unref(form).processing
                            }, null, 8, ["class", "disabled"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(FormValidationErrors),
                      createVNode(FormSuccess),
                      createVNode("h4", { class: "text-2xl font-semibold text-slate-800" }, "Want to work with us?"),
                      createVNode("p", { class: "leading-relaxed mt-1 mb-4 text-gray-600" }, " Complete this form and we will get back to you in 24 hours. "),
                      createVNode(FormField, {
                        label: "Full Name",
                        "label-for": "name",
                        help: "Please enter your full name"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            id: "name",
                            icon: "fas fa-user",
                            type: "text",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(FormField, {
                        label: "Email",
                        "label-for": "email",
                        help: "Please enter your email"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            id: "email",
                            icon: "fas fa-envelope",
                            type: "email",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(FormField, {
                        label: "Subject",
                        "label-for": "subject",
                        help: "Please enter your subject"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).subject,
                            "onUpdate:modelValue": ($event) => unref(form).subject = $event,
                            id: "subject",
                            icon: "fas fa-sticky-note",
                            type: "text",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(FormField, {
                        label: "Message",
                        "label-for": "message",
                        help: "Please enter your message"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).message,
                            "onUpdate:modelValue": ($event) => unref(form).message = $event,
                            id: "message",
                            type: "textarea",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(BaseDivider),
                      createVNode(BaseButtons, null, {
                        default: withCtx(() => [
                          createVNode(BaseButtonLink, {
                            type: "submit",
                            color: "primary",
                            label: "SENT MESSAGE",
                            class: { "opacity-25": unref(form).processing },
                            disabled: unref(form).processing
                          }, null, 8, ["class", "disabled"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div></div></div></section></main>`);
            } else {
              _push2(ssrRenderComponent(ComingSoon, null, null, _parent2, _scopeId));
            }
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(contactPageData).title ?? "Contact"
              }, null, 8, ["title"]),
              unref(contactPageData) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, {
                  bgImage: unref(contactPageData).featured_image
                }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$3, {
                      title: unref(contactPageData).title
                    }, null, 8, ["title"])
                  ]),
                  _: 1
                }, 8, ["bgImage"]),
                createVNode("section", { class: "pb-20 relative block dark:bg-gray-900" }, [
                  createVNode("div", { class: "container mx-auto px-4 lg:pt-24 lg:pb-64" }, [
                    createVNode("div", { class: "flex flex-wrap text-center justify-center" }, [
                      createVNode("div", { class: "w-full lg:w-6/12 px-4" }, [
                        createVNode(_sfc_main$3, {
                          title: contactContent.banner.title,
                          description: contactContent.banner.description,
                          subtitle: contactContent.banner.subtitle
                        }, null, 8, ["title", "description", "subtitle"])
                      ])
                    ]),
                    createVNode("div", { class: "flex flex-wrap" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(contactContent.contact_info, (item) => {
                        return openBlock(), createBlock("div", { class: "lg:pt-12 pt-6 w-full md:w-4/12 px-4 text-center" }, [
                          createVNode("div", { class: "relative flex flex-col min-w-0 break-words bg-white w-full mb-8 shadow-lg rounded-lg" }, [
                            createVNode("div", { class: "px-4 py-5 flex-auto" }, [
                              createVNode("div", { class: "text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 mb-5 shadow-lg rounded-full bg-red-400" }, [
                                createVNode("i", {
                                  class: item.icon
                                }, null, 2)
                              ]),
                              createVNode("h6", { class: "text-xl font-semibold text-stone-900" }, toDisplayString(item.title), 1),
                              createVNode("p", { class: "mt-2 mb-4 text-gray-600" }, toDisplayString(item.info), 1)
                            ])
                          ])
                        ]);
                      }), 256))
                    ])
                  ])
                ]),
                createVNode("section", { class: "relative block py-24 lg:pt-0 dark:bg-gray-900 dark:text-slate-800" }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "flex flex-wrap justify-center lg:-mt-64 -mt-48" }, [
                      createVNode("div", { class: "w-full lg:w-6/12 px-4" }, [
                        createVNode(CardBox, {
                          class: "my-24 bg-white dark:bg-white",
                          "is-form": "",
                          onSubmit: withModifiers(submit, ["prevent"])
                        }, {
                          default: withCtx(() => [
                            createVNode(FormValidationErrors),
                            createVNode(FormSuccess),
                            createVNode("h4", { class: "text-2xl font-semibold text-slate-800" }, "Want to work with us?"),
                            createVNode("p", { class: "leading-relaxed mt-1 mb-4 text-gray-600" }, " Complete this form and we will get back to you in 24 hours. "),
                            createVNode(FormField, {
                              label: "Full Name",
                              "label-for": "name",
                              help: "Please enter your full name"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).name,
                                  "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                  id: "name",
                                  icon: "fas fa-user",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Email",
                              "label-for": "email",
                              help: "Please enter your email"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).email,
                                  "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                  id: "email",
                                  icon: "fas fa-envelope",
                                  type: "email",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Subject",
                              "label-for": "subject",
                              help: "Please enter your subject"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).subject,
                                  "onUpdate:modelValue": ($event) => unref(form).subject = $event,
                                  id: "subject",
                                  icon: "fas fa-sticky-note",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Message",
                              "label-for": "message",
                              help: "Please enter your message"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).message,
                                  "onUpdate:modelValue": ($event) => unref(form).message = $event,
                                  id: "message",
                                  type: "textarea",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(BaseDivider),
                            createVNode(BaseButtons, null, {
                              default: withCtx(() => [
                                createVNode(BaseButtonLink, {
                                  type: "submit",
                                  color: "primary",
                                  label: "SENT MESSAGE",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["class", "disabled"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ])
              ])) : (openBlock(), createBlock(ComingSoon, { key: 1 }))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Contact.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
