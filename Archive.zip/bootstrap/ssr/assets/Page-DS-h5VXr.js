import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { usePage, Head } from "@inertiajs/vue3";
import { C as ComingSoon } from "./ComingSoon-DuRr8gR7.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Page",
  __ssrInlineRender: true,
  setup(__props) {
    const pageData = usePage().props.pageData;
    const urls = usePage().props.urls;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(pageData).title ?? "Page"
            }, null, _parent2, _scopeId));
            if (unref(pageData)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                bgImage: unref(pageData).featured_image
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: unref(pageData).title
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: unref(pageData).title
                      }, null, 8, ["title"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<!--[-->`);
              ssrRenderList(unref(pageData).contents, (item, index) => {
                _push2(`<section class="${ssrRenderClass([index % 2 === 0 && unref(pageData).contents.length > 1 ? "dark:bg-slate-800 bg-gray-100 dark:text-white" : "dark:bg-gray-100 dark:text-slate-800", "relative py-20"])}"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><!--[-->`);
                ssrRenderList(item.data, (data, itemIndex) => {
                  _push2(`<div class="${ssrRenderClass([data.imagePosition === "right" ? "flex-row-reverse text-slate-800" : "flex-row", "items-center flex"])}"${_scopeId}><div class="w-full md:w-4/12 ml-auto mr-auto px-4"${_scopeId}><img${ssrRenderAttr("alt", data.title)} class="max-w-full rounded-lg shadow-lg"${ssrRenderAttr("src", `${unref(urls).storeUrl}/${data.image}`)}${_scopeId}></div><div class="w-full md:w-5/12 ml-auto mr-auto px-4"${_scopeId}><div class="md:pr-12"${_scopeId}><h4 class="text-xl mb-2"${_scopeId}>${ssrInterpolate(data.subtitle)}</h4><h3 class="text-3xl font-semibold"${_scopeId}>${ssrInterpolate(data.title)}</h3><div class="mt-4 text-lg leading-relaxed"${_scopeId}>${ssrInterpolate(data.description)}</div></div></div></div>`);
                });
                _push2(`<!--]--></div></section>`);
              });
              _push2(`<!--]--></main>`);
            } else {
              _push2(ssrRenderComponent(ComingSoon, null, null, _parent2, _scopeId));
            }
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(pageData).title ?? "Page"
              }, null, 8, ["title"]),
              unref(pageData) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, {
                  bgImage: unref(pageData).featured_image
                }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$3, {
                      title: unref(pageData).title
                    }, null, 8, ["title"])
                  ]),
                  _: 1
                }, 8, ["bgImage"]),
                (openBlock(true), createBlock(Fragment, null, renderList(unref(pageData).contents, (item, index) => {
                  return openBlock(), createBlock("section", {
                    key: index,
                    class: ["relative py-20", index % 2 === 0 && unref(pageData).contents.length > 1 ? "dark:bg-slate-800 bg-gray-100 dark:text-white" : "dark:bg-gray-100 dark:text-slate-800"]
                  }, [
                    createVNode("div", { class: "container mx-auto px-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(item.data, (data, itemIndex) => {
                        return openBlock(), createBlock("div", {
                          key: itemIndex,
                          class: ["items-center flex", data.imagePosition === "right" ? "flex-row-reverse text-slate-800" : "flex-row"]
                        }, [
                          createVNode("div", { class: "w-full md:w-4/12 ml-auto mr-auto px-4" }, [
                            createVNode("img", {
                              alt: data.title,
                              class: "max-w-full rounded-lg shadow-lg",
                              src: `${unref(urls).storeUrl}/${data.image}`
                            }, null, 8, ["alt", "src"])
                          ]),
                          createVNode("div", { class: "w-full md:w-5/12 ml-auto mr-auto px-4" }, [
                            createVNode("div", { class: "md:pr-12" }, [
                              createVNode("h4", { class: "text-xl mb-2" }, toDisplayString(data.subtitle), 1),
                              createVNode("h3", { class: "text-3xl font-semibold" }, toDisplayString(data.title), 1),
                              createVNode("div", { class: "mt-4 text-lg leading-relaxed" }, toDisplayString(data.description), 1)
                            ])
                          ])
                        ], 2);
                      }), 128))
                    ])
                  ], 2);
                }), 128))
              ])) : (openBlock(), createBlock(ComingSoon, { key: 1 }))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Page.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
