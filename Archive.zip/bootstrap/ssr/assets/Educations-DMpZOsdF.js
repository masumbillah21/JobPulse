import { defineComponent, withCtx, createVNode, unref, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { usePage, useForm, router } from "@inertiajs/vue3";
import "./colors-K3EOgMMA.js";
import "./BaseIcon-C4zrUKd9.js";
import "./isSystemUser-D-zJOoLX.js";
import "./NotificationBarInCard-Dg146C8Q.js";
import "./IconRounded-RF1xkXym.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "pinia";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Educations",
  __ssrInlineRender: true,
  setup(__props) {
    const educationInfo = usePage().props.educationInfo ?? null;
    const gradeType = [
      { id: "division", label: "Division" },
      { id: "grade", label: "Grade" }
    ];
    const form = useForm({
      "educations": [
        {
          id: 0,
          degree: "test",
          institute: "test1",
          board_university: "test2",
          passing_year: "2012",
          result_type: "grade",
          result: "5"
        }
      ],
      _method: "post"
    });
    if (educationInfo) {
      form.educations = educationInfo;
    }
    const addRow = () => {
      form.educations.push({
        id: 0,
        degree: "",
        institute: "",
        board_university: "",
        passing_year: "",
        result_type: "",
        result: ""
      });
    };
    const remove = (index, id) => {
      form.educations.splice(index, 1);
      if (id != 0) {
        router.delete(route("resume.deleteEducation", id));
      }
    };
    const submit = (data) => {
      router.post(route("resume.saveEducation"), data);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(SectionTitleLineWithButton, {
        icon: "fas fa-arrow-circle-right",
        title: "Educational Qualification",
        main: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(BaseButtonLink, {
              icon: "fas fa-plus",
              onClick: addRow,
              label: "Add New",
              color: "contrast",
              "rounded-full": "",
              small: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(BaseButtonLink, {
                icon: "fas fa-plus",
                onClick: addRow,
                label: "Add New",
                color: "contrast",
                "rounded-full": "",
                small: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(CardBox, {
        "is-form": "",
        onSubmit: submit
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(FormValidationErrors, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(FormSuccess, null, null, _parent2, _scopeId));
            _push2(`<table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}> Title </th><th scope="col" class="px-6 py-3"${_scopeId}> Institution </th><th scope="col" class="px-6 py-3"${_scopeId}> Board / University </th><th scope="col" class="px-6 py-3"${_scopeId}> Passing Year </th><th scope="col" class="px-6 py-3"${_scopeId}> Result Type </th><th scope="col" class="px-6 py-3"${_scopeId}> Result </th><th scope="col" class="px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(unref(form).educations, (row, index) => {
              _push2(`<tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700"${_scopeId}><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.degree,
                "onUpdate:modelValue": ($event) => row.degree = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.institute,
                "onUpdate:modelValue": ($event) => row.institute = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.board_university,
                "onUpdate:modelValue": ($event) => row.board_university = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.passing_year,
                "onUpdate:modelValue": ($event) => row.passing_year = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" width="180"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.result_type,
                "onUpdate:modelValue": ($event) => row.result_type = $event,
                options: gradeType,
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(FormControl, {
                modelValue: row.result,
                "onUpdate:modelValue": ($event) => row.result = $event,
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(BaseButtonLink, {
                icon: "fas fa-save",
                color: "info",
                class: { "opacity-25": unref(form).processing },
                onClick: ($event) => submit(row)
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(BaseButtonLink, {
                icon: "fas fa-minus",
                onClick: ($event) => remove(index, row.id),
                class: "ml-2",
                color: "danger",
                "rounded-full": "",
                small: ""
              }, null, _parent2, _scopeId));
              _push2(`</td></tr>`);
            });
            _push2(`<!--]--></tbody></table>`);
          } else {
            return [
              createVNode(FormValidationErrors),
              createVNode(FormSuccess),
              createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                  createVNode("tr", null, [
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Title "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Institution "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Board / University "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Passing Year "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Result Type "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Result "),
                    createVNode("th", {
                      scope: "col",
                      class: "px-6 py-3"
                    }, " Action ")
                  ])
                ]),
                createVNode("tbody", null, [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(form).educations, (row, index) => {
                    return openBlock(), createBlock("tr", {
                      key: index,
                      class: "odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700"
                    }, [
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.degree,
                          "onUpdate:modelValue": ($event) => row.degree = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.institute,
                          "onUpdate:modelValue": ($event) => row.institute = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.board_university,
                          "onUpdate:modelValue": ($event) => row.board_university = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.passing_year,
                          "onUpdate:modelValue": ($event) => row.passing_year = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", {
                        class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white",
                        width: "180"
                      }, [
                        createVNode(FormControl, {
                          modelValue: row.result_type,
                          "onUpdate:modelValue": ($event) => row.result_type = $event,
                          options: gradeType,
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(FormControl, {
                          modelValue: row.result,
                          "onUpdate:modelValue": ($event) => row.result = $event,
                          type: "text",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white" }, [
                        createVNode(BaseButtonLink, {
                          icon: "fas fa-save",
                          color: "info",
                          class: { "opacity-25": unref(form).processing },
                          onClick: ($event) => submit(row)
                        }, null, 8, ["class", "onClick"]),
                        createVNode(BaseButtonLink, {
                          icon: "fas fa-minus",
                          onClick: ($event) => remove(index, row.id),
                          class: "ml-2",
                          color: "danger",
                          "rounded-full": "",
                          small: ""
                        }, null, 8, ["onClick"])
                      ])
                    ]);
                  }), 128))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Resume/Tabs/Educations.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
