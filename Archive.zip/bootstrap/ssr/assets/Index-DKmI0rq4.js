import { defineComponent, computed, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, createTextVNode, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { P as Pagination } from "./Pagination-BiZgXXz6.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import { _ as _sfc_main$4 } from "./JobSection--NNnfjnx.js";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { C as ComingSoon } from "./ComingSoon-DuRr8gR7.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./FormField-ePZgxXzs.js";
import "./FormControl-DwHkIb1m.js";
import "./main-C5vGb8af.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    storageUrl: String
  },
  setup(__props) {
    const jobPageData = usePage().props.jobPageData;
    const jobList = usePage().props.jobList;
    const allActiveJobs = usePage().props.allActiveJobs;
    const jobCategories = usePage().props.jobCategories;
    const form = useForm({
      categories: [],
      jobLevel: [],
      jobType: [],
      workType: []
    });
    const jobPageContent = {
      banner: "",
      jobs: ""
    };
    if (jobPageData) {
      jobPageData.contents.forEach((item) => {
        if (item.slug === "banner") {
          jobPageContent.banner = item.data[0];
        }
        if (item.slug === "jobs") {
          jobPageContent.jobs = item.data[0];
        }
      });
    }
    const jobTypes = {
      "Full Time": "Full Time",
      "Part Time": "Part Time",
      "Contract": "Contract"
    };
    const jobLevel = {
      "Beginner": "Beginner",
      "Intermiddiate": "Intermidiate",
      "Advanced": "Advanced"
    };
    const workType = {
      "Remote": "Remote",
      "On Site": "On Site",
      "Hybrid": "Hybrid"
    };
    const filteredJobs = computed(() => {
      if (form.categories.length === 0 && form.jobLevel.length === 0 && form.jobType.length === 0 && form.workType.length === 0) {
        return jobList.data;
      }
      return allActiveJobs.filter((job) => {
        const cateId = job.job_category_id.toString();
        const categoryMatch = form.categories.length === 0 || form.categories.includes(cateId);
        const jobLevelMatch = form.jobLevel.length === 0 || form.jobLevel.includes(job.job_level);
        const jobTypeMatch = form.jobType.length === 0 || form.jobType.includes(job.job_type);
        const workTypeMatch = form.workType.length === 0 || form.workType.includes(job.work_type);
        return categoryMatch && jobLevelMatch && jobTypeMatch && workTypeMatch;
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Jobs" }, null, _parent2, _scopeId));
            if (unref(jobPageData)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                bgImage: (_a = unref(jobPageData)) == null ? void 0 : _a.featured_image
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: jobPageContent.banner.title,
                      description: jobPageContent.banner.description,
                      subtitle: jobPageContent.banner.subtitle
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: jobPageContent.banner.title,
                        description: jobPageContent.banner.description,
                        subtitle: jobPageContent.banner.subtitle
                      }, null, 8, ["title", "description", "subtitle"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<section class="pb-20 bg-gray-100"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="flex flex-wrap"${_scopeId}><div class="lg:pt-12 pt-6 w-full px-4"${_scopeId}><div class="w-full lg:w-6/12 px-4 ml-auto mr-auto text-center text-slate-800 mb-5"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                title: jobPageContent.jobs.title,
                description: jobPageContent.jobs.description,
                subtitle: jobPageContent.jobs.subtitle
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="flex"${_scopeId}><div class="md:w-3/12 w-full md:mr-2 dark:text-black"${_scopeId}><h2 class="text-xl font-semibold px-4"${_scopeId}>Filters</h2><hr${_scopeId}>`);
              if (unref(jobCategories)) {
                _push2(`<div class="mt-4 bg-white dark:text-black rounded shadow p-4"${_scopeId}><h2 class="text-xl font-semibold"${_scopeId}>Categories</h2><hr${_scopeId}>`);
                _push2(ssrRenderComponent(FormCheckRadioGroup, {
                  class: "mt-6",
                  componentClass: "w-full",
                  modelValue: unref(form).categories,
                  "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                  name: "categories",
                  type: "checkbox",
                  options: unref(jobCategories)
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<div class="mt-4 bg-white rounded shadow p-4"${_scopeId}><h2 class="text-xl font-semibold"${_scopeId}>Level</h2><hr${_scopeId}>`);
              _push2(ssrRenderComponent(FormCheckRadioGroup, {
                class: "mt-6",
                componentClass: "w-full",
                modelValue: unref(form).jobLevel,
                "onUpdate:modelValue": ($event) => unref(form).jobLevel = $event,
                name: "levels",
                type: "checkbox",
                options: jobLevel
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="mt-4 bg-white rounded shadow p-4"${_scopeId}><h2 class="text-xl font-semibold"${_scopeId}>Job Type</h2><hr${_scopeId}>`);
              _push2(ssrRenderComponent(FormCheckRadioGroup, {
                class: "mt-6",
                componentClass: "w-full",
                modelValue: unref(form).jobType,
                "onUpdate:modelValue": ($event) => unref(form).jobType = $event,
                name: "types",
                type: "checkbox",
                options: jobTypes
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="mt-4 bg-white rounded shadow p-4"${_scopeId}><h2 class="text-xl font-semibold"${_scopeId}>Work Type</h2><hr${_scopeId}>`);
              _push2(ssrRenderComponent(FormCheckRadioGroup, {
                class: "mt-6",
                componentClass: "w-full",
                modelValue: unref(form).workType,
                "onUpdate:modelValue": ($event) => unref(form).workType = $event,
                name: "workType",
                type: "checkbox",
                options: workType
              }, null, _parent2, _scopeId));
              _push2(`</div></div><div class="relative flex flex-col min-w-0 break-words bg-white text-slate-900 w-full mb-8 py-10 px-3 shadow-lg rounded-lg"${_scopeId}>`);
              if (unref(form).categories.length > 0) {
                _push2(`<p class="mb-2"${_scopeId}> Category(s): <!--[-->`);
                ssrRenderList(unref(form).categories, (category) => {
                  _push2(`<span class="font-bold bg-black rounded m-1 p-1 text-white"${_scopeId}>${ssrInterpolate(unref(jobCategories)[category])}</span>`);
                });
                _push2(`<!--]--></p>`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(form).jobLevel.length > 0) {
                _push2(`<p class="mb-2"${_scopeId}> Level: <!--[-->`);
                ssrRenderList(unref(form).jobLevel, (level) => {
                  _push2(`<span class="font-bold bg-black rounded m-1 p-1 text-white"${_scopeId}>${ssrInterpolate(level)}</span>`);
                });
                _push2(`<!--]--></p>`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(form).jobType.length > 0) {
                _push2(`<p class="mb-2"${_scopeId}> Job Type: <!--[-->`);
                ssrRenderList(unref(form).jobType, (job) => {
                  _push2(`<span class="font-bold bg-black rounded m-1 p-1 text-white"${_scopeId}>${ssrInterpolate(job)}</span>`);
                });
                _push2(`<!--]--></p>`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(form).workType.length > 0) {
                _push2(`<p class="mb-2"${_scopeId}> Work Type: <!--[-->`);
                ssrRenderList(unref(form).workType, (work) => {
                  _push2(`<span class="font-bold bg-black rounded m-1 p-1 text-white"${_scopeId}>${ssrInterpolate(work)}</span>`);
                });
                _push2(`<!--]--></p>`);
              } else {
                _push2(`<!---->`);
              }
              if (filteredJobs.value.length > 0) {
                _push2(`<!--[-->`);
                _push2(ssrRenderComponent(_sfc_main$4, {
                  jobList: filteredJobs.value,
                  allJobs: unref(allActiveJobs),
                  displayTotal: 10
                }, null, _parent2, _scopeId));
                _push2(ssrRenderComponent(Pagination, {
                  class: "mt-6 text-white",
                  links: (_b = unref(jobList)) == null ? void 0 : _b.links
                }, null, _parent2, _scopeId));
                _push2(`<!--]-->`);
              } else {
                _push2(`<p class="text-center bg-red-500 text-white font-semibold rounded py-5 text-xl"${_scopeId}>No jobs found </p>`);
              }
              _push2(`</div></div></div></div></div></section></main>`);
            } else {
              _push2(ssrRenderComponent(ComingSoon, null, null, _parent2, _scopeId));
            }
          } else {
            return [
              createVNode(unref(Head), { title: "Jobs" }),
              unref(jobPageData) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, {
                  bgImage: (_c = unref(jobPageData)) == null ? void 0 : _c.featured_image
                }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$3, {
                      title: jobPageContent.banner.title,
                      description: jobPageContent.banner.description,
                      subtitle: jobPageContent.banner.subtitle
                    }, null, 8, ["title", "description", "subtitle"])
                  ]),
                  _: 1
                }, 8, ["bgImage"]),
                createVNode("section", { class: "pb-20 bg-gray-100" }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "flex flex-wrap" }, [
                      createVNode("div", { class: "lg:pt-12 pt-6 w-full px-4" }, [
                        createVNode("div", { class: "w-full lg:w-6/12 px-4 ml-auto mr-auto text-center text-slate-800 mb-5" }, [
                          createVNode(_sfc_main$3, {
                            title: jobPageContent.jobs.title,
                            description: jobPageContent.jobs.description,
                            subtitle: jobPageContent.jobs.subtitle
                          }, null, 8, ["title", "description", "subtitle"])
                        ]),
                        createVNode("div", { class: "flex" }, [
                          createVNode("div", { class: "md:w-3/12 w-full md:mr-2 dark:text-black" }, [
                            createVNode("h2", { class: "text-xl font-semibold px-4" }, "Filters"),
                            createVNode("hr"),
                            unref(jobCategories) ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "mt-4 bg-white dark:text-black rounded shadow p-4"
                            }, [
                              createVNode("h2", { class: "text-xl font-semibold" }, "Categories"),
                              createVNode("hr"),
                              createVNode(FormCheckRadioGroup, {
                                class: "mt-6",
                                componentClass: "w-full",
                                modelValue: unref(form).categories,
                                "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                                name: "categories",
                                type: "checkbox",
                                options: unref(jobCategories)
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                            ])) : createCommentVNode("", true),
                            createVNode("div", { class: "mt-4 bg-white rounded shadow p-4" }, [
                              createVNode("h2", { class: "text-xl font-semibold" }, "Level"),
                              createVNode("hr"),
                              createVNode(FormCheckRadioGroup, {
                                class: "mt-6",
                                componentClass: "w-full",
                                modelValue: unref(form).jobLevel,
                                "onUpdate:modelValue": ($event) => unref(form).jobLevel = $event,
                                name: "levels",
                                type: "checkbox",
                                options: jobLevel
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            createVNode("div", { class: "mt-4 bg-white rounded shadow p-4" }, [
                              createVNode("h2", { class: "text-xl font-semibold" }, "Job Type"),
                              createVNode("hr"),
                              createVNode(FormCheckRadioGroup, {
                                class: "mt-6",
                                componentClass: "w-full",
                                modelValue: unref(form).jobType,
                                "onUpdate:modelValue": ($event) => unref(form).jobType = $event,
                                name: "types",
                                type: "checkbox",
                                options: jobTypes
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            createVNode("div", { class: "mt-4 bg-white rounded shadow p-4" }, [
                              createVNode("h2", { class: "text-xl font-semibold" }, "Work Type"),
                              createVNode("hr"),
                              createVNode(FormCheckRadioGroup, {
                                class: "mt-6",
                                componentClass: "w-full",
                                modelValue: unref(form).workType,
                                "onUpdate:modelValue": ($event) => unref(form).workType = $event,
                                name: "workType",
                                type: "checkbox",
                                options: workType
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ])
                          ]),
                          createVNode("div", { class: "relative flex flex-col min-w-0 break-words bg-white text-slate-900 w-full mb-8 py-10 px-3 shadow-lg rounded-lg" }, [
                            unref(form).categories.length > 0 ? (openBlock(), createBlock("p", {
                              key: 0,
                              class: "mb-2"
                            }, [
                              createTextVNode(" Category(s): "),
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(form).categories, (category) => {
                                return openBlock(), createBlock("span", { class: "font-bold bg-black rounded m-1 p-1 text-white" }, toDisplayString(unref(jobCategories)[category]), 1);
                              }), 256))
                            ])) : createCommentVNode("", true),
                            unref(form).jobLevel.length > 0 ? (openBlock(), createBlock("p", {
                              key: 1,
                              class: "mb-2"
                            }, [
                              createTextVNode(" Level: "),
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(form).jobLevel, (level) => {
                                return openBlock(), createBlock("span", { class: "font-bold bg-black rounded m-1 p-1 text-white" }, toDisplayString(level), 1);
                              }), 256))
                            ])) : createCommentVNode("", true),
                            unref(form).jobType.length > 0 ? (openBlock(), createBlock("p", {
                              key: 2,
                              class: "mb-2"
                            }, [
                              createTextVNode(" Job Type: "),
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(form).jobType, (job) => {
                                return openBlock(), createBlock("span", { class: "font-bold bg-black rounded m-1 p-1 text-white" }, toDisplayString(job), 1);
                              }), 256))
                            ])) : createCommentVNode("", true),
                            unref(form).workType.length > 0 ? (openBlock(), createBlock("p", {
                              key: 3,
                              class: "mb-2"
                            }, [
                              createTextVNode(" Work Type: "),
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(form).workType, (work) => {
                                return openBlock(), createBlock("span", { class: "font-bold bg-black rounded m-1 p-1 text-white" }, toDisplayString(work), 1);
                              }), 256))
                            ])) : createCommentVNode("", true),
                            filteredJobs.value.length > 0 ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                              createVNode(_sfc_main$4, {
                                jobList: filteredJobs.value,
                                allJobs: unref(allActiveJobs),
                                displayTotal: 10
                              }, null, 8, ["jobList", "allJobs"]),
                              createVNode(Pagination, {
                                class: "mt-6 text-white",
                                links: (_d = unref(jobList)) == null ? void 0 : _d.links
                              }, null, 8, ["links"])
                            ], 64)) : (openBlock(), createBlock("p", {
                              key: 5,
                              class: "text-center bg-red-500 text-white font-semibold rounded py-5 text-xl"
                            }, "No jobs found "))
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])) : (openBlock(), createBlock(ComingSoon, { key: 1 }))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Job/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
