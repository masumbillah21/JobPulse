import { ref, onMounted, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$2, c as chartTemplate } from "./CardBoxWidget-C_qrvtYP.js";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import "./BaseLevel-D_z-LHoc.js";
import "./IconRounded-RF1xkXym.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { S as SectionTitle } from "./SectionTitle-qF5u6qV8.js";
import { usePage, Head } from "@inertiajs/vue3";
import { U as UserTypeEnum } from "./isSystemUser-D-zJOoLX.js";
import { i as isCandidateUser } from "./isCandidateUser-C4fFP75s.js";
import "chart.js";
import "numeral";
import "./BaseIcon-C4zrUKd9.js";
import "./colors-K3EOgMMA.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseDivider-uk-eaHSj.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const isCompanyUser = () => {
  const { auth } = usePage().props;
  if (!auth.user) {
    return false;
  }
  const userType = auth.user.user_type || "";
  return userType === UserTypeEnum.COMPANY;
};
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    const chartInfo = usePage().props.chartInfo;
    const totalEmployees = usePage().props.totalEmployees;
    const totalJobs = usePage().props.totalJobs;
    const totalCandidates = usePage().props.totalCandidates;
    const totalApplied = usePage().props.totalApplied;
    const totalSelected = usePage().props.totalSelected;
    const totalRejected = usePage().props.totalRejected;
    const chartData = ref(null);
    const fillChartData = () => {
      chartData.value = chartTemplate();
      chartInfo.data.forEach((item, index) => {
        chartData.value.datasets[index].data = item;
      });
    };
    onMounted(() => {
      fillChartData();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitle, {
                    icon: "fas fa-sliders-h",
                    title: "Overview",
                    main: ""
                  }, null, _parent3, _scopeId2));
                  _push3(`<div class="grid grid-cols-1 gap-6 lg:grid-cols-3 mb-6"${_scopeId2}>`);
                  if (unref(isCompanyUser)()) {
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      color: "text-emerald-500",
                      icon: "fas fa-users",
                      number: unref(totalEmployees),
                      label: "Employees"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  if (unref(isCompanyUser)()) {
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      color: "text-blue-500",
                      icon: "fas fa-building",
                      number: unref(totalJobs),
                      label: "Jobs"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  if (unref(isCompanyUser)()) {
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      color: "text-red-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalCandidates),
                      label: "Applications"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  if (unref(isCandidateUser)()) {
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      color: "text-emerald-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalApplied),
                      label: "Applied"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  if (unref(isCandidateUser)()) {
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      color: "text-blue-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalSelected),
                      label: "Selected"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  if (unref(isCandidateUser)()) {
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      color: "text-red-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalRejected),
                      label: "Rejected"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    icon: "fas fa-chart-pie",
                    title: "This Year"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "fas fa-sync-alt",
                          color: "whiteDark",
                          onClick: fillChartData
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            icon: "fas fa-sync-alt",
                            color: "whiteDark",
                            onClick: fillChartData
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, { class: "mb-6" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (chartData.value) {
                          _push4(`<div${_scopeId3}>`);
                          _push4(ssrRenderComponent(_sfc_main$2, {
                            data: chartData.value,
                            class: "h-96"
                          }, null, _parent4, _scopeId3));
                          _push4(`</div>`);
                        } else {
                          _push4(`<!---->`);
                        }
                      } else {
                        return [
                          chartData.value ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode(_sfc_main$2, {
                              data: chartData.value,
                              class: "h-96"
                            }, null, 8, ["data"])
                          ])) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(SectionTitle, {
                      icon: "fas fa-sliders-h",
                      title: "Overview",
                      main: ""
                    }),
                    createVNode("div", { class: "grid grid-cols-1 gap-6 lg:grid-cols-3 mb-6" }, [
                      unref(isCompanyUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                        key: 0,
                        color: "text-emerald-500",
                        icon: "fas fa-users",
                        number: unref(totalEmployees),
                        label: "Employees"
                      }, null, 8, ["number"])) : createCommentVNode("", true),
                      unref(isCompanyUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                        key: 1,
                        color: "text-blue-500",
                        icon: "fas fa-building",
                        number: unref(totalJobs),
                        label: "Jobs"
                      }, null, 8, ["number"])) : createCommentVNode("", true),
                      unref(isCompanyUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                        key: 2,
                        color: "text-red-500",
                        icon: "fas fa-suitcase",
                        number: unref(totalCandidates),
                        label: "Applications"
                      }, null, 8, ["number"])) : createCommentVNode("", true),
                      unref(isCandidateUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                        key: 3,
                        color: "text-emerald-500",
                        icon: "fas fa-suitcase",
                        number: unref(totalApplied),
                        label: "Applied"
                      }, null, 8, ["number"])) : createCommentVNode("", true),
                      unref(isCandidateUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                        key: 4,
                        color: "text-blue-500",
                        icon: "fas fa-suitcase",
                        number: unref(totalSelected),
                        label: "Selected"
                      }, null, 8, ["number"])) : createCommentVNode("", true),
                      unref(isCandidateUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                        key: 5,
                        color: "text-red-500",
                        icon: "fas fa-suitcase",
                        number: unref(totalRejected),
                        label: "Rejected"
                      }, null, 8, ["number"])) : createCommentVNode("", true)
                    ]),
                    createVNode(SectionTitleLineWithButton, {
                      icon: "fas fa-chart-pie",
                      title: "This Year"
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          icon: "fas fa-sync-alt",
                          color: "whiteDark",
                          onClick: fillChartData
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(CardBox, { class: "mb-6" }, {
                      default: withCtx(() => [
                        chartData.value ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode(_sfc_main$2, {
                            data: chartData.value,
                            class: "h-96"
                          }, null, 8, ["data"])
                        ])) : createCommentVNode("", true)
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Dashboard" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitle, {
                    icon: "fas fa-sliders-h",
                    title: "Overview",
                    main: ""
                  }),
                  createVNode("div", { class: "grid grid-cols-1 gap-6 lg:grid-cols-3 mb-6" }, [
                    unref(isCompanyUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 0,
                      color: "text-emerald-500",
                      icon: "fas fa-users",
                      number: unref(totalEmployees),
                      label: "Employees"
                    }, null, 8, ["number"])) : createCommentVNode("", true),
                    unref(isCompanyUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 1,
                      color: "text-blue-500",
                      icon: "fas fa-building",
                      number: unref(totalJobs),
                      label: "Jobs"
                    }, null, 8, ["number"])) : createCommentVNode("", true),
                    unref(isCompanyUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 2,
                      color: "text-red-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalCandidates),
                      label: "Applications"
                    }, null, 8, ["number"])) : createCommentVNode("", true),
                    unref(isCandidateUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 3,
                      color: "text-emerald-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalApplied),
                      label: "Applied"
                    }, null, 8, ["number"])) : createCommentVNode("", true),
                    unref(isCandidateUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 4,
                      color: "text-blue-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalSelected),
                      label: "Selected"
                    }, null, 8, ["number"])) : createCommentVNode("", true),
                    unref(isCandidateUser)() ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 5,
                      color: "text-red-500",
                      icon: "fas fa-suitcase",
                      number: unref(totalRejected),
                      label: "Rejected"
                    }, null, 8, ["number"])) : createCommentVNode("", true)
                  ]),
                  createVNode(SectionTitleLineWithButton, {
                    icon: "fas fa-chart-pie",
                    title: "This Year"
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        icon: "fas fa-sync-alt",
                        color: "whiteDark",
                        onClick: fillChartData
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(CardBox, { class: "mb-6" }, {
                    default: withCtx(() => [
                      chartData.value ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode(_sfc_main$2, {
                          data: chartData.value,
                          class: "h-96"
                        }, null, 8, ["data"])
                      ])) : createCommentVNode("", true)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
