import { withCtx, unref, createVNode, toDisplayString, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { usePage, Head } from "@inertiajs/vue3";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./IconRounded-RF1xkXym.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {
  __name: "Show",
  __ssrInlineRender: true,
  setup(__props) {
    const companyData = usePage().props.companyDetails;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(companyData).name
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(companyData).name,
                    main: ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "company.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            icon: "far fa-arrow-alt-circle-left",
                            label: "Back",
                            routeName: "company.index",
                            color: "contrast",
                            "rounded-full": "",
                            small: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="flex"${_scopeId2}>`);
                  _push3(ssrRenderComponent(CardBox, { class: "my-24 w-1/5 ml-3" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<img class="mb-10"${ssrRenderAttr("src", unref(companyData).logo)} alt="" width="200"${_scopeId3}><h2 class="mb-3"${_scopeId3}><span class="text-3xl font-bold"${_scopeId3}>Title: ${ssrInterpolate(unref(companyData).name)}</span></h2><hr class="mb-6"${_scopeId3}><h2 class="mb-3"${_scopeId3}><span class="font-bold"${_scopeId3}>Company Type:</span> ${ssrInterpolate(unref(companyData).company_type)}</h2><h2 class="mb-3"${_scopeId3}><span class="font-bold"${_scopeId3}>Company Size:</span> ${ssrInterpolate(unref(companyData).company_size)}</h2><h2 class="mb-3"${_scopeId3}><span class="font-bold"${_scopeId3}>Address:</span> ${ssrInterpolate(unref(companyData).address)}</h2><h2 class="mb-3"${_scopeId3}><span class="font-bold"${_scopeId3}>Phone:</span> ${ssrInterpolate(unref(companyData).phone)}</h2><h2 class="mb-3"${_scopeId3}><span class="font-bold"${_scopeId3}>Email: </span> ${ssrInterpolate(unref(companyData).email)}</h2><h2 class="mb-3"${_scopeId3}><span class="font-bold"${_scopeId3}>Website:</span> ${ssrInterpolate(unref(companyData).website)}</h2>`);
                      } else {
                        return [
                          createVNode("img", {
                            class: "mb-10",
                            src: unref(companyData).logo,
                            alt: "",
                            width: "200"
                          }, null, 8, ["src"]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "text-3xl font-bold" }, "Title: " + toDisplayString(unref(companyData).name), 1)
                          ]),
                          createVNode("hr", { class: "mb-6" }),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Company Type:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).company_type), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Company Size:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).company_size), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Address:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).address), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Phone:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).phone), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Email: "),
                            createTextVNode(" " + toDisplayString(unref(companyData).email), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Website:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).website), 1)
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, { class: "my-24 w-4/5 ml-3" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<h2 class="text-2xl font-bold"${_scopeId3}>Company Description</h2><hr class="mb-3"${_scopeId3}><p class="mb-2"${_scopeId3}>${ssrInterpolate(unref(companyData).description)}</p>`);
                      } else {
                        return [
                          createVNode("h2", { class: "text-2xl font-bold" }, "Company Description"),
                          createVNode("hr", { class: "mb-3" }),
                          createVNode("p", { class: "mb-2" }, toDisplayString(unref(companyData).description), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: unref(companyData).name,
                      main: ""
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "company.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        })
                      ]),
                      _: 1
                    }, 8, ["title"]),
                    createVNode("div", { class: "flex" }, [
                      createVNode(CardBox, { class: "my-24 w-1/5 ml-3" }, {
                        default: withCtx(() => [
                          createVNode("img", {
                            class: "mb-10",
                            src: unref(companyData).logo,
                            alt: "",
                            width: "200"
                          }, null, 8, ["src"]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "text-3xl font-bold" }, "Title: " + toDisplayString(unref(companyData).name), 1)
                          ]),
                          createVNode("hr", { class: "mb-6" }),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Company Type:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).company_type), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Company Size:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).company_size), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Address:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).address), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Phone:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).phone), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Email: "),
                            createTextVNode(" " + toDisplayString(unref(companyData).email), 1)
                          ]),
                          createVNode("h2", { class: "mb-3" }, [
                            createVNode("span", { class: "font-bold" }, "Website:"),
                            createTextVNode(" " + toDisplayString(unref(companyData).website), 1)
                          ])
                        ]),
                        _: 1
                      }),
                      createVNode(CardBox, { class: "my-24 w-4/5 ml-3" }, {
                        default: withCtx(() => [
                          createVNode("h2", { class: "text-2xl font-bold" }, "Company Description"),
                          createVNode("hr", { class: "mb-3" }),
                          createVNode("p", { class: "mb-2" }, toDisplayString(unref(companyData).description), 1)
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(companyData).name
              }, null, 8, ["title"]),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(companyData).name,
                    main: ""
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        icon: "far fa-arrow-alt-circle-left",
                        label: "Back",
                        routeName: "company.index",
                        color: "contrast",
                        "rounded-full": "",
                        small: ""
                      })
                    ]),
                    _: 1
                  }, 8, ["title"]),
                  createVNode("div", { class: "flex" }, [
                    createVNode(CardBox, { class: "my-24 w-1/5 ml-3" }, {
                      default: withCtx(() => [
                        createVNode("img", {
                          class: "mb-10",
                          src: unref(companyData).logo,
                          alt: "",
                          width: "200"
                        }, null, 8, ["src"]),
                        createVNode("h2", { class: "mb-3" }, [
                          createVNode("span", { class: "text-3xl font-bold" }, "Title: " + toDisplayString(unref(companyData).name), 1)
                        ]),
                        createVNode("hr", { class: "mb-6" }),
                        createVNode("h2", { class: "mb-3" }, [
                          createVNode("span", { class: "font-bold" }, "Company Type:"),
                          createTextVNode(" " + toDisplayString(unref(companyData).company_type), 1)
                        ]),
                        createVNode("h2", { class: "mb-3" }, [
                          createVNode("span", { class: "font-bold" }, "Company Size:"),
                          createTextVNode(" " + toDisplayString(unref(companyData).company_size), 1)
                        ]),
                        createVNode("h2", { class: "mb-3" }, [
                          createVNode("span", { class: "font-bold" }, "Address:"),
                          createTextVNode(" " + toDisplayString(unref(companyData).address), 1)
                        ]),
                        createVNode("h2", { class: "mb-3" }, [
                          createVNode("span", { class: "font-bold" }, "Phone:"),
                          createTextVNode(" " + toDisplayString(unref(companyData).phone), 1)
                        ]),
                        createVNode("h2", { class: "mb-3" }, [
                          createVNode("span", { class: "font-bold" }, "Email: "),
                          createTextVNode(" " + toDisplayString(unref(companyData).email), 1)
                        ]),
                        createVNode("h2", { class: "mb-3" }, [
                          createVNode("span", { class: "font-bold" }, "Website:"),
                          createTextVNode(" " + toDisplayString(unref(companyData).website), 1)
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(CardBox, { class: "my-24 w-4/5 ml-3" }, {
                      default: withCtx(() => [
                        createVNode("h2", { class: "text-2xl font-bold" }, "Company Description"),
                        createVNode("hr", { class: "mb-3" }),
                        createVNode("p", { class: "mb-2" }, toDisplayString(unref(companyData).description), 1)
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Company/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
