import { defineComponent, ref, reactive, computed, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain, h as hasPermission } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { S as SectionTitle } from "./SectionTitle-qF5u6qV8.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { C as CardBoxModal } from "./CardBoxModal-Ci16pu_P.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import Vue3Datatable from "@bhplugin/vue3-datatable";
/* empty css               */
import { usePage, useForm, Head, router } from "@inertiajs/vue3";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./IconRounded-RF1xkXym.js";
import "./BaseButtons-6cEMRrBZ.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Tags",
  __ssrInlineRender: true,
  setup(__props) {
    const tagsData = usePage().props.tagsData;
    const isModalDangerActive = ref(false);
    const deleteId = ref("");
    const form = useForm({
      id: 0,
      name: "",
      created_at: "",
      updated_at: ""
    });
    const submit = () => {
      form.post(route("admin.tags.store"), {
        onSuccess: () => {
          const items = usePage().props.tagsData;
          tagsData.data = items.data;
          form.reset();
        }
      });
    };
    const dataEdit = (data) => {
      form.id = data.id;
      form.name = data.name;
    };
    const deleteData = () => {
      isModalDangerActive.value = false;
      router.delete(route("admin.tags.destroy", deleteId.value));
      const index = tagsData.findIndex((category) => category.id === deleteId.value);
      if (index !== -1) {
        tagsData.splice(index, 1);
      }
    };
    const showModle = (id) => {
      isModalDangerActive.value = true;
      deleteId.value = id;
    };
    const params = reactive({
      current_page: 1,
      pagesize: 10,
      sort_column: "id",
      sort_direction: "asc",
      search: ""
    });
    const cols = ref([
      { title: "SL", field: "id", isUnique: true, type: "number", width: "100px", hide: false },
      { title: "Title", field: "name", hide: false },
      { title: "Action", field: "action", hide: false }
    ]);
    const rows = ref(tagsData.map((tag, index) => {
      return {
        sl: index + 1,
        id: tag.id,
        name: tag.name
      };
    }));
    const filterdJobList = computed(() => {
      if (!params.search)
        return tagsData.slice(0, params.pagesize);
      const query = params.search.toLowerCase();
      return tagsData == null ? void 0 : tagsData.filter((item) => item.name.toLowerCase().includes(query));
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Tags" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitle, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: "Tags",
                    main: ""
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBoxModal, {
                    modelValue: isModalDangerActive.value,
                    "onUpdate:modelValue": ($event) => isModalDangerActive.value = $event,
                    title: "Warning",
                    button: "danger",
                    onConfirm: deleteData,
                    buttonLabel: "Delete",
                    "has-cancel": ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<p${_scopeId3}>Do you really want to delete?</p>`);
                      } else {
                        return [
                          createVNode("p", null, "Do you really want to delete?")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="flex"${_scopeId2}>`);
                  if (unref(hasPermission)("tags.create") || unref(hasPermission)("tags.update")) {
                    _push3(ssrRenderComponent(CardBox, {
                      class: "w-1/2 mb-6 mr-4",
                      "is-form": "",
                      onSubmit: submit
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(FormSuccess, null, null, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(FormField, {
                            label: "Name",
                            "label-for": "name",
                            help: "Please enter tag name"
                          }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).name,
                                  "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                  id: "name",
                                  autocomplete: "title",
                                  type: "text",
                                  required: ""
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).name,
                                    "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                    id: "name",
                                    autocomplete: "title",
                                    type: "text",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(BaseButtonLink, {
                            type: "submit",
                            color: "info",
                            label: "Save",
                            class: { "opacity-25": unref(form).processing },
                            disabled: unref(form).processing
                          }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(FormSuccess),
                            createVNode(FormField, {
                              label: "Name",
                              "label-for": "name",
                              help: "Please enter tag name"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).name,
                                  "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                  id: "name",
                                  autocomplete: "title",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(BaseButtonLink, {
                              type: "submit",
                              color: "info",
                              label: "Save",
                              class: { "opacity-25": unref(form).processing },
                              disabled: unref(form).processing
                            }, null, 8, ["class", "disabled"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(ssrRenderComponent(CardBox, {
                    class: "mb-6 relative overflow-x-auto shadow-md sm:rounded-lg",
                    "has-table": ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormSuccess, { class: "pt-5 pl-5" }, null, _parent4, _scopeId3));
                        _push4(`<div class="flex justify-between px-3 pt-4"${_scopeId3}>`);
                        _push4(ssrRenderComponent(FormControl, {
                          modelValue: params.search,
                          "onUpdate:modelValue": ($event) => params.search = $event,
                          type: "text",
                          placeholder: "Search..."
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                        _push4(ssrRenderComponent(unref(Vue3Datatable), {
                          rows: rows.value,
                          columns: cols.value,
                          sortable: true,
                          sortColumn: params.sort_column,
                          sortDirection: params.sort_direction,
                          search: params.search,
                          columnFilter: true,
                          onChange: filterdJobList.value,
                          cloneHeaderInFooter: true,
                          skin: "bh-table-compact",
                          class: "column-filter p-4",
                          rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                        }, {
                          action: withCtx((data, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<template class="flex"${_scopeId4}>`);
                              if (unref(hasPermission)("tags.update")) {
                                _push5(ssrRenderComponent(BaseButtonLink, {
                                  icon: "fas fa-edit",
                                  label: "Edit",
                                  color: "info",
                                  small: "",
                                  onClick: ($event) => dataEdit(data.value)
                                }, null, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                              if (unref(hasPermission)("tags.delete")) {
                                _push5(ssrRenderComponent(BaseButtonLink, {
                                  class: "ml-2",
                                  icon: "fas fa-trash-alt",
                                  label: "Delete",
                                  color: "danger",
                                  small: "",
                                  onClick: ($event) => showModle(data.value.id)
                                }, null, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                              _push5(`</template>`);
                            } else {
                              return [
                                createVNode("template", { class: "flex" }, [
                                  unref(hasPermission)("tags.update") ? (openBlock(), createBlock(BaseButtonLink, {
                                    key: 0,
                                    icon: "fas fa-edit",
                                    label: "Edit",
                                    color: "info",
                                    small: "",
                                    onClick: ($event) => dataEdit(data.value)
                                  }, null, 8, ["onClick"])) : createCommentVNode("", true),
                                  unref(hasPermission)("tags.delete") ? (openBlock(), createBlock(BaseButtonLink, {
                                    key: 1,
                                    class: "ml-2",
                                    icon: "fas fa-trash-alt",
                                    label: "Delete",
                                    color: "danger",
                                    small: "",
                                    onClick: ($event) => showModle(data.value.id)
                                  }, null, 8, ["onClick"])) : createCommentVNode("", true)
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormSuccess, { class: "pt-5 pl-5" }),
                          createVNode("div", { class: "flex justify-between px-3 pt-4" }, [
                            createVNode(FormControl, {
                              modelValue: params.search,
                              "onUpdate:modelValue": ($event) => params.search = $event,
                              type: "text",
                              placeholder: "Search..."
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode(unref(Vue3Datatable), {
                            rows: rows.value,
                            columns: cols.value,
                            sortable: true,
                            sortColumn: params.sort_column,
                            sortDirection: params.sort_direction,
                            search: params.search,
                            columnFilter: true,
                            onChange: filterdJobList.value,
                            cloneHeaderInFooter: true,
                            skin: "bh-table-compact",
                            class: "column-filter p-4",
                            rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                          }, {
                            action: withCtx((data) => [
                              createVNode("template", { class: "flex" }, [
                                unref(hasPermission)("tags.update") ? (openBlock(), createBlock(BaseButtonLink, {
                                  key: 0,
                                  icon: "fas fa-edit",
                                  label: "Edit",
                                  color: "info",
                                  small: "",
                                  onClick: ($event) => dataEdit(data.value)
                                }, null, 8, ["onClick"])) : createCommentVNode("", true),
                                unref(hasPermission)("tags.delete") ? (openBlock(), createBlock(BaseButtonLink, {
                                  key: 1,
                                  class: "ml-2",
                                  icon: "fas fa-trash-alt",
                                  label: "Delete",
                                  color: "danger",
                                  small: "",
                                  onClick: ($event) => showModle(data.value.id)
                                }, null, 8, ["onClick"])) : createCommentVNode("", true)
                              ])
                            ]),
                            _: 1
                          }, 8, ["rows", "columns", "sortColumn", "sortDirection", "search", "onChange"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitle, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: "Tags",
                      main: ""
                    }),
                    createVNode(CardBoxModal, {
                      modelValue: isModalDangerActive.value,
                      "onUpdate:modelValue": ($event) => isModalDangerActive.value = $event,
                      title: "Warning",
                      button: "danger",
                      onConfirm: deleteData,
                      buttonLabel: "Delete",
                      "has-cancel": ""
                    }, {
                      default: withCtx(() => [
                        createVNode("p", null, "Do you really want to delete?")
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode("div", { class: "flex" }, [
                      unref(hasPermission)("tags.create") || unref(hasPermission)("tags.update") ? (openBlock(), createBlock(CardBox, {
                        key: 0,
                        class: "w-1/2 mb-6 mr-4",
                        "is-form": "",
                        onSubmit: withModifiers(submit, ["prevent"])
                      }, {
                        default: withCtx(() => [
                          createVNode(FormSuccess),
                          createVNode(FormField, {
                            label: "Name",
                            "label-for": "name",
                            help: "Please enter tag name"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                autocomplete: "title",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseButtonLink, {
                            type: "submit",
                            color: "info",
                            label: "Save",
                            class: { "opacity-25": unref(form).processing },
                            disabled: unref(form).processing
                          }, null, 8, ["class", "disabled"])
                        ]),
                        _: 1
                      })) : createCommentVNode("", true),
                      createVNode(CardBox, {
                        class: "mb-6 relative overflow-x-auto shadow-md sm:rounded-lg",
                        "has-table": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(FormSuccess, { class: "pt-5 pl-5" }),
                          createVNode("div", { class: "flex justify-between px-3 pt-4" }, [
                            createVNode(FormControl, {
                              modelValue: params.search,
                              "onUpdate:modelValue": ($event) => params.search = $event,
                              type: "text",
                              placeholder: "Search..."
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode(unref(Vue3Datatable), {
                            rows: rows.value,
                            columns: cols.value,
                            sortable: true,
                            sortColumn: params.sort_column,
                            sortDirection: params.sort_direction,
                            search: params.search,
                            columnFilter: true,
                            onChange: filterdJobList.value,
                            cloneHeaderInFooter: true,
                            skin: "bh-table-compact",
                            class: "column-filter p-4",
                            rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                          }, {
                            action: withCtx((data) => [
                              createVNode("template", { class: "flex" }, [
                                unref(hasPermission)("tags.update") ? (openBlock(), createBlock(BaseButtonLink, {
                                  key: 0,
                                  icon: "fas fa-edit",
                                  label: "Edit",
                                  color: "info",
                                  small: "",
                                  onClick: ($event) => dataEdit(data.value)
                                }, null, 8, ["onClick"])) : createCommentVNode("", true),
                                unref(hasPermission)("tags.delete") ? (openBlock(), createBlock(BaseButtonLink, {
                                  key: 1,
                                  class: "ml-2",
                                  icon: "fas fa-trash-alt",
                                  label: "Delete",
                                  color: "danger",
                                  small: "",
                                  onClick: ($event) => showModle(data.value.id)
                                }, null, 8, ["onClick"])) : createCommentVNode("", true)
                              ])
                            ]),
                            _: 1
                          }, 8, ["rows", "columns", "sortColumn", "sortDirection", "search", "onChange"])
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Tags" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitle, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: "Tags",
                    main: ""
                  }),
                  createVNode(CardBoxModal, {
                    modelValue: isModalDangerActive.value,
                    "onUpdate:modelValue": ($event) => isModalDangerActive.value = $event,
                    title: "Warning",
                    button: "danger",
                    onConfirm: deleteData,
                    buttonLabel: "Delete",
                    "has-cancel": ""
                  }, {
                    default: withCtx(() => [
                      createVNode("p", null, "Do you really want to delete?")
                    ]),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode("div", { class: "flex" }, [
                    unref(hasPermission)("tags.create") || unref(hasPermission)("tags.update") ? (openBlock(), createBlock(CardBox, {
                      key: 0,
                      class: "w-1/2 mb-6 mr-4",
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormSuccess),
                        createVNode(FormField, {
                          label: "Name",
                          "label-for": "name",
                          help: "Please enter tag name"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).name,
                              "onUpdate:modelValue": ($event) => unref(form).name = $event,
                              id: "name",
                              autocomplete: "title",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(BaseButtonLink, {
                          type: "submit",
                          color: "info",
                          label: "Save",
                          class: { "opacity-25": unref(form).processing },
                          disabled: unref(form).processing
                        }, null, 8, ["class", "disabled"])
                      ]),
                      _: 1
                    })) : createCommentVNode("", true),
                    createVNode(CardBox, {
                      class: "mb-6 relative overflow-x-auto shadow-md sm:rounded-lg",
                      "has-table": ""
                    }, {
                      default: withCtx(() => [
                        createVNode(FormSuccess, { class: "pt-5 pl-5" }),
                        createVNode("div", { class: "flex justify-between px-3 pt-4" }, [
                          createVNode(FormControl, {
                            modelValue: params.search,
                            "onUpdate:modelValue": ($event) => params.search = $event,
                            type: "text",
                            placeholder: "Search..."
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        createVNode(unref(Vue3Datatable), {
                          rows: rows.value,
                          columns: cols.value,
                          sortable: true,
                          sortColumn: params.sort_column,
                          sortDirection: params.sort_direction,
                          search: params.search,
                          columnFilter: true,
                          onChange: filterdJobList.value,
                          cloneHeaderInFooter: true,
                          skin: "bh-table-compact",
                          class: "column-filter p-4",
                          rowClass: "bg-white dark:bg-slate-800 dark:text-slate-300 dark:border-gray-600"
                        }, {
                          action: withCtx((data) => [
                            createVNode("template", { class: "flex" }, [
                              unref(hasPermission)("tags.update") ? (openBlock(), createBlock(BaseButtonLink, {
                                key: 0,
                                icon: "fas fa-edit",
                                label: "Edit",
                                color: "info",
                                small: "",
                                onClick: ($event) => dataEdit(data.value)
                              }, null, 8, ["onClick"])) : createCommentVNode("", true),
                              unref(hasPermission)("tags.delete") ? (openBlock(), createBlock(BaseButtonLink, {
                                key: 1,
                                class: "ml-2",
                                icon: "fas fa-trash-alt",
                                label: "Delete",
                                color: "danger",
                                small: "",
                                onClick: ($event) => showModle(data.value.id)
                              }, null, 8, ["onClick"])) : createCommentVNode("", true)
                            ])
                          ]),
                          _: 1
                        }, 8, ["rows", "columns", "sortColumn", "sortDirection", "search", "onChange"])
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Blog/Tags.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
