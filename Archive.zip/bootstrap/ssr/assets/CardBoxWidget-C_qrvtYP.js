import { ref, onMounted, computed, watch, mergeProps, useSSRContext, withCtx, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { Chart, LineElement, PointElement, LineController, LinearScale, CategoryScale, Tooltip } from "chart.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import numeral from "numeral";
import { _ as _sfc_main$6 } from "./BaseIcon-C4zrUKd9.js";
import { _ as _sfc_main$7 } from "./BaseLevel-D_z-LHoc.js";
import { c as colorsOutline, a as colorsBgLight } from "./colors-K3EOgMMA.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
const chartColors = {
  default: {
    primary: "#00D1B2",
    info: "#209CEE",
    danger: "#FF3860"
  }
};
const datasetObject = (color, points) => {
  return {
    fill: false,
    borderColor: chartColors.default[color],
    borderWidth: 2,
    borderDash: [],
    borderDashOffset: 0,
    pointBackgroundColor: chartColors.default[color],
    pointBorderColor: "rgba(255,255,255,0)",
    pointHoverBackgroundColor: chartColors.default[color],
    pointBorderWidth: 20,
    pointHoverRadius: 4,
    pointHoverBorderWidth: 15,
    pointRadius: 4,
    data: [],
    tension: 0.5,
    cubicInterpolationMode: "default"
  };
};
const chartTemplate = (points = 12) => {
  const labels = [];
  for (let i = 1; i <= points; i++) {
    if (i < 10) {
      labels.push(`0${i}`);
    } else {
      labels.push(i);
    }
  }
  return {
    labels,
    datasets: [
      datasetObject("primary"),
      datasetObject("info"),
      datasetObject("success")
    ]
  };
};
const _sfc_main$5 = {
  __name: "LineChart",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const root = ref(null);
    let chart;
    Chart.register(LineElement, PointElement, LineController, LinearScale, CategoryScale, Tooltip);
    onMounted(() => {
      chart = new Chart(root.value, {
        type: "line",
        data: props.data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              display: false
            },
            x: {
              display: true
            }
          },
          plugins: {
            legend: {
              display: false
            }
          }
        }
      });
    });
    const chartData = computed(() => props.data);
    watch(chartData, (data) => {
      if (chart) {
        chart.data = data;
        chart.update();
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<canvas${ssrRenderAttrs(mergeProps({
        ref_key: "root",
        ref: root
      }, _attrs))}></canvas>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Charts/LineChart.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "NumberDynamic",
  __ssrInlineRender: true,
  props: {
    prefix: {
      type: String,
      default: null
    },
    suffix: {
      type: String,
      default: null
    },
    value: {
      type: Number,
      default: 0
    },
    duration: {
      type: Number,
      default: 500
    }
  },
  setup(__props) {
    const props = __props;
    const newValue = ref(0);
    const newValueFormatted = computed(
      () => newValue.value < 1e3 ? newValue.value : numeral(newValue.value).format("0,0")
    );
    const value = computed(() => props.value);
    const grow = (m) => {
      const v = Math.ceil(newValue.value + m);
      if (v > value.value) {
        newValue.value = value.value;
        return false;
      }
      newValue.value = v;
      setTimeout(() => {
        grow(m);
      }, 25);
    };
    const growInit = () => {
      newValue.value = 0;
      grow(props.value / (props.duration / 25));
    };
    watch(value, () => {
      growInit();
    });
    onMounted(() => {
      growInit();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>${ssrInterpolate(__props.prefix)}${ssrInterpolate(newValueFormatted.value)}${ssrInterpolate(__props.suffix)}</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NumberDynamic.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "PillTagPlain",
  __ssrInlineRender: true,
  props: {
    label: {
      type: String,
      required: true
    },
    icon: {
      type: String,
      default: null
    },
    small: Boolean
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["inline-flex items-center capitalize leading-none", [__props.small ? "text-xs" : "text-sm"]]
      }, _attrs))}>`);
      if (__props.icon) {
        _push(ssrRenderComponent(_sfc_main$6, {
          path: __props.icon,
          h: "h-4",
          w: "w-4",
          class: __props.small ? "mr-1" : "mr-2",
          size: __props.small ? 14 : null
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<span>${ssrInterpolate(__props.label)}</span></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/PillTagPlain.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "PillTag",
  __ssrInlineRender: true,
  props: {
    label: {
      type: String,
      required: true
    },
    color: {
      type: String,
      required: true
    },
    icon: {
      type: String,
      default: null
    },
    small: Boolean,
    outline: Boolean
  },
  setup(__props) {
    const props = __props;
    const componentClass = computed(() => [
      props.small ? "py-1 px-3" : "py-1.5 px-4",
      props.outline ? colorsOutline[props.color] : colorsBgLight[props.color]
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$3, mergeProps({
        class: ["border rounded-full", componentClass.value],
        icon: __props.icon,
        label: __props.label,
        small: __props.small
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/PillTag.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "PillTagTrend",
  __ssrInlineRender: true,
  props: {
    trend: {
      type: String,
      required: true
    },
    trendType: {
      type: String,
      default: null
    },
    small: Boolean
  },
  setup(__props) {
    const props = __props;
    const trendStyle = computed(() => {
      if (props.trendType === "up") {
        return {
          icon: "fas fa-chevron-up",
          style: "success"
        };
      }
      if (props.trendType === "down") {
        return {
          icon: "fas fa-chevron-down",
          style: "danger"
        };
      }
      if (props.trendType === "alert") {
        return {
          icon: "fas fa-exclamation-circle",
          style: "warning"
        };
      }
      return {
        style: "info"
      };
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$2, mergeProps({
        label: __props.trend,
        color: trendStyle.value.style,
        icon: trendStyle.value.icon,
        small: __props.small
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/PillTagTrend.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "CardBoxWidget",
  __ssrInlineRender: true,
  props: {
    number: {
      type: Number,
      default: 0
    },
    icon: {
      type: String,
      default: null
    },
    prefix: {
      type: String,
      default: null
    },
    suffix: {
      type: String,
      default: null
    },
    label: {
      type: String,
      default: null
    },
    color: {
      type: String,
      default: null
    },
    trend: {
      type: String,
      default: null
    },
    trendType: {
      type: String,
      default: null
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(CardBox, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (__props.trend) {
              _push2(ssrRenderComponent(_sfc_main$7, {
                class: "mb-3",
                mobile: ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$1, {
                      trend: __props.trend,
                      "trend-type": __props.trendType,
                      small: ""
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(BaseButtonLink, {
                      icon: "fas fa-cog",
                      "icon-w": "w-4",
                      "icon-h": "h-4",
                      color: "lightDark",
                      small: ""
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$1, {
                        trend: __props.trend,
                        "trend-type": __props.trendType,
                        small: ""
                      }, null, 8, ["trend", "trend-type"]),
                      createVNode(BaseButtonLink, {
                        icon: "fas fa-cog",
                        "icon-w": "w-4",
                        "icon-h": "h-4",
                        color: "lightDark",
                        small: ""
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(_sfc_main$7, { mobile: "" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div${_scopeId2}><h3 class="text-lg leading-tight text-gray-500 dark:text-slate-400"${_scopeId2}>${ssrInterpolate(__props.label)}</h3><h1 class="text-3xl leading-tight font-semibold"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    value: __props.number,
                    prefix: __props.prefix,
                    suffix: __props.suffix
                  }, null, _parent3, _scopeId2));
                  _push3(`</h1></div>`);
                  if (__props.icon) {
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      path: __props.icon,
                      size: "48",
                      w: "",
                      h: "h-16",
                      class: __props.color
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                } else {
                  return [
                    createVNode("div", null, [
                      createVNode("h3", { class: "text-lg leading-tight text-gray-500 dark:text-slate-400" }, toDisplayString(__props.label), 1),
                      createVNode("h1", { class: "text-3xl leading-tight font-semibold" }, [
                        createVNode(_sfc_main$4, {
                          value: __props.number,
                          prefix: __props.prefix,
                          suffix: __props.suffix
                        }, null, 8, ["value", "prefix", "suffix"])
                      ])
                    ]),
                    __props.icon ? (openBlock(), createBlock(_sfc_main$6, {
                      key: 0,
                      path: __props.icon,
                      size: "48",
                      w: "",
                      h: "h-16",
                      class: __props.color
                    }, null, 8, ["path", "class"])) : createCommentVNode("", true)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              __props.trend ? (openBlock(), createBlock(_sfc_main$7, {
                key: 0,
                class: "mb-3",
                mobile: ""
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$1, {
                    trend: __props.trend,
                    "trend-type": __props.trendType,
                    small: ""
                  }, null, 8, ["trend", "trend-type"]),
                  createVNode(BaseButtonLink, {
                    icon: "fas fa-cog",
                    "icon-w": "w-4",
                    "icon-h": "h-4",
                    color: "lightDark",
                    small: ""
                  })
                ]),
                _: 1
              })) : createCommentVNode("", true),
              createVNode(_sfc_main$7, { mobile: "" }, {
                default: withCtx(() => [
                  createVNode("div", null, [
                    createVNode("h3", { class: "text-lg leading-tight text-gray-500 dark:text-slate-400" }, toDisplayString(__props.label), 1),
                    createVNode("h1", { class: "text-3xl leading-tight font-semibold" }, [
                      createVNode(_sfc_main$4, {
                        value: __props.number,
                        prefix: __props.prefix,
                        suffix: __props.suffix
                      }, null, 8, ["value", "prefix", "suffix"])
                    ])
                  ]),
                  __props.icon ? (openBlock(), createBlock(_sfc_main$6, {
                    key: 0,
                    path: __props.icon,
                    size: "48",
                    w: "",
                    h: "h-16",
                    class: __props.color
                  }, null, 8, ["path", "class"])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/CardBoxWidget.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _,
  _sfc_main$5 as a,
  chartTemplate as c
};
