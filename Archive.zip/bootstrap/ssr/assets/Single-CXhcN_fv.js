import { withCtx, unref, createVNode, toDisplayString, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { usePage, Head } from "@inertiajs/vue3";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./IconRounded-RF1xkXym.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {
  __name: "Single",
  __ssrInlineRender: true,
  setup(__props) {
    const applicationData = usePage().props.applicationData;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(applicationData).job.title
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(applicationData).job.title,
                    main: ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "jobs.applications.list",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            icon: "far fa-arrow-alt-circle-left",
                            label: "Back",
                            routeName: "jobs.applications.list",
                            color: "contrast",
                            "rounded-full": "",
                            small: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="flex justify-center"${_scopeId2}>`);
                  _push3(ssrRenderComponent(CardBox, { class: "w-1/5 dark:bg-white dark:text-blue-950" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<p class="text-xl mb-1"${_scopeId3}>Job Post By: ${ssrInterpolate(unref(applicationData).job.user.name)}</p><p class="text-xl mb-1"${_scopeId3}>Posted on: ${ssrInterpolate(unref(applicationData).job.created_at)}</p><p class="text-xl mb-1"${_scopeId3}>Closing on: ${ssrInterpolate(unref(applicationData).job.closing_date)}</p><p class="text-xl mb-1"${_scopeId3}>Status: ${ssrInterpolate(unref(applicationData).job.status == 1 ? "Active" : "Draft")}</p>`);
                      } else {
                        return [
                          createVNode("p", { class: "text-xl mb-1" }, "Job Post By: " + toDisplayString(unref(applicationData).job.user.name), 1),
                          createVNode("p", { class: "text-xl mb-1" }, "Posted on: " + toDisplayString(unref(applicationData).job.created_at), 1),
                          createVNode("p", { class: "text-xl mb-1" }, "Closing on: " + toDisplayString(unref(applicationData).job.closing_date), 1),
                          createVNode("p", { class: "text-xl mb-1" }, "Status: " + toDisplayString(unref(applicationData).job.status == 1 ? "Active" : "Draft"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, { class: "w-4/5 ml-3 dark:bg-white dark:text-slate-950" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<h2 class="text-3xl font-bold"${_scopeId3}>Title: ${ssrInterpolate(unref(applicationData).job.title)}</h2><hr class="mb-2"${_scopeId3}><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Category:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.category.name)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Job type:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.job_type)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Level:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.job_level)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Category:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.category.name)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Category:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.category.name)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Location:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.location)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Description:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.description)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Requirements:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.requirements)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Responsibilities:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).responsibilities)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Salary:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.salary)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Facilities:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).job.facilities)}</span></h2><h2 class="mb-2"${_scopeId3}><span class="font-bold text-lg"${_scopeId3}>Skills:</span> <span${_scopeId3}>${ssrInterpolate(unref(applicationData).skills)}</span></h2>`);
                      } else {
                        return [
                          createVNode("h2", { class: "text-3xl font-bold" }, "Title: " + toDisplayString(unref(applicationData).job.title), 1),
                          createVNode("hr", { class: "mb-2" }),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Job type:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.job_type), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Level:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.job_level), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Location:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.location), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Description:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.description), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Requirements:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.requirements), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Responsibilities:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).responsibilities), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Salary:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.salary), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Facilities:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.facilities), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Skills:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).skills), 1)
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: unref(applicationData).job.title,
                      main: ""
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "jobs.applications.list",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        })
                      ]),
                      _: 1
                    }, 8, ["title"]),
                    createVNode("div", { class: "flex justify-center" }, [
                      createVNode(CardBox, { class: "w-1/5 dark:bg-white dark:text-blue-950" }, {
                        default: withCtx(() => [
                          createVNode("p", { class: "text-xl mb-1" }, "Job Post By: " + toDisplayString(unref(applicationData).job.user.name), 1),
                          createVNode("p", { class: "text-xl mb-1" }, "Posted on: " + toDisplayString(unref(applicationData).job.created_at), 1),
                          createVNode("p", { class: "text-xl mb-1" }, "Closing on: " + toDisplayString(unref(applicationData).job.closing_date), 1),
                          createVNode("p", { class: "text-xl mb-1" }, "Status: " + toDisplayString(unref(applicationData).job.status == 1 ? "Active" : "Draft"), 1)
                        ]),
                        _: 1
                      }),
                      createVNode(CardBox, { class: "w-4/5 ml-3 dark:bg-white dark:text-slate-950" }, {
                        default: withCtx(() => [
                          createVNode("h2", { class: "text-3xl font-bold" }, "Title: " + toDisplayString(unref(applicationData).job.title), 1),
                          createVNode("hr", { class: "mb-2" }),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Job type:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.job_type), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Level:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.job_level), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Location:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.location), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Description:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.description), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Requirements:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.requirements), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Responsibilities:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).responsibilities), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Salary:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.salary), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Facilities:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).job.facilities), 1)
                          ]),
                          createVNode("h2", { class: "mb-2" }, [
                            createVNode("span", { class: "font-bold text-lg" }, "Skills:"),
                            createTextVNode(),
                            createVNode("span", null, toDisplayString(unref(applicationData).skills), 1)
                          ])
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(applicationData).job.title
              }, null, 8, ["title"]),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(applicationData).job.title,
                    main: ""
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        icon: "far fa-arrow-alt-circle-left",
                        label: "Back",
                        routeName: "jobs.applications.list",
                        color: "contrast",
                        "rounded-full": "",
                        small: ""
                      })
                    ]),
                    _: 1
                  }, 8, ["title"]),
                  createVNode("div", { class: "flex justify-center" }, [
                    createVNode(CardBox, { class: "w-1/5 dark:bg-white dark:text-blue-950" }, {
                      default: withCtx(() => [
                        createVNode("p", { class: "text-xl mb-1" }, "Job Post By: " + toDisplayString(unref(applicationData).job.user.name), 1),
                        createVNode("p", { class: "text-xl mb-1" }, "Posted on: " + toDisplayString(unref(applicationData).job.created_at), 1),
                        createVNode("p", { class: "text-xl mb-1" }, "Closing on: " + toDisplayString(unref(applicationData).job.closing_date), 1),
                        createVNode("p", { class: "text-xl mb-1" }, "Status: " + toDisplayString(unref(applicationData).job.status == 1 ? "Active" : "Draft"), 1)
                      ]),
                      _: 1
                    }),
                    createVNode(CardBox, { class: "w-4/5 ml-3 dark:bg-white dark:text-slate-950" }, {
                      default: withCtx(() => [
                        createVNode("h2", { class: "text-3xl font-bold" }, "Title: " + toDisplayString(unref(applicationData).job.title), 1),
                        createVNode("hr", { class: "mb-2" }),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Job type:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.job_type), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Level:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.job_level), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Category:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.category.name), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Location:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.location), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Description:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.description), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Requirements:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.requirements), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Responsibilities:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).responsibilities), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Salary:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.salary), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Facilities:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).job.facilities), 1)
                        ]),
                        createVNode("h2", { class: "mb-2" }, [
                          createVNode("span", { class: "font-bold text-lg" }, "Skills:"),
                          createTextVNode(),
                          createVNode("span", null, toDisplayString(unref(applicationData).skills), 1)
                        ])
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Applications/Single.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
