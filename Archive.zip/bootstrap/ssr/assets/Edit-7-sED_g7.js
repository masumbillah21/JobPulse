import { defineComponent, ref, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { F as FormFilePicker } from "./FormFilePicker-BtfvB5iT.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { i as isSystemUser } from "./isSystemUser-D-zJOoLX.js";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import CKEditor from "@ckeditor/ckeditor5-vue";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./IconRounded-RF1xkXym.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const style = `
        .ck-editor__editable {
            min-height: 300px; /* Adjust the height as per your requirement */
        }
        .ck-powered-by-balloon {
            display: none !important;
        }
    `;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  setup(__props) {
    const blogData = usePage().props.blogData ?? null;
    const categoryData = usePage().props.categoryData ?? null;
    const fileInputKey = ref(0);
    const editor = ClassicEditor;
    const onChange = (data) => {
      form.body = data;
      addStyle();
    };
    const addStyle = () => {
      const styleElement = document.createElement("style");
      styleElement.textContent = style;
      document.head.appendChild(styleElement);
    };
    const form = useForm({
      id: 0,
      title: "",
      body: "",
      image: "",
      status: "",
      categories: [],
      tags: "",
      _method: "post"
    });
    if (blogData !== null) {
      form.id = blogData.id;
      form.title = blogData.title;
      form.body = blogData.body;
      form.status = blogData.status;
      form.categories = blogData.category_ids;
      form.tags = blogData.tags.map((tag) => tag.name);
      form._method = "put";
    }
    const submit = () => {
      if (blogData !== null) {
        update();
      } else {
        create();
      }
    };
    const create = () => {
      const routeName = isSystemUser() ? "admin.blogs.store" : "blogs.store";
      form.post(route(routeName), {
        onSuccess: () => {
          form.reset();
          fileInputKey.value = fileInputKey.value + 1;
        }
      });
    };
    const update = () => {
      form.post(route(isSystemUser() ? "admin.blogs.update" : "blogs.update", form.id));
    };
    addStyle();
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(blogData) !== null ? "Edit Post" : "Create Post"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(blogData) !== null ? "Edit Post" : "Create Post",
                    main: ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "blogs.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            icon: "far fa-arrow-alt-circle-left",
                            label: "Back",
                            routeName: "blogs.index",
                            color: "contrast",
                            "rounded-full": "",
                            small: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, {
                    class: "my-24 w-full",
                    "is-form": "",
                    onSubmit: submit
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormSuccess, null, null, _parent4, _scopeId3));
                        _push4(`<div class="flex justify-center"${_scopeId3}>`);
                        _push4(ssrRenderComponent(CardBox, { class: "w-4/5" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormField, {
                                label: "Tilte",
                                "label-for": "title",
                                help: "Please enter post title"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(FormControl, {
                                      modelValue: unref(form).title,
                                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                      id: "title",
                                      autocomplete: "title",
                                      type: "text",
                                      required: ""
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(FormControl, {
                                        modelValue: unref(form).title,
                                        "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                        id: "title",
                                        autocomplete: "title",
                                        type: "text",
                                        required: ""
                                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(`<p${_scopeId4}>Content</p><div class="dark:text-black min-h-24"${_scopeId4}>`);
                              _push5(ssrRenderComponent(unref(CKEditor).component, {
                                modelValue: unref(form).body,
                                "onUpdate:modelValue": ($event) => unref(form).body = $event,
                                editor: unref(editor),
                                onChange
                              }, null, _parent5, _scopeId4));
                              _push5(`</div>`);
                            } else {
                              return [
                                createVNode(FormField, {
                                  label: "Tilte",
                                  "label-for": "title",
                                  help: "Please enter post title"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(FormControl, {
                                      modelValue: unref(form).title,
                                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                      id: "title",
                                      autocomplete: "title",
                                      type: "text",
                                      required: ""
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 1
                                }),
                                createVNode("p", null, "Content"),
                                createVNode("div", { class: "dark:text-black min-h-24" }, [
                                  createVNode(unref(CKEditor).component, {
                                    modelValue: unref(form).body,
                                    "onUpdate:modelValue": ($event) => unref(form).body = $event,
                                    editor: unref(editor),
                                    onChange
                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "editor"])
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(CardBox, { class: "ml-2 w-1/5" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormField, {
                                class: "w-full",
                                label: "Select Categories"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<div class="overflow-y-auto max-h-[150px]"${_scopeId5}>`);
                                    _push6(ssrRenderComponent(FormCheckRadioGroup, {
                                      componentClass: "w-full",
                                      modelValue: unref(form).categories,
                                      "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                                      name: "categories[]",
                                      type: "checkbox",
                                      options: unref(categoryData)
                                    }, null, _parent6, _scopeId5));
                                    _push6(`</div>`);
                                  } else {
                                    return [
                                      createVNode("div", { class: "overflow-y-auto max-h-[150px]" }, [
                                        createVNode(FormCheckRadioGroup, {
                                          componentClass: "w-full",
                                          modelValue: unref(form).categories,
                                          "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                                          name: "categories[]",
                                          type: "checkbox",
                                          options: unref(categoryData)
                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                                      ])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(FormField, {
                                label: "Tags",
                                "label-for": "tag",
                                help: "Please write tag (add multiple tags seperated by coma.)"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(FormControl, {
                                      modelValue: unref(form).tags,
                                      "onUpdate:modelValue": ($event) => unref(form).tags = $event,
                                      id: "tag",
                                      autocomplete: "tag",
                                      type: "text",
                                      required: ""
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(FormControl, {
                                        modelValue: unref(form).tags,
                                        "onUpdate:modelValue": ($event) => unref(form).tags = $event,
                                        id: "tag",
                                        autocomplete: "tag",
                                        type: "text",
                                        required: ""
                                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              if (unref(blogData) && unref(blogData).image) {
                                _push5(`<img${ssrRenderAttr("src", unref(blogData).image)} alt=""${_scopeId4}>`);
                              } else {
                                _push5(`<!---->`);
                              }
                              _push5(ssrRenderComponent(FormField, {
                                label: "Featued Image",
                                help: "Max 500kb"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(FormFilePicker, {
                                      key: fileInputKey.value,
                                      label: "Upload Image",
                                      color: "success",
                                      "onUpdate:modelValue": ($event) => unref(form).image = $event
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      (openBlock(), createBlock(FormFilePicker, {
                                        key: fileInputKey.value,
                                        label: "Upload Image",
                                        color: "success",
                                        "onUpdate:modelValue": ($event) => unref(form).image = $event
                                      }, null, 8, ["onUpdate:modelValue"]))
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(FormCheckRadioGroup, {
                                label: "Status",
                                class: "mb-3",
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                name: "status",
                                type: "radio",
                                options: { "1": "Publish", "0": "Draft" }
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(BaseButtons, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(BaseButtonLink, {
                                      type: "submit",
                                      color: "info",
                                      label: unref(blogData) !== null ? "Update" : "Create",
                                      class: { "opacity-25": unref(form).processing },
                                      disabled: unref(form).processing
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(BaseButtonLink, {
                                        type: "submit",
                                        color: "info",
                                        label: unref(blogData) !== null ? "Update" : "Create",
                                        class: { "opacity-25": unref(form).processing },
                                        disabled: unref(form).processing
                                      }, null, 8, ["label", "class", "disabled"])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormField, {
                                  class: "w-full",
                                  label: "Select Categories"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "overflow-y-auto max-h-[150px]" }, [
                                      createVNode(FormCheckRadioGroup, {
                                        componentClass: "w-full",
                                        modelValue: unref(form).categories,
                                        "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                                        name: "categories[]",
                                        type: "checkbox",
                                        options: unref(categoryData)
                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(FormField, {
                                  label: "Tags",
                                  "label-for": "tag",
                                  help: "Please write tag (add multiple tags seperated by coma.)"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(FormControl, {
                                      modelValue: unref(form).tags,
                                      "onUpdate:modelValue": ($event) => unref(form).tags = $event,
                                      id: "tag",
                                      autocomplete: "tag",
                                      type: "text",
                                      required: ""
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 1
                                }),
                                unref(blogData) && unref(blogData).image ? (openBlock(), createBlock("img", {
                                  key: 0,
                                  src: unref(blogData).image,
                                  alt: ""
                                }, null, 8, ["src"])) : createCommentVNode("", true),
                                createVNode(FormField, {
                                  label: "Featued Image",
                                  help: "Max 500kb"
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(), createBlock(FormFilePicker, {
                                      key: fileInputKey.value,
                                      label: "Upload Image",
                                      color: "success",
                                      "onUpdate:modelValue": ($event) => unref(form).image = $event
                                    }, null, 8, ["onUpdate:modelValue"]))
                                  ]),
                                  _: 1
                                }),
                                createVNode(FormCheckRadioGroup, {
                                  label: "Status",
                                  class: "mb-3",
                                  modelValue: unref(form).status,
                                  "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                  name: "status",
                                  type: "radio",
                                  options: { "1": "Publish", "0": "Draft" }
                                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                                createVNode(BaseButtons, null, {
                                  default: withCtx(() => [
                                    createVNode(BaseButtonLink, {
                                      type: "submit",
                                      color: "info",
                                      label: unref(blogData) !== null ? "Update" : "Create",
                                      class: { "opacity-25": unref(form).processing },
                                      disabled: unref(form).processing
                                    }, null, 8, ["label", "class", "disabled"])
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          createVNode("div", { class: "flex justify-center" }, [
                            createVNode(CardBox, { class: "w-4/5" }, {
                              default: withCtx(() => [
                                createVNode(FormField, {
                                  label: "Tilte",
                                  "label-for": "title",
                                  help: "Please enter post title"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(FormControl, {
                                      modelValue: unref(form).title,
                                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                      id: "title",
                                      autocomplete: "title",
                                      type: "text",
                                      required: ""
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 1
                                }),
                                createVNode("p", null, "Content"),
                                createVNode("div", { class: "dark:text-black min-h-24" }, [
                                  createVNode(unref(CKEditor).component, {
                                    modelValue: unref(form).body,
                                    "onUpdate:modelValue": ($event) => unref(form).body = $event,
                                    editor: unref(editor),
                                    onChange
                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "editor"])
                                ])
                              ]),
                              _: 1
                            }),
                            createVNode(CardBox, { class: "ml-2 w-1/5" }, {
                              default: withCtx(() => [
                                createVNode(FormField, {
                                  class: "w-full",
                                  label: "Select Categories"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "overflow-y-auto max-h-[150px]" }, [
                                      createVNode(FormCheckRadioGroup, {
                                        componentClass: "w-full",
                                        modelValue: unref(form).categories,
                                        "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                                        name: "categories[]",
                                        type: "checkbox",
                                        options: unref(categoryData)
                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(FormField, {
                                  label: "Tags",
                                  "label-for": "tag",
                                  help: "Please write tag (add multiple tags seperated by coma.)"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(FormControl, {
                                      modelValue: unref(form).tags,
                                      "onUpdate:modelValue": ($event) => unref(form).tags = $event,
                                      id: "tag",
                                      autocomplete: "tag",
                                      type: "text",
                                      required: ""
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 1
                                }),
                                unref(blogData) && unref(blogData).image ? (openBlock(), createBlock("img", {
                                  key: 0,
                                  src: unref(blogData).image,
                                  alt: ""
                                }, null, 8, ["src"])) : createCommentVNode("", true),
                                createVNode(FormField, {
                                  label: "Featued Image",
                                  help: "Max 500kb"
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(), createBlock(FormFilePicker, {
                                      key: fileInputKey.value,
                                      label: "Upload Image",
                                      color: "success",
                                      "onUpdate:modelValue": ($event) => unref(form).image = $event
                                    }, null, 8, ["onUpdate:modelValue"]))
                                  ]),
                                  _: 1
                                }),
                                createVNode(FormCheckRadioGroup, {
                                  label: "Status",
                                  class: "mb-3",
                                  modelValue: unref(form).status,
                                  "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                  name: "status",
                                  type: "radio",
                                  options: { "1": "Publish", "0": "Draft" }
                                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                                createVNode(BaseButtons, null, {
                                  default: withCtx(() => [
                                    createVNode(BaseButtonLink, {
                                      type: "submit",
                                      color: "info",
                                      label: unref(blogData) !== null ? "Update" : "Create",
                                      class: { "opacity-25": unref(form).processing },
                                      disabled: unref(form).processing
                                    }, null, 8, ["label", "class", "disabled"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: unref(blogData) !== null ? "Edit Post" : "Create Post",
                      main: ""
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "blogs.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        })
                      ]),
                      _: 1
                    }, 8, ["title"]),
                    createVNode(CardBox, {
                      class: "my-24 w-full",
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormSuccess),
                        createVNode("div", { class: "flex justify-center" }, [
                          createVNode(CardBox, { class: "w-4/5" }, {
                            default: withCtx(() => [
                              createVNode(FormField, {
                                label: "Tilte",
                                "label-for": "title",
                                help: "Please enter post title"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).title,
                                    "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                    id: "title",
                                    autocomplete: "title",
                                    type: "text",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              createVNode("p", null, "Content"),
                              createVNode("div", { class: "dark:text-black min-h-24" }, [
                                createVNode(unref(CKEditor).component, {
                                  modelValue: unref(form).body,
                                  "onUpdate:modelValue": ($event) => unref(form).body = $event,
                                  editor: unref(editor),
                                  onChange
                                }, null, 8, ["modelValue", "onUpdate:modelValue", "editor"])
                              ])
                            ]),
                            _: 1
                          }),
                          createVNode(CardBox, { class: "ml-2 w-1/5" }, {
                            default: withCtx(() => [
                              createVNode(FormField, {
                                class: "w-full",
                                label: "Select Categories"
                              }, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "overflow-y-auto max-h-[150px]" }, [
                                    createVNode(FormCheckRadioGroup, {
                                      componentClass: "w-full",
                                      modelValue: unref(form).categories,
                                      "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                                      name: "categories[]",
                                      type: "checkbox",
                                      options: unref(categoryData)
                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(FormField, {
                                label: "Tags",
                                "label-for": "tag",
                                help: "Please write tag (add multiple tags seperated by coma.)"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).tags,
                                    "onUpdate:modelValue": ($event) => unref(form).tags = $event,
                                    id: "tag",
                                    autocomplete: "tag",
                                    type: "text",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              unref(blogData) && unref(blogData).image ? (openBlock(), createBlock("img", {
                                key: 0,
                                src: unref(blogData).image,
                                alt: ""
                              }, null, 8, ["src"])) : createCommentVNode("", true),
                              createVNode(FormField, {
                                label: "Featued Image",
                                help: "Max 500kb"
                              }, {
                                default: withCtx(() => [
                                  (openBlock(), createBlock(FormFilePicker, {
                                    key: fileInputKey.value,
                                    label: "Upload Image",
                                    color: "success",
                                    "onUpdate:modelValue": ($event) => unref(form).image = $event
                                  }, null, 8, ["onUpdate:modelValue"]))
                                ]),
                                _: 1
                              }),
                              createVNode(FormCheckRadioGroup, {
                                label: "Status",
                                class: "mb-3",
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                name: "status",
                                type: "radio",
                                options: { "1": "Publish", "0": "Draft" }
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(BaseButtons, null, {
                                default: withCtx(() => [
                                  createVNode(BaseButtonLink, {
                                    type: "submit",
                                    color: "info",
                                    label: unref(blogData) !== null ? "Update" : "Create",
                                    class: { "opacity-25": unref(form).processing },
                                    disabled: unref(form).processing
                                  }, null, 8, ["label", "class", "disabled"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(blogData) !== null ? "Edit Post" : "Create Post"
              }, null, 8, ["title"]),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(blogData) !== null ? "Edit Post" : "Create Post",
                    main: ""
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        icon: "far fa-arrow-alt-circle-left",
                        label: "Back",
                        routeName: "blogs.index",
                        color: "contrast",
                        "rounded-full": "",
                        small: ""
                      })
                    ]),
                    _: 1
                  }, 8, ["title"]),
                  createVNode(CardBox, {
                    class: "my-24 w-full",
                    "is-form": "",
                    onSubmit: withModifiers(submit, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(FormValidationErrors),
                      createVNode(FormSuccess),
                      createVNode("div", { class: "flex justify-center" }, [
                        createVNode(CardBox, { class: "w-4/5" }, {
                          default: withCtx(() => [
                            createVNode(FormField, {
                              label: "Tilte",
                              "label-for": "title",
                              help: "Please enter post title"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).title,
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  id: "title",
                                  autocomplete: "title",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode("p", null, "Content"),
                            createVNode("div", { class: "dark:text-black min-h-24" }, [
                              createVNode(unref(CKEditor).component, {
                                modelValue: unref(form).body,
                                "onUpdate:modelValue": ($event) => unref(form).body = $event,
                                editor: unref(editor),
                                onChange
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "editor"])
                            ])
                          ]),
                          _: 1
                        }),
                        createVNode(CardBox, { class: "ml-2 w-1/5" }, {
                          default: withCtx(() => [
                            createVNode(FormField, {
                              class: "w-full",
                              label: "Select Categories"
                            }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "overflow-y-auto max-h-[150px]" }, [
                                  createVNode(FormCheckRadioGroup, {
                                    componentClass: "w-full",
                                    modelValue: unref(form).categories,
                                    "onUpdate:modelValue": ($event) => unref(form).categories = $event,
                                    name: "categories[]",
                                    type: "checkbox",
                                    options: unref(categoryData)
                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                                ])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Tags",
                              "label-for": "tag",
                              help: "Please write tag (add multiple tags seperated by coma.)"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).tags,
                                  "onUpdate:modelValue": ($event) => unref(form).tags = $event,
                                  id: "tag",
                                  autocomplete: "tag",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            unref(blogData) && unref(blogData).image ? (openBlock(), createBlock("img", {
                              key: 0,
                              src: unref(blogData).image,
                              alt: ""
                            }, null, 8, ["src"])) : createCommentVNode("", true),
                            createVNode(FormField, {
                              label: "Featued Image",
                              help: "Max 500kb"
                            }, {
                              default: withCtx(() => [
                                (openBlock(), createBlock(FormFilePicker, {
                                  key: fileInputKey.value,
                                  label: "Upload Image",
                                  color: "success",
                                  "onUpdate:modelValue": ($event) => unref(form).image = $event
                                }, null, 8, ["onUpdate:modelValue"]))
                              ]),
                              _: 1
                            }),
                            createVNode(FormCheckRadioGroup, {
                              label: "Status",
                              class: "mb-3",
                              modelValue: unref(form).status,
                              "onUpdate:modelValue": ($event) => unref(form).status = $event,
                              name: "status",
                              type: "radio",
                              options: { "1": "Publish", "0": "Draft" }
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(BaseButtons, null, {
                              default: withCtx(() => [
                                createVNode(BaseButtonLink, {
                                  type: "submit",
                                  color: "info",
                                  label: unref(blogData) !== null ? "Update" : "Create",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["label", "class", "disabled"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Blog/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
