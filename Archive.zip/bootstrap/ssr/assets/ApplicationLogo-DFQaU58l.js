import { defineComponent, unref, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate } from "vue/server-renderer";
import { usePage } from "@inertiajs/vue3";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ApplicationLogo",
  __ssrInlineRender: true,
  props: {
    logoSize: {
      type: String,
      default: "250"
    }
  },
  setup(__props) {
    const siteLogo = usePage().props.logo;
    const urls = usePage().props.urls;
    const siteTitle = usePage().props.siteTitle ?? "JobPulse";
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(siteLogo)) {
        _push(`<img${ssrRenderAttrs(mergeProps({
          src: unref(urls).storeUrl + "/" + unref(siteLogo),
          width: __props.logoSize,
          alt: unref(siteTitle)
        }, _attrs))}>`);
      } else {
        _push(`<span${ssrRenderAttrs(_attrs)}>${ssrInterpolate(unref(siteTitle))}</span>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/ApplicationLogo.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
