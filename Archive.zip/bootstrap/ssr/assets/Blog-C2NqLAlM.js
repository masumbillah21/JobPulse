import { defineComponent, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderStyle } from "vue/server-renderer";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { S as SectionTitle } from "./SectionTitle-qF5u6qV8.js";
import "./main-C5vGb8af.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./IconRounded-RF1xkXym.js";
import "./colors-K3EOgMMA.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Blog",
  __ssrInlineRender: true,
  props: {
    row: {
      type: Object,
      required: true
    },
    sectionIndex: {
      type: Number,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(SectionTitle, {
        title: __props.row.name,
        main: ""
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(__props.row.data, (data, rowIndex) => {
        _push(`<div style="${ssrRenderStyle(!__props.row.hidden ? null : { display: "none" })}" class="mb-2 flex-col justify-end items-end h-full"><div class="w-full mb-7 p-5 dark:bg-slate-900 bg-gray-100 rounded">`);
        _push(ssrRenderComponent(FormField, {
          label: "Title: " + data.title,
          "label-for": "headline-" + (rowIndex + __props.sectionIndex)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(FormControl, {
                modelValue: data.title,
                "onUpdate:modelValue": ($event) => data.title = $event,
                id: "headline-" + (rowIndex + __props.sectionIndex),
                placeholder: "Title here",
                type: "text",
                required: ""
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(FormControl, {
                  modelValue: data.title,
                  "onUpdate:modelValue": ($event) => data.title = $event,
                  id: "headline-" + (rowIndex + __props.sectionIndex),
                  placeholder: "Title here",
                  type: "text",
                  required: ""
                }, null, 8, ["modelValue", "onUpdate:modelValue", "id"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(FormField, {
          label: "Subtitle",
          "label-for": "subtitle-" + (rowIndex + __props.sectionIndex)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(FormControl, {
                modelValue: data.subtitle,
                "onUpdate:modelValue": ($event) => data.subtitle = $event,
                id: "subtitle-" + (rowIndex + __props.sectionIndex),
                placeholder: "Subtitle here",
                type: "text"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(FormControl, {
                  modelValue: data.subtitle,
                  "onUpdate:modelValue": ($event) => data.subtitle = $event,
                  id: "subtitle-" + (rowIndex + __props.sectionIndex),
                  placeholder: "Subtitle here",
                  type: "text"
                }, null, 8, ["modelValue", "onUpdate:modelValue", "id"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(FormField, {
          label: "Description",
          "label-for": "description-" + (rowIndex + __props.sectionIndex)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(FormControl, {
                modelValue: data.description,
                "onUpdate:modelValue": ($event) => data.description = $event,
                id: "description-" + (rowIndex + __props.sectionIndex),
                placeholder: "Description here",
                type: "textarea",
                required: ""
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(FormControl, {
                  modelValue: data.description,
                  "onUpdate:modelValue": ($event) => data.description = $event,
                  id: "description-" + (rowIndex + __props.sectionIndex),
                  placeholder: "Description here",
                  type: "textarea",
                  required: ""
                }, null, 8, ["modelValue", "onUpdate:modelValue", "id"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Pages/Parts/Blog.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
