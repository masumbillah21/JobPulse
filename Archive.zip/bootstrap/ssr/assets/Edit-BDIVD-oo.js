import { defineComponent, ref, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, Fragment, renderList, withDirectives, vShow, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderStyle, ssrRenderAttr } from "vue/server-renderer";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { F as FormFilePicker } from "./FormFilePicker-BtfvB5iT.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import _sfc_main$5 from "./Home-DJeOoywj.js";
import _sfc_main$3 from "./Blog-C2NqLAlM.js";
import _sfc_main$4 from "./Contact-De19zrMQ.js";
import _sfc_main$1 from "./General-pjPnHKSN.js";
import _sfc_main$2 from "./Job-SgXZbzxE.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./IconRounded-RF1xkXym.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NotificationBarInCard-Dg146C8Q.js";
import "./main-C5vGb8af.js";
import "./SectionTitle-qF5u6qV8.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  setup(__props) {
    const pageData = usePage().props.pageData ?? null;
    const urls = usePage().props.urls;
    const storage = urls.storeUrl;
    const pageType = [
      { id: "general", label: "General" },
      { id: "home", label: "Home" },
      { id: "job", label: "Job" },
      { id: "blog", label: "Blog" },
      { id: "contact", label: "Contact" }
    ];
    const imagePosition = [
      { id: "left", label: "Left" },
      { id: "right", label: "Right" }
    ];
    const iconList = [
      { id: "fa fa-phone", label: "Phone" },
      { id: "fa fa-envelope", label: "Email" },
      { id: "fa fa-map-marker", label: "Map Marker" },
      { id: "fa fa-fax", label: "Fax" }
    ];
    const form = useForm({
      id: 0,
      title: "",
      featured_image: "",
      page_type: pageType[0].id,
      for_nav: 0,
      page_order: 0,
      email_to: "",
      status: 1,
      contents: [{
        name: "Section 1",
        data: [{
          title: "",
          subtitle: "",
          description: "",
          image: "",
          oldImage: "",
          imagePosition: imagePosition[0].id,
          imageKey: Date.now()
        }]
      }],
      _method: "post"
    });
    if (pageData) {
      form.id = pageData.id;
      form.title = pageData.title;
      form.page_type = pageData.page_type;
      form.for_nav = pageData.for_nav;
      form.page_order = pageData.page_order;
      form.email_to = pageData.email_to;
      form.status = pageData.status;
      form.contents = pageData.contents;
      form._method = "put";
      form.contents.forEach((section) => {
        section.data.forEach((row) => {
          if (row.image) {
            row.oldImage = row.image;
            row.image = "";
          }
        });
      });
    }
    const featuredKey = ref(1);
    const addSection = () => {
      form.contents.push({
        name: `Section ${form.contents.length + 1}`,
        data: [{
          title: "",
          description: "",
          image: "",
          oldImage: "",
          imagePosition: imagePosition[0].id,
          imageKey: Date.now()
        }]
      });
    };
    const removeSection = (sectionIndex) => {
      form.contents[sectionIndex].data.forEach((row) => {
        delete row.image;
      });
      form.contents.splice(sectionIndex, 1);
    };
    const removeRow = (sectionIndex, rowIndex) => {
      form.contents[sectionIndex].data.splice(rowIndex, 1);
    };
    const addRow = (sectionIndex) => {
      if (form.pageType === "contact") {
        form.contents[sectionIndex].data.push({
          title: "",
          info: "",
          icon: iconList[0].id
        });
      } else {
        form.contents[sectionIndex].data.push({
          title: "",
          description: "",
          subtitle: "",
          image: "",
          oldImage: "",
          imageKey: Date.now()
        });
      }
    };
    const save = () => {
      if (form.id == 0) {
        create();
      } else {
        update();
      }
    };
    const create = () => {
      form.transform((data) => ({
        ...data,
        terms: form.terms && form.terms.length
      })).post(route("admin.pages.store"));
    };
    const update = () => {
      form.transform((data) => ({
        ...data,
        terms: form.terms && form.terms.length
      })).post(route("admin.pages.update", form.id));
    };
    const toggleSection = (sectionIndex) => {
      form.contents[sectionIndex].hidden = !form.contents[sectionIndex].hidden;
    };
    const chooseLayout = (layout) => {
      if (layout === "contact") {
        form.contents = [
          {
            name: "Banner Section",
            slug: "banner",
            data: [{
              title: "",
              subtitle: "",
              description: ""
            }]
          },
          {
            name: "Contact Info",
            slug: "contact_info",
            data: [{
              title: "",
              info: "",
              icon: iconList[0].id
            }]
          }
        ];
      } else if (layout === "blog") {
        form.contents = [
          {
            name: "Banner Section",
            slug: "banner",
            data: [{
              title: "",
              subtitle: "",
              description: ""
            }]
          }
        ];
      } else if (layout === "job") {
        form.contents = [
          {
            name: "Banner Section",
            slug: "banner",
            data: [{
              title: "",
              subtitle: "",
              description: ""
            }]
          },
          {
            name: "Available Jobs Section",
            slug: "jobs",
            data: [{
              title: "",
              subtitle: "",
              description: ""
            }]
          }
        ];
      } else if (layout === "home") {
        form.contents = [
          {
            name: "Slide Section",
            slug: "slider",
            data: [{
              title: "",
              subtitle: "",
              description: "",
              image: "",
              oldImage: "",
              imageKey: Date.now()
            }]
          },
          {
            name: "Compnay Logo Section",
            slug: "logo",
            data: [{
              title: "",
              subtitle: "",
              description: ""
            }]
          },
          {
            name: "Job Category Section",
            slug: "job_category",
            data: [{
              title: "",
              subtitle: "",
              description: ""
            }]
          },
          {
            name: "Available Jobs Section",
            slug: "jobs",
            data: [{
              title: "",
              subtitle: "",
              description: ""
            }]
          }
        ];
      } else {
        form.contents = [
          {
            name: "Section 1",
            data: [{
              title: "",
              description: "",
              image: "",
              oldImage: "",
              imagePosition: imagePosition[0].id,
              imageKey: Date.now()
            }]
          }
        ];
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Edit Page" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    title: "Page",
                    icon: "fas fa-arrow-circle-right"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtons, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(BaseButtonLink, {
                                class: "mr-1",
                                icon: "fas fa-arrow-circle-left",
                                routeName: "pages.index",
                                label: "Back",
                                color: "contrast",
                                "rounded-full": "",
                                small: ""
                              }, null, _parent5, _scopeId4));
                              if (unref(pageData)) {
                                _push5(ssrRenderComponent(BaseButtonLink, {
                                  class: "mr-1",
                                  icon: "fas fa-plus",
                                  routeName: "pages.create",
                                  label: "Add New",
                                  color: "info",
                                  "rounded-full": "",
                                  small: ""
                                }, null, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                            } else {
                              return [
                                createVNode(BaseButtonLink, {
                                  class: "mr-1",
                                  icon: "fas fa-arrow-circle-left",
                                  routeName: "pages.index",
                                  label: "Back",
                                  color: "contrast",
                                  "rounded-full": "",
                                  small: ""
                                }),
                                unref(pageData) ? (openBlock(), createBlock(BaseButtonLink, {
                                  key: 0,
                                  class: "mr-1",
                                  icon: "fas fa-plus",
                                  routeName: "pages.create",
                                  label: "Add New",
                                  color: "info",
                                  "rounded-full": "",
                                  small: ""
                                })) : createCommentVNode("", true)
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                class: "mr-1",
                                icon: "fas fa-arrow-circle-left",
                                routeName: "pages.index",
                                label: "Back",
                                color: "contrast",
                                "rounded-full": "",
                                small: ""
                              }),
                              unref(pageData) ? (openBlock(), createBlock(BaseButtonLink, {
                                key: 0,
                                class: "mr-1",
                                icon: "fas fa-plus",
                                routeName: "pages.create",
                                label: "Add New",
                                color: "info",
                                "rounded-full": "",
                                small: ""
                              })) : createCommentVNode("", true)
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, {
                    class: "w-full",
                    "is-form": "",
                    onSubmit: save
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormSuccess, null, null, _parent4, _scopeId3));
                        _push4(`<div class="flex flex-row justify-center"${_scopeId3}><div class="w-9/12"${_scopeId3}>`);
                        _push4(ssrRenderComponent(FormField, {
                          label: "Title",
                          help: "Enter Page Title"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).title,
                                "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                type: "text",
                                placeholder: "Enter Page Title",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).title,
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  type: "text",
                                  placeholder: "Enter Page Title",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        if (unref(form).page_type === "general") {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(form).contents, (row, sectionIndex) => {
                            _push4(`<div${_scopeId3}>`);
                            _push4(ssrRenderComponent(_sfc_main$1, {
                              sectionIndex,
                              row,
                              imagePosition,
                              onAddRow: addRow,
                              onRemoveRow: removeRow,
                              onToggleSection: toggleSection,
                              onAddSection: addSection,
                              onRemoveSection: removeSection
                            }, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        if (unref(form).page_type === "job") {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(form).contents, (row, sectionIndex) => {
                            _push4(`<div${_scopeId3}>`);
                            _push4(ssrRenderComponent(_sfc_main$2, {
                              sectionIndex,
                              row
                            }, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        if (unref(form).page_type === "blog") {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(form).contents, (row, sectionIndex) => {
                            _push4(`<div${_scopeId3}>`);
                            _push4(ssrRenderComponent(_sfc_main$3, {
                              sectionIndex,
                              row
                            }, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        if (unref(form).page_type === "contact") {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(form).contents, (row, sectionIndex) => {
                            _push4(`<div${_scopeId3}>`);
                            _push4(ssrRenderComponent(_sfc_main$4, {
                              sectionIndex,
                              row,
                              iconList,
                              onAddRow: addRow,
                              onRemoveRow: removeRow,
                              onToggleSection: toggleSection
                            }, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        if (unref(form).page_type === "home") {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(form).contents, (row, sectionIndex) => {
                            _push4(`<div${_scopeId3}>`);
                            _push4(ssrRenderComponent(_sfc_main$5, {
                              sectionIndex,
                              row,
                              onToggleSection: toggleSection,
                              onAddRow: addRow,
                              onRemoveRow: removeRow
                            }, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`</div><div class="w-3/12 ml-5 flex flex-col items-center justify-start mt-10 border border-gray-50 rounded p-5"${_scopeId3}><div style="${ssrRenderStyle(!unref(form).featured_image ? null : { display: "none" })}" class="w-full"${_scopeId3}>`);
                        if (unref(pageData) != null && unref(pageData).featured_image) {
                          _push4(`<img${ssrRenderAttr("src", `${unref(storage)}/${unref(pageData).featured_image}`)} class="h-52 w-11/12 mb-4" alt=""${_scopeId3}>`);
                        } else {
                          _push4(`<div class="h-52 w-11/12 mb-4 border-dashed border dark:border-gray-50 border-slate-800 flex justify-center items-center"${_scopeId3}> Featured Image</div>`);
                        }
                        _push4(`</div>`);
                        _push4(ssrRenderComponent(FormField, {
                          label: "Featured Image",
                          help: "Max 500kb"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormFilePicker, {
                                key: featuredKey.value,
                                label: "Upload Image",
                                modelValue: unref(form).featured_image,
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).featured_image = $event
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                (openBlock(), createBlock(FormFilePicker, {
                                  key: featuredKey.value,
                                  label: "Upload Image",
                                  modelValue: unref(form).featured_image,
                                  color: "success",
                                  "onUpdate:modelValue": ($event) => unref(form).featured_image = $event
                                }, null, 8, ["modelValue", "onUpdate:modelValue"]))
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          class: "w-full",
                          label: "Page Type"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                onChange: ($event) => chooseLayout(unref(form).page_type),
                                modelValue: unref(form).page_type,
                                "onUpdate:modelValue": ($event) => unref(form).page_type = $event,
                                options: pageType
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  onChange: ($event) => chooseLayout(unref(form).page_type),
                                  modelValue: unref(form).page_type,
                                  "onUpdate:modelValue": ($event) => unref(form).page_type = $event,
                                  options: pageType
                                }, null, 8, ["onChange", "modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          style: unref(form).pageType === "contact" ? null : { display: "none" },
                          class: "w-full",
                          label: "Email To",
                          "label-for": "email-to"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).email_to,
                                "onUpdate:modelValue": ($event) => unref(form).email_to = $event,
                                id: "email-to",
                                placeholder: "Email To",
                                type: "text"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).email_to,
                                  "onUpdate:modelValue": ($event) => unref(form).email_to = $event,
                                  id: "email-to",
                                  placeholder: "Email To",
                                  type: "text"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          class: "w-full",
                          label: "Page Order",
                          "label-for": "page-order"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).page_order,
                                "onUpdate:modelValue": ($event) => unref(form).page_order = $event,
                                id: "page-order",
                                placeholder: "Page Order",
                                type: "number",
                                min: "0",
                                step: "1",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).page_order,
                                  "onUpdate:modelValue": ($event) => unref(form).page_order = $event,
                                  id: "page-order",
                                  placeholder: "Page Order",
                                  type: "number",
                                  min: "0",
                                  step: "1",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          class: "w-full",
                          label: "Show On Navigation Bar?"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormCheckRadioGroup, {
                                modelValue: unref(form).for_nav,
                                "onUpdate:modelValue": ($event) => unref(form).for_nav = $event,
                                name: "for_nav",
                                type: "radio",
                                options: { "1": "Yes", "0": "No" }
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormCheckRadioGroup, {
                                  modelValue: unref(form).for_nav,
                                  "onUpdate:modelValue": ($event) => unref(form).for_nav = $event,
                                  name: "for_nav",
                                  type: "radio",
                                  options: { "1": "Yes", "0": "No" }
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          class: "w-full",
                          label: "Status"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormCheckRadioGroup, {
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                name: "status",
                                type: "radio",
                                options: { "1": "Enable", "0": "Disable" }
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormCheckRadioGroup, {
                                  modelValue: unref(form).status,
                                  "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                  name: "status",
                                  type: "radio",
                                  options: { "1": "Enable", "0": "Disable" }
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "far fa-save",
                          class: ["w-full mt-10", { "opacity-25": unref(form).processing }],
                          color: "info",
                          type: "submit",
                          label: "Save",
                          disabled: unref(form).processing,
                          "rounded-full": ""
                        }, null, _parent4, _scopeId3));
                        _push4(`</div></div>`);
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          createVNode("div", { class: "flex flex-row justify-center" }, [
                            createVNode("div", { class: "w-9/12" }, [
                              createVNode(FormField, {
                                label: "Title",
                                help: "Enter Page Title"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).title,
                                    "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                    type: "text",
                                    placeholder: "Enter Page Title",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              unref(form).page_type === "general" ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(form).contents, (row, sectionIndex) => {
                                return openBlock(), createBlock("div", { key: sectionIndex }, [
                                  createVNode(_sfc_main$1, {
                                    sectionIndex,
                                    row,
                                    imagePosition,
                                    onAddRow: addRow,
                                    onRemoveRow: removeRow,
                                    onToggleSection: toggleSection,
                                    onAddSection: addSection,
                                    onRemoveSection: removeSection
                                  }, null, 8, ["sectionIndex", "row"])
                                ]);
                              }), 128)) : createCommentVNode("", true),
                              unref(form).page_type === "job" ? (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(form).contents, (row, sectionIndex) => {
                                return openBlock(), createBlock("div", { key: sectionIndex }, [
                                  createVNode(_sfc_main$2, {
                                    sectionIndex,
                                    row
                                  }, null, 8, ["sectionIndex", "row"])
                                ]);
                              }), 128)) : createCommentVNode("", true),
                              unref(form).page_type === "blog" ? (openBlock(true), createBlock(Fragment, { key: 2 }, renderList(unref(form).contents, (row, sectionIndex) => {
                                return openBlock(), createBlock("div", { key: sectionIndex }, [
                                  createVNode(_sfc_main$3, {
                                    sectionIndex,
                                    row
                                  }, null, 8, ["sectionIndex", "row"])
                                ]);
                              }), 128)) : createCommentVNode("", true),
                              unref(form).page_type === "contact" ? (openBlock(true), createBlock(Fragment, { key: 3 }, renderList(unref(form).contents, (row, sectionIndex) => {
                                return openBlock(), createBlock("div", { key: sectionIndex }, [
                                  createVNode(_sfc_main$4, {
                                    sectionIndex,
                                    row,
                                    iconList,
                                    onAddRow: addRow,
                                    onRemoveRow: removeRow,
                                    onToggleSection: toggleSection
                                  }, null, 8, ["sectionIndex", "row"])
                                ]);
                              }), 128)) : createCommentVNode("", true),
                              unref(form).page_type === "home" ? (openBlock(true), createBlock(Fragment, { key: 4 }, renderList(unref(form).contents, (row, sectionIndex) => {
                                return openBlock(), createBlock("div", { key: sectionIndex }, [
                                  createVNode(_sfc_main$5, {
                                    sectionIndex,
                                    row,
                                    onToggleSection: toggleSection,
                                    onAddRow: addRow,
                                    onRemoveRow: removeRow
                                  }, null, 8, ["sectionIndex", "row"])
                                ]);
                              }), 128)) : createCommentVNode("", true)
                            ]),
                            createVNode("div", { class: "w-3/12 ml-5 flex flex-col items-center justify-start mt-10 border border-gray-50 rounded p-5" }, [
                              withDirectives(createVNode("div", { class: "w-full" }, [
                                unref(pageData) != null && unref(pageData).featured_image ? (openBlock(), createBlock("img", {
                                  key: 0,
                                  src: `${unref(storage)}/${unref(pageData).featured_image}`,
                                  class: "h-52 w-11/12 mb-4",
                                  alt: ""
                                }, null, 8, ["src"])) : (openBlock(), createBlock("div", {
                                  key: 1,
                                  class: "h-52 w-11/12 mb-4 border-dashed border dark:border-gray-50 border-slate-800 flex justify-center items-center"
                                }, " Featured Image"))
                              ], 512), [
                                [vShow, !unref(form).featured_image]
                              ]),
                              createVNode(FormField, {
                                label: "Featured Image",
                                help: "Max 500kb"
                              }, {
                                default: withCtx(() => [
                                  (openBlock(), createBlock(FormFilePicker, {
                                    key: featuredKey.value,
                                    label: "Upload Image",
                                    modelValue: unref(form).featured_image,
                                    color: "success",
                                    "onUpdate:modelValue": ($event) => unref(form).featured_image = $event
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"]))
                                ]),
                                _: 1
                              }),
                              createVNode(FormField, {
                                class: "w-full",
                                label: "Page Type"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormControl, {
                                    onChange: ($event) => chooseLayout(unref(form).page_type),
                                    modelValue: unref(form).page_type,
                                    "onUpdate:modelValue": ($event) => unref(form).page_type = $event,
                                    options: pageType
                                  }, null, 8, ["onChange", "modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode(FormField, {
                                class: "w-full",
                                label: "Email To",
                                "label-for": "email-to"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).email_to,
                                    "onUpdate:modelValue": ($event) => unref(form).email_to = $event,
                                    id: "email-to",
                                    placeholder: "Email To",
                                    type: "text"
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }, 512), [
                                [vShow, unref(form).pageType === "contact"]
                              ]),
                              createVNode(FormField, {
                                class: "w-full",
                                label: "Page Order",
                                "label-for": "page-order"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).page_order,
                                    "onUpdate:modelValue": ($event) => unref(form).page_order = $event,
                                    id: "page-order",
                                    placeholder: "Page Order",
                                    type: "number",
                                    min: "0",
                                    step: "1",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              createVNode(FormField, {
                                class: "w-full",
                                label: "Show On Navigation Bar?"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormCheckRadioGroup, {
                                    modelValue: unref(form).for_nav,
                                    "onUpdate:modelValue": ($event) => unref(form).for_nav = $event,
                                    name: "for_nav",
                                    type: "radio",
                                    options: { "1": "Yes", "0": "No" }
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              createVNode(FormField, {
                                class: "w-full",
                                label: "Status"
                              }, {
                                default: withCtx(() => [
                                  createVNode(FormCheckRadioGroup, {
                                    modelValue: unref(form).status,
                                    "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                    name: "status",
                                    type: "radio",
                                    options: { "1": "Enable", "0": "Disable" }
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              }),
                              createVNode(BaseButtonLink, {
                                icon: "far fa-save",
                                class: ["w-full mt-10", { "opacity-25": unref(form).processing }],
                                color: "info",
                                type: "submit",
                                label: "Save",
                                disabled: unref(form).processing,
                                "rounded-full": ""
                              }, null, 8, ["class", "disabled"])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      title: "Page",
                      icon: "fas fa-arrow-circle-right"
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtons, null, {
                          default: withCtx(() => [
                            createVNode(BaseButtonLink, {
                              class: "mr-1",
                              icon: "fas fa-arrow-circle-left",
                              routeName: "pages.index",
                              label: "Back",
                              color: "contrast",
                              "rounded-full": "",
                              small: ""
                            }),
                            unref(pageData) ? (openBlock(), createBlock(BaseButtonLink, {
                              key: 0,
                              class: "mr-1",
                              icon: "fas fa-plus",
                              routeName: "pages.create",
                              label: "Add New",
                              color: "info",
                              "rounded-full": "",
                              small: ""
                            })) : createCommentVNode("", true)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(CardBox, {
                      class: "w-full",
                      "is-form": "",
                      onSubmit: withModifiers(save, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormSuccess),
                        createVNode("div", { class: "flex flex-row justify-center" }, [
                          createVNode("div", { class: "w-9/12" }, [
                            createVNode(FormField, {
                              label: "Title",
                              help: "Enter Page Title"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).title,
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  type: "text",
                                  placeholder: "Enter Page Title",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            unref(form).page_type === "general" ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(form).contents, (row, sectionIndex) => {
                              return openBlock(), createBlock("div", { key: sectionIndex }, [
                                createVNode(_sfc_main$1, {
                                  sectionIndex,
                                  row,
                                  imagePosition,
                                  onAddRow: addRow,
                                  onRemoveRow: removeRow,
                                  onToggleSection: toggleSection,
                                  onAddSection: addSection,
                                  onRemoveSection: removeSection
                                }, null, 8, ["sectionIndex", "row"])
                              ]);
                            }), 128)) : createCommentVNode("", true),
                            unref(form).page_type === "job" ? (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(form).contents, (row, sectionIndex) => {
                              return openBlock(), createBlock("div", { key: sectionIndex }, [
                                createVNode(_sfc_main$2, {
                                  sectionIndex,
                                  row
                                }, null, 8, ["sectionIndex", "row"])
                              ]);
                            }), 128)) : createCommentVNode("", true),
                            unref(form).page_type === "blog" ? (openBlock(true), createBlock(Fragment, { key: 2 }, renderList(unref(form).contents, (row, sectionIndex) => {
                              return openBlock(), createBlock("div", { key: sectionIndex }, [
                                createVNode(_sfc_main$3, {
                                  sectionIndex,
                                  row
                                }, null, 8, ["sectionIndex", "row"])
                              ]);
                            }), 128)) : createCommentVNode("", true),
                            unref(form).page_type === "contact" ? (openBlock(true), createBlock(Fragment, { key: 3 }, renderList(unref(form).contents, (row, sectionIndex) => {
                              return openBlock(), createBlock("div", { key: sectionIndex }, [
                                createVNode(_sfc_main$4, {
                                  sectionIndex,
                                  row,
                                  iconList,
                                  onAddRow: addRow,
                                  onRemoveRow: removeRow,
                                  onToggleSection: toggleSection
                                }, null, 8, ["sectionIndex", "row"])
                              ]);
                            }), 128)) : createCommentVNode("", true),
                            unref(form).page_type === "home" ? (openBlock(true), createBlock(Fragment, { key: 4 }, renderList(unref(form).contents, (row, sectionIndex) => {
                              return openBlock(), createBlock("div", { key: sectionIndex }, [
                                createVNode(_sfc_main$5, {
                                  sectionIndex,
                                  row,
                                  onToggleSection: toggleSection,
                                  onAddRow: addRow,
                                  onRemoveRow: removeRow
                                }, null, 8, ["sectionIndex", "row"])
                              ]);
                            }), 128)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "w-3/12 ml-5 flex flex-col items-center justify-start mt-10 border border-gray-50 rounded p-5" }, [
                            withDirectives(createVNode("div", { class: "w-full" }, [
                              unref(pageData) != null && unref(pageData).featured_image ? (openBlock(), createBlock("img", {
                                key: 0,
                                src: `${unref(storage)}/${unref(pageData).featured_image}`,
                                class: "h-52 w-11/12 mb-4",
                                alt: ""
                              }, null, 8, ["src"])) : (openBlock(), createBlock("div", {
                                key: 1,
                                class: "h-52 w-11/12 mb-4 border-dashed border dark:border-gray-50 border-slate-800 flex justify-center items-center"
                              }, " Featured Image"))
                            ], 512), [
                              [vShow, !unref(form).featured_image]
                            ]),
                            createVNode(FormField, {
                              label: "Featured Image",
                              help: "Max 500kb"
                            }, {
                              default: withCtx(() => [
                                (openBlock(), createBlock(FormFilePicker, {
                                  key: featuredKey.value,
                                  label: "Upload Image",
                                  modelValue: unref(form).featured_image,
                                  color: "success",
                                  "onUpdate:modelValue": ($event) => unref(form).featured_image = $event
                                }, null, 8, ["modelValue", "onUpdate:modelValue"]))
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              class: "w-full",
                              label: "Page Type"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  onChange: ($event) => chooseLayout(unref(form).page_type),
                                  modelValue: unref(form).page_type,
                                  "onUpdate:modelValue": ($event) => unref(form).page_type = $event,
                                  options: pageType
                                }, null, 8, ["onChange", "modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            withDirectives(createVNode(FormField, {
                              class: "w-full",
                              label: "Email To",
                              "label-for": "email-to"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).email_to,
                                  "onUpdate:modelValue": ($event) => unref(form).email_to = $event,
                                  id: "email-to",
                                  placeholder: "Email To",
                                  type: "text"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }, 512), [
                              [vShow, unref(form).pageType === "contact"]
                            ]),
                            createVNode(FormField, {
                              class: "w-full",
                              label: "Page Order",
                              "label-for": "page-order"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).page_order,
                                  "onUpdate:modelValue": ($event) => unref(form).page_order = $event,
                                  id: "page-order",
                                  placeholder: "Page Order",
                                  type: "number",
                                  min: "0",
                                  step: "1",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              class: "w-full",
                              label: "Show On Navigation Bar?"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormCheckRadioGroup, {
                                  modelValue: unref(form).for_nav,
                                  "onUpdate:modelValue": ($event) => unref(form).for_nav = $event,
                                  name: "for_nav",
                                  type: "radio",
                                  options: { "1": "Yes", "0": "No" }
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              class: "w-full",
                              label: "Status"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormCheckRadioGroup, {
                                  modelValue: unref(form).status,
                                  "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                  name: "status",
                                  type: "radio",
                                  options: { "1": "Enable", "0": "Disable" }
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(BaseButtonLink, {
                              icon: "far fa-save",
                              class: ["w-full mt-10", { "opacity-25": unref(form).processing }],
                              color: "info",
                              type: "submit",
                              label: "Save",
                              disabled: unref(form).processing,
                              "rounded-full": ""
                            }, null, 8, ["class", "disabled"])
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Edit Page" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    title: "Page",
                    icon: "fas fa-arrow-circle-right"
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtons, null, {
                        default: withCtx(() => [
                          createVNode(BaseButtonLink, {
                            class: "mr-1",
                            icon: "fas fa-arrow-circle-left",
                            routeName: "pages.index",
                            label: "Back",
                            color: "contrast",
                            "rounded-full": "",
                            small: ""
                          }),
                          unref(pageData) ? (openBlock(), createBlock(BaseButtonLink, {
                            key: 0,
                            class: "mr-1",
                            icon: "fas fa-plus",
                            routeName: "pages.create",
                            label: "Add New",
                            color: "info",
                            "rounded-full": "",
                            small: ""
                          })) : createCommentVNode("", true)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(CardBox, {
                    class: "w-full",
                    "is-form": "",
                    onSubmit: withModifiers(save, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(FormValidationErrors),
                      createVNode(FormSuccess),
                      createVNode("div", { class: "flex flex-row justify-center" }, [
                        createVNode("div", { class: "w-9/12" }, [
                          createVNode(FormField, {
                            label: "Title",
                            help: "Enter Page Title"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).title,
                                "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                type: "text",
                                placeholder: "Enter Page Title",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          unref(form).page_type === "general" ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(form).contents, (row, sectionIndex) => {
                            return openBlock(), createBlock("div", { key: sectionIndex }, [
                              createVNode(_sfc_main$1, {
                                sectionIndex,
                                row,
                                imagePosition,
                                onAddRow: addRow,
                                onRemoveRow: removeRow,
                                onToggleSection: toggleSection,
                                onAddSection: addSection,
                                onRemoveSection: removeSection
                              }, null, 8, ["sectionIndex", "row"])
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          unref(form).page_type === "job" ? (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(form).contents, (row, sectionIndex) => {
                            return openBlock(), createBlock("div", { key: sectionIndex }, [
                              createVNode(_sfc_main$2, {
                                sectionIndex,
                                row
                              }, null, 8, ["sectionIndex", "row"])
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          unref(form).page_type === "blog" ? (openBlock(true), createBlock(Fragment, { key: 2 }, renderList(unref(form).contents, (row, sectionIndex) => {
                            return openBlock(), createBlock("div", { key: sectionIndex }, [
                              createVNode(_sfc_main$3, {
                                sectionIndex,
                                row
                              }, null, 8, ["sectionIndex", "row"])
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          unref(form).page_type === "contact" ? (openBlock(true), createBlock(Fragment, { key: 3 }, renderList(unref(form).contents, (row, sectionIndex) => {
                            return openBlock(), createBlock("div", { key: sectionIndex }, [
                              createVNode(_sfc_main$4, {
                                sectionIndex,
                                row,
                                iconList,
                                onAddRow: addRow,
                                onRemoveRow: removeRow,
                                onToggleSection: toggleSection
                              }, null, 8, ["sectionIndex", "row"])
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          unref(form).page_type === "home" ? (openBlock(true), createBlock(Fragment, { key: 4 }, renderList(unref(form).contents, (row, sectionIndex) => {
                            return openBlock(), createBlock("div", { key: sectionIndex }, [
                              createVNode(_sfc_main$5, {
                                sectionIndex,
                                row,
                                onToggleSection: toggleSection,
                                onAddRow: addRow,
                                onRemoveRow: removeRow
                              }, null, 8, ["sectionIndex", "row"])
                            ]);
                          }), 128)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "w-3/12 ml-5 flex flex-col items-center justify-start mt-10 border border-gray-50 rounded p-5" }, [
                          withDirectives(createVNode("div", { class: "w-full" }, [
                            unref(pageData) != null && unref(pageData).featured_image ? (openBlock(), createBlock("img", {
                              key: 0,
                              src: `${unref(storage)}/${unref(pageData).featured_image}`,
                              class: "h-52 w-11/12 mb-4",
                              alt: ""
                            }, null, 8, ["src"])) : (openBlock(), createBlock("div", {
                              key: 1,
                              class: "h-52 w-11/12 mb-4 border-dashed border dark:border-gray-50 border-slate-800 flex justify-center items-center"
                            }, " Featured Image"))
                          ], 512), [
                            [vShow, !unref(form).featured_image]
                          ]),
                          createVNode(FormField, {
                            label: "Featured Image",
                            help: "Max 500kb"
                          }, {
                            default: withCtx(() => [
                              (openBlock(), createBlock(FormFilePicker, {
                                key: featuredKey.value,
                                label: "Upload Image",
                                modelValue: unref(form).featured_image,
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).featured_image = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]))
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            class: "w-full",
                            label: "Page Type"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                onChange: ($event) => chooseLayout(unref(form).page_type),
                                modelValue: unref(form).page_type,
                                "onUpdate:modelValue": ($event) => unref(form).page_type = $event,
                                options: pageType
                              }, null, 8, ["onChange", "modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          withDirectives(createVNode(FormField, {
                            class: "w-full",
                            label: "Email To",
                            "label-for": "email-to"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).email_to,
                                "onUpdate:modelValue": ($event) => unref(form).email_to = $event,
                                id: "email-to",
                                placeholder: "Email To",
                                type: "text"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }, 512), [
                            [vShow, unref(form).pageType === "contact"]
                          ]),
                          createVNode(FormField, {
                            class: "w-full",
                            label: "Page Order",
                            "label-for": "page-order"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).page_order,
                                "onUpdate:modelValue": ($event) => unref(form).page_order = $event,
                                id: "page-order",
                                placeholder: "Page Order",
                                type: "number",
                                min: "0",
                                step: "1",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            class: "w-full",
                            label: "Show On Navigation Bar?"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormCheckRadioGroup, {
                                modelValue: unref(form).for_nav,
                                "onUpdate:modelValue": ($event) => unref(form).for_nav = $event,
                                name: "for_nav",
                                type: "radio",
                                options: { "1": "Yes", "0": "No" }
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            class: "w-full",
                            label: "Status"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormCheckRadioGroup, {
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                name: "status",
                                type: "radio",
                                options: { "1": "Enable", "0": "Disable" }
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseButtonLink, {
                            icon: "far fa-save",
                            class: ["w-full mt-10", { "opacity-25": unref(form).processing }],
                            color: "info",
                            type: "submit",
                            label: "Save",
                            disabled: unref(form).processing,
                            "rounded-full": ""
                          }, null, 8, ["class", "disabled"])
                        ])
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Pages/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
