import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { P as Pagination } from "./Pagination-BiZgXXz6.js";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { _ as _sfc_main$4 } from "./PostGrid-Din_eeNu.js";
import { usePage, Head } from "@inertiajs/vue3";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Archive",
  __ssrInlineRender: true,
  setup(__props) {
    const postMeta = usePage().props.postMeta;
    const postList = usePage().props.postList;
    const cateBgImage = usePage().props.cateBgImage ?? null;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(postMeta).name ?? "Blog"
            }, null, _parent2, _scopeId));
            if (unref(postMeta)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, { bgImage: unref(cateBgImage) }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: unref(postMeta).name
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: unref(postMeta).name
                      }, null, 8, ["title"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<section class="relative py-20 bg-gray-50"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="grid gap-x-8 gap-y-4 grid-cols-3"${_scopeId}><!--[-->`);
              ssrRenderList(unref(postList).data, (post, index) => {
                _push2(`<div class="bg-gray-100 text-center rounded"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$4, { post }, null, _parent2, _scopeId));
                _push2(`</div>`);
              });
              _push2(`<!--]--></div>`);
              _push2(ssrRenderComponent(Pagination, {
                class: "mt-6",
                links: (_a = unref(postList)) == null ? void 0 : _a.links
              }, null, _parent2, _scopeId));
              _push2(`</div></section></main>`);
            } else {
              _push2(`<main class="mt-40"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="items-center justify-center flex flex-wrap"${_scopeId}><div class="w-full ml-auto mr-auto px-4"${_scopeId}><h3 class="text-4xl font-semibold"${_scopeId}>Not Found</h3></div></div></div></main>`);
            }
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(postMeta).name ?? "Blog"
              }, null, 8, ["title"]),
              unref(postMeta) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, { bgImage: unref(cateBgImage) }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$3, {
                      title: unref(postMeta).name
                    }, null, 8, ["title"])
                  ]),
                  _: 1
                }, 8, ["bgImage"]),
                createVNode("section", { class: "relative py-20 bg-gray-50" }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "grid gap-x-8 gap-y-4 grid-cols-3" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(postList).data, (post, index) => {
                        return openBlock(), createBlock("div", {
                          key: index,
                          class: "bg-gray-100 text-center rounded"
                        }, [
                          createVNode(_sfc_main$4, { post }, null, 8, ["post"])
                        ]);
                      }), 128))
                    ]),
                    createVNode(Pagination, {
                      class: "mt-6",
                      links: (_b = unref(postList)) == null ? void 0 : _b.links
                    }, null, 8, ["links"])
                  ])
                ])
              ])) : (openBlock(), createBlock("main", {
                key: 1,
                class: "mt-40"
              }, [
                createVNode("div", { class: "container mx-auto px-4" }, [
                  createVNode("div", { class: "items-center justify-center flex flex-wrap" }, [
                    createVNode("div", { class: "w-full ml-auto mr-auto px-4" }, [
                      createVNode("h3", { class: "text-4xl font-semibold" }, "Not Found")
                    ])
                  ])
                ])
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Blog/Archive.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
