import { usePage } from "@inertiajs/vue3";
const UserTypeEnum = {
  SYSTEM: "system",
  COMPANY: "company",
  CANDIDATE: "candidate"
};
const isSystemUser = () => {
  const { auth } = usePage().props;
  if (!auth.user) {
    return false;
  }
  const userType = auth.user.user_type || "";
  return userType === UserTypeEnum.SYSTEM;
};
export {
  UserTypeEnum as U,
  isSystemUser as i
};
