import { defineComponent, ref, withCtx, unref, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderClass } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import _sfc_main$2 from "./Educations-DMpZOsdF.js";
import _sfc_main$1 from "./PersonalInfo-CiBhufsh.js";
import _sfc_main$4 from "./Experience-ZlZsEew4.js";
import _sfc_main$3 from "./Training-BgnyEwlh.js";
import _sfc_main$5 from "./Reference-DNnu066E.js";
import { Head } from "@inertiajs/vue3";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./BaseDivider-uk-eaHSj.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./IconRounded-RF1xkXym.js";
import "./FormValidationErrors-CmqgJHc6.js";
import "./NotificationBarInCard-Dg146C8Q.js";
import "./FormSuccess-CqNI5DHV.js";
import "./CardBox-BXS3nXKj.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./FormControl-DwHkIb1m.js";
import "./main-C5vGb8af.js";
import "./FormField-ePZgxXzs.js";
import "./SectionTitle-qF5u6qV8.js";
import "./BaseButtons-6cEMRrBZ.js";
import "./FormFilePicker-BtfvB5iT.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    const openTab = ref(1);
    const toggleTabs = (tabNumber) => {
      openTab.value = tabNumber;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Resume" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    title: "Resume",
                    icon: "fas fa-arrow-circle-right"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          type: "button",
                          routeName: "resume.viewResume",
                          color: "success",
                          label: "View",
                          icon: "fas fa-eye"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            type: "button",
                            routeName: "resume.viewResume",
                            color: "success",
                            label: "View",
                            icon: "fas fa-eye"
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="w-full"${_scopeId2}><ul class="flex w-full mb-0 list-none pt-3 pb-4 flex-row"${_scopeId2}><li class="mb-3 mr-2 last:mr-0"${_scopeId2}><a class="${ssrRenderClass([{ "text-slate-900 bg-white": openTab.value !== 1, "text-white bg-slate-900": openTab.value === 1 }, "w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal"])}"${_scopeId2}> Personal Information </a></li><li class="mb-3 mr-2 last:mr-0"${_scopeId2}><a class="${ssrRenderClass([{ "text-slate-900 bg-white": openTab.value !== 2, "text-white bg-slate-900": openTab.value === 2 }, "w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal"])}"${_scopeId2}> Education </a></li><li class="mb-3 mr-2 last:mr-0"${_scopeId2}><a class="${ssrRenderClass([{ "text-slate-900 bg-white": openTab.value !== 3, "text-white bg-slate-900": openTab.value === 3 }, "w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal"])}"${_scopeId2}> Training </a></li><li class="mb-3 mr-2"${_scopeId2}><a class="${ssrRenderClass([{ "text-slate-900 bg-white": openTab.value !== 4, "text-white bg-slate-900": openTab.value === 4 }, "w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal"])}"${_scopeId2}> Experiance </a></li><li class="mb-3 mr-2"${_scopeId2}><a class="${ssrRenderClass([{ "text-slate-900 bg-white": openTab.value !== 5, "text-white bg-slate-900": openTab.value === 5 }, "w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal"])}"${_scopeId2}> Reference </a></li></ul></div><div class="w-full"${_scopeId2}><div class="tab-content tab-space w-full"${_scopeId2}><div class="${ssrRenderClass([{ "hidden": openTab.value !== 1, "block": openTab.value === 1 }, "flex justify-center items-center"])}"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$1, null, null, _parent3, _scopeId2));
                  _push3(`</div><div class="tab-content tab-space"${_scopeId2}><div class="${ssrRenderClass({ "hidden": openTab.value !== 2, "block": openTab.value === 2 })}"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$2, null, null, _parent3, _scopeId2));
                  _push3(`</div></div><div class="tab-content tab-space"${_scopeId2}><div class="${ssrRenderClass({ "hidden": openTab.value !== 3, "block": openTab.value === 3 })}"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, null, null, _parent3, _scopeId2));
                  _push3(`</div></div><div class="tab-content tab-space"${_scopeId2}><div class="${ssrRenderClass({ "hidden": openTab.value !== 4, "block": openTab.value === 4 })}"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$4, null, null, _parent3, _scopeId2));
                  _push3(`</div></div><div class="tab-content tab-space"${_scopeId2}><div class="${ssrRenderClass({ "hidden": openTab.value !== 5, "block": openTab.value === 5 })}"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$5, null, null, _parent3, _scopeId2));
                  _push3(`</div></div></div></div>`);
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      title: "Resume",
                      icon: "fas fa-arrow-circle-right"
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          type: "button",
                          routeName: "resume.viewResume",
                          color: "success",
                          label: "View",
                          icon: "fas fa-eye"
                        })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "w-full" }, [
                      createVNode("ul", { class: "flex w-full mb-0 list-none pt-3 pb-4 flex-row" }, [
                        createVNode("li", { class: "mb-3 mr-2 last:mr-0" }, [
                          createVNode("a", {
                            class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 1, "text-white bg-slate-900": openTab.value === 1 }],
                            onClick: ($event) => toggleTabs(1)
                          }, " Personal Information ", 10, ["onClick"])
                        ]),
                        createVNode("li", { class: "mb-3 mr-2 last:mr-0" }, [
                          createVNode("a", {
                            class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 2, "text-white bg-slate-900": openTab.value === 2 }],
                            onClick: ($event) => toggleTabs(2)
                          }, " Education ", 10, ["onClick"])
                        ]),
                        createVNode("li", { class: "mb-3 mr-2 last:mr-0" }, [
                          createVNode("a", {
                            class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 3, "text-white bg-slate-900": openTab.value === 3 }],
                            onClick: ($event) => toggleTabs(3)
                          }, " Training ", 10, ["onClick"])
                        ]),
                        createVNode("li", { class: "mb-3 mr-2" }, [
                          createVNode("a", {
                            class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 4, "text-white bg-slate-900": openTab.value === 4 }],
                            onClick: ($event) => toggleTabs(4)
                          }, " Experiance ", 10, ["onClick"])
                        ]),
                        createVNode("li", { class: "mb-3 mr-2" }, [
                          createVNode("a", {
                            class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 5, "text-white bg-slate-900": openTab.value === 5 }],
                            onClick: ($event) => toggleTabs(5)
                          }, " Reference ", 10, ["onClick"])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "w-full" }, [
                      createVNode("div", { class: "tab-content tab-space w-full" }, [
                        createVNode("div", {
                          class: ["flex justify-center items-center", { "hidden": openTab.value !== 1, "block": openTab.value === 1 }]
                        }, [
                          createVNode(_sfc_main$1)
                        ], 2),
                        createVNode("div", { class: "tab-content tab-space" }, [
                          createVNode("div", {
                            class: { "hidden": openTab.value !== 2, "block": openTab.value === 2 }
                          }, [
                            createVNode(_sfc_main$2)
                          ], 2)
                        ]),
                        createVNode("div", { class: "tab-content tab-space" }, [
                          createVNode("div", {
                            class: { "hidden": openTab.value !== 3, "block": openTab.value === 3 }
                          }, [
                            createVNode(_sfc_main$3)
                          ], 2)
                        ]),
                        createVNode("div", { class: "tab-content tab-space" }, [
                          createVNode("div", {
                            class: { "hidden": openTab.value !== 4, "block": openTab.value === 4 }
                          }, [
                            createVNode(_sfc_main$4)
                          ], 2)
                        ]),
                        createVNode("div", { class: "tab-content tab-space" }, [
                          createVNode("div", {
                            class: { "hidden": openTab.value !== 5, "block": openTab.value === 5 }
                          }, [
                            createVNode(_sfc_main$5)
                          ], 2)
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Resume" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    title: "Resume",
                    icon: "fas fa-arrow-circle-right"
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        type: "button",
                        routeName: "resume.viewResume",
                        color: "success",
                        label: "View",
                        icon: "fas fa-eye"
                      })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "w-full" }, [
                    createVNode("ul", { class: "flex w-full mb-0 list-none pt-3 pb-4 flex-row" }, [
                      createVNode("li", { class: "mb-3 mr-2 last:mr-0" }, [
                        createVNode("a", {
                          class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 1, "text-white bg-slate-900": openTab.value === 1 }],
                          onClick: ($event) => toggleTabs(1)
                        }, " Personal Information ", 10, ["onClick"])
                      ]),
                      createVNode("li", { class: "mb-3 mr-2 last:mr-0" }, [
                        createVNode("a", {
                          class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 2, "text-white bg-slate-900": openTab.value === 2 }],
                          onClick: ($event) => toggleTabs(2)
                        }, " Education ", 10, ["onClick"])
                      ]),
                      createVNode("li", { class: "mb-3 mr-2 last:mr-0" }, [
                        createVNode("a", {
                          class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 3, "text-white bg-slate-900": openTab.value === 3 }],
                          onClick: ($event) => toggleTabs(3)
                        }, " Training ", 10, ["onClick"])
                      ]),
                      createVNode("li", { class: "mb-3 mr-2" }, [
                        createVNode("a", {
                          class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 4, "text-white bg-slate-900": openTab.value === 4 }],
                          onClick: ($event) => toggleTabs(4)
                        }, " Experiance ", 10, ["onClick"])
                      ]),
                      createVNode("li", { class: "mb-3 mr-2" }, [
                        createVNode("a", {
                          class: ["w-full inline-block text-xs font-bold uppercase px-5 py-3 shadow-lg rounded leading-normal", { "text-slate-900 bg-white": openTab.value !== 5, "text-white bg-slate-900": openTab.value === 5 }],
                          onClick: ($event) => toggleTabs(5)
                        }, " Reference ", 10, ["onClick"])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "w-full" }, [
                    createVNode("div", { class: "tab-content tab-space w-full" }, [
                      createVNode("div", {
                        class: ["flex justify-center items-center", { "hidden": openTab.value !== 1, "block": openTab.value === 1 }]
                      }, [
                        createVNode(_sfc_main$1)
                      ], 2),
                      createVNode("div", { class: "tab-content tab-space" }, [
                        createVNode("div", {
                          class: { "hidden": openTab.value !== 2, "block": openTab.value === 2 }
                        }, [
                          createVNode(_sfc_main$2)
                        ], 2)
                      ]),
                      createVNode("div", { class: "tab-content tab-space" }, [
                        createVNode("div", {
                          class: { "hidden": openTab.value !== 3, "block": openTab.value === 3 }
                        }, [
                          createVNode(_sfc_main$3)
                        ], 2)
                      ]),
                      createVNode("div", { class: "tab-content tab-space" }, [
                        createVNode("div", {
                          class: { "hidden": openTab.value !== 4, "block": openTab.value === 4 }
                        }, [
                          createVNode(_sfc_main$4)
                        ], 2)
                      ]),
                      createVNode("div", { class: "tab-content tab-space" }, [
                        createVNode("div", {
                          class: { "hidden": openTab.value !== 5, "block": openTab.value === 5 }
                        }, [
                          createVNode(_sfc_main$5)
                        ], 2)
                      ])
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Resume/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
