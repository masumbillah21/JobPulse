import { computed, mergeProps, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { usePage } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = {
  __name: "FormValidationErrors",
  __ssrInlineRender: true,
  setup(__props) {
    const errors = computed(() => usePage().props.errors);
    const hasErrors = computed(() => Object.keys(errors.value).length > 0);
    return (_ctx, _push, _parent, _attrs) => {
      if (hasErrors.value) {
        _push(ssrRenderComponent(_sfc_main$1, mergeProps({ color: "danger" }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<b${_scopeId}>Whoops! Something went wrong.</b><!--[-->`);
              ssrRenderList(errors.value, (error, key) => {
                _push2(`<span${_scopeId}>${ssrInterpolate(error)}</span>`);
              });
              _push2(`<!--]-->`);
            } else {
              return [
                createVNode("b", null, "Whoops! Something went wrong."),
                (openBlock(true), createBlock(Fragment, null, renderList(errors.value, (error, key) => {
                  return openBlock(), createBlock("span", { key }, toDisplayString(error), 1);
                }), 128))
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FormValidationErrors.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const FormValidationErrors = _sfc_main;
export {
  FormValidationErrors as F
};
