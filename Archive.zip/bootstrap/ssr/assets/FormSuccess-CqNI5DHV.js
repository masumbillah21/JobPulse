import { computed, mergeProps, withCtx, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { usePage } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = {
  __name: "FormSuccess",
  __ssrInlineRender: true,
  setup(__props) {
    const success = computed(() => usePage().props.session.success ?? "");
    return (_ctx, _push, _parent, _attrs) => {
      if (success.value) {
        _push(ssrRenderComponent(_sfc_main$1, mergeProps({ color: "success" }, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span${_scopeId}>${ssrInterpolate(success.value)}</span>`);
            } else {
              return [
                createVNode("span", null, toDisplayString(success.value), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FormSuccess.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const FormSuccess = _sfc_main;
export {
  FormSuccess as F
};
