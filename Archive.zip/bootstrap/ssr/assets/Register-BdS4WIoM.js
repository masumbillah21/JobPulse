import { ref, watch, computed, withCtx, unref, createVNode, openBlock, createBlock, Fragment, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { useForm, usePage, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { _ as _sfc_main$2 } from "./SectionFullScreen-CGqGp5K0.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { U as UserTypeEnum } from "./isSystemUser-D-zJOoLX.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./colors-K3EOgMMA.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./BaseIcon-C4zrUKd9.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = {
  __name: "Register",
  __ssrInlineRender: true,
  setup(__props) {
    const companyTypes = [
      { id: "", label: "Select Company Type" },
      { id: "Business development", label: "Business development" },
      { id: "Marketing", label: "Marketing" },
      { id: "Sales", label: "Sales" },
      { id: "Tech", label: "Tech" }
    ];
    const companySize = [
      { id: "", label: "Select Company Size" },
      { id: "0-10 Employees", label: "0-10 Employees" },
      { id: "11-20 Employees", label: "11-20 Employees" },
      { id: "21-30 Employees", label: "21-30 Employees" },
      { id: "31-40 Employees", label: "31-40 Employees" },
      { id: "41-50 Employees", label: "41-50 Employees" }
    ];
    const isCompany = ref(false);
    const form = useForm({
      name: "",
      email: "",
      password: "",
      password_confirmation: "",
      user_type: UserTypeEnum.CANDIDATE,
      company_name: "",
      description: "",
      company_type: "",
      address: "",
      phone: "",
      company_size: "",
      website: "",
      terms: []
    });
    watch(isCompany, (newValue) => {
      if (newValue) {
        form.user_type = UserTypeEnum.COMPANY;
      } else {
        form.user_type = UserTypeEnum.CANDIDATE;
      }
    });
    const hasTermsAndPrivacyPolicyFeature = computed(
      () => {
        var _a;
        return ((_a = usePage().props.jetstream) == null ? void 0 : _a.hasTermsAndPrivacyPolicyFeature) ?? {};
      }
    );
    const submit = () => {
      form.post(route("register"), {
        onFinish: () => {
          form.reset("password", "password_confirmation");
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Register" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              class: "flex-col",
              bg: "purplePink"
            }, {
              default: withCtx(({ cardClass }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(BaseButtons, { class: "mt-10" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          label: "Looking For Jobs",
                          color: isCompany.value ? "secondary" : "info",
                          onClick: ($event) => isCompany.value = false
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          label: "Looking To Hire",
                          color: isCompany.value ? "info" : "secondary",
                          onClick: ($event) => isCompany.value = true
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            label: "Looking For Jobs",
                            color: isCompany.value ? "secondary" : "info",
                            onClick: ($event) => isCompany.value = false
                          }, null, 8, ["color", "onClick"]),
                          createVNode(BaseButtonLink, {
                            label: "Looking To Hire",
                            color: isCompany.value ? "info" : "secondary",
                            onClick: ($event) => isCompany.value = true
                          }, null, 8, ["color", "onClick"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, {
                    class: [cardClass, "mb-24 mt-4"],
                    "is-form": "",
                    onSubmit: submit
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Name",
                          "label-for": "name",
                          help: "Please enter your name"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                icon: "fas fa-user",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).name,
                                  "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                  id: "name",
                                  icon: "fas fa-user",
                                  autocomplete: "name",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        if (isCompany.value) {
                          _push4(`<!--[-->`);
                          _push4(ssrRenderComponent(FormField, {
                            label: "Company Name",
                            "label-for": "company-name",
                            help: "Please enter your company name"
                          }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).company_name,
                                  "onUpdate:modelValue": ($event) => unref(form).company_name = $event,
                                  id: "company-name",
                                  icon: "fas fa-user",
                                  autocomplete: "company_name",
                                  type: "text",
                                  required: ""
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).company_name,
                                    "onUpdate:modelValue": ($event) => unref(form).company_name = $event,
                                    id: "company-name",
                                    icon: "fas fa-user",
                                    autocomplete: "company_name",
                                    type: "text",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(FormField, {
                            label: "Description",
                            "label-for": "description",
                            help: "Please enter your company description"
                          }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).description,
                                  "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                  id: "description",
                                  icon: "fas fa-info",
                                  autocomplete: "description",
                                  type: "text",
                                  required: ""
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).description,
                                    "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                    id: "description",
                                    icon: "fas fa-info",
                                    autocomplete: "description",
                                    type: "text",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(FormField, { label: "Company type" }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).company_type,
                                  "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                  icon: "fas fa-list",
                                  options: companyTypes
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).company_type,
                                    "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                    icon: "fas fa-list",
                                    options: companyTypes
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(FormField, {
                            label: "Address",
                            "label-for": "address",
                            help: "Please enter your company address"
                          }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).address,
                                  "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                  id: "address",
                                  icon: "fas fa-map-marker",
                                  autocomplete: "address",
                                  type: "address",
                                  required: ""
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).address,
                                    "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                    id: "address",
                                    icon: "fas fa-map-marker",
                                    autocomplete: "address",
                                    type: "address",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(FormField, {
                            label: "Phone Number",
                            "label-for": "phone",
                            help: "Please enter your company phone"
                          }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).phone,
                                  "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                  id: "phone",
                                  icon: "fas fa-phone",
                                  autocomplete: "phone",
                                  type: "tel",
                                  required: ""
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).phone,
                                    "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                    id: "phone",
                                    icon: "fas fa-phone",
                                    autocomplete: "phone",
                                    type: "tel",
                                    required: ""
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(FormField, { label: "Company Size" }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).company_size,
                                  "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                  icon: "fas fa-list",
                                  options: companySize
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).company_size,
                                    "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                    icon: "fas fa-list",
                                    options: companySize
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(FormField, {
                            label: "Website",
                            "label-for": "website",
                            help: "Please enter company website"
                          }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(FormControl, {
                                  modelValue: unref(form).website,
                                  "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                  id: "website",
                                  icon: "fas fa-globe",
                                  type: "url",
                                  autocomplete: "website"
                                }, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(FormControl, {
                                    modelValue: unref(form).website,
                                    "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                    id: "website",
                                    icon: "fas fa-globe",
                                    type: "url",
                                    autocomplete: "website"
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(ssrRenderComponent(FormField, {
                          label: "Email",
                          "label-for": "email",
                          help: "Please enter your email"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).email,
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                id: "email",
                                icon: "fas fa-envelope",
                                autocomplete: "email",
                                type: "email",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).email,
                                  "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                  id: "email",
                                  icon: "fas fa-envelope",
                                  autocomplete: "email",
                                  type: "email",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Password",
                          "label-for": "password",
                          help: "Please enter new password"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).password,
                                "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                id: "password",
                                icon: "fas fa-key",
                                type: "password",
                                autocomplete: "new-password",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).password,
                                  "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                  id: "password",
                                  icon: "fas fa-key",
                                  type: "password",
                                  autocomplete: "new-password",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Confirm Password",
                          "label-for": "password_confirmation",
                          help: "Please confirm your password"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).password_confirmation,
                                "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                                id: "password_confirmation",
                                icon: "fas fa-key",
                                type: "password",
                                autocomplete: "new-password",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).password_confirmation,
                                  "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                                  id: "password_confirmation",
                                  icon: "fas fa-key",
                                  type: "password",
                                  autocomplete: "new-password",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        if (hasTermsAndPrivacyPolicyFeature.value) {
                          _push4(ssrRenderComponent(FormCheckRadioGroup, {
                            modelValue: unref(form).terms,
                            "onUpdate:modelValue": ($event) => unref(form).terms = $event,
                            name: "remember",
                            options: { agree: "I agree to the Terms" },
                            required: ""
                          }, null, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtons, null, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: "Register",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(BaseButtonLink, {
                                "route-name": "login",
                                color: "info",
                                outline: "",
                                label: "Already Have Account ? Login"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(BaseButtonLink, {
                                  type: "submit",
                                  color: "info",
                                  label: "Register",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["class", "disabled"]),
                                createVNode(BaseButtonLink, {
                                  "route-name": "login",
                                  color: "info",
                                  outline: "",
                                  label: "Already Have Account ? Login"
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormField, {
                            label: "Name",
                            "label-for": "name",
                            help: "Please enter your name"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                id: "name",
                                icon: "fas fa-user",
                                autocomplete: "name",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          isCompany.value ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            createVNode(FormField, {
                              label: "Company Name",
                              "label-for": "company-name",
                              help: "Please enter your company name"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).company_name,
                                  "onUpdate:modelValue": ($event) => unref(form).company_name = $event,
                                  id: "company-name",
                                  icon: "fas fa-user",
                                  autocomplete: "company_name",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Description",
                              "label-for": "description",
                              help: "Please enter your company description"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).description,
                                  "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                  id: "description",
                                  icon: "fas fa-info",
                                  autocomplete: "description",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, { label: "Company type" }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).company_type,
                                  "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                  icon: "fas fa-list",
                                  options: companyTypes
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Address",
                              "label-for": "address",
                              help: "Please enter your company address"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).address,
                                  "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                  id: "address",
                                  icon: "fas fa-map-marker",
                                  autocomplete: "address",
                                  type: "address",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Phone Number",
                              "label-for": "phone",
                              help: "Please enter your company phone"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).phone,
                                  "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                  id: "phone",
                                  icon: "fas fa-phone",
                                  autocomplete: "phone",
                                  type: "tel",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, { label: "Company Size" }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).company_size,
                                  "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                  icon: "fas fa-list",
                                  options: companySize
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(FormField, {
                              label: "Website",
                              "label-for": "website",
                              help: "Please enter company website"
                            }, {
                              default: withCtx(() => [
                                createVNode(FormControl, {
                                  modelValue: unref(form).website,
                                  "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                  id: "website",
                                  icon: "fas fa-globe",
                                  type: "url",
                                  autocomplete: "website"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            })
                          ], 64)) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Email",
                            "label-for": "email",
                            help: "Please enter your email"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).email,
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                id: "email",
                                icon: "fas fa-envelope",
                                autocomplete: "email",
                                type: "email",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Password",
                            "label-for": "password",
                            help: "Please enter new password"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).password,
                                "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                id: "password",
                                icon: "fas fa-key",
                                type: "password",
                                autocomplete: "new-password",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Confirm Password",
                            "label-for": "password_confirmation",
                            help: "Please confirm your password"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).password_confirmation,
                                "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                                id: "password_confirmation",
                                icon: "fas fa-key",
                                type: "password",
                                autocomplete: "new-password",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          hasTermsAndPrivacyPolicyFeature.value ? (openBlock(), createBlock(FormCheckRadioGroup, {
                            key: 1,
                            modelValue: unref(form).terms,
                            "onUpdate:modelValue": ($event) => unref(form).terms = $event,
                            name: "remember",
                            options: { agree: "I agree to the Terms" },
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])) : createCommentVNode("", true),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: "Register",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["class", "disabled"]),
                              createVNode(BaseButtonLink, {
                                "route-name": "login",
                                color: "info",
                                outline: "",
                                label: "Already Have Account ? Login"
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(BaseButtons, { class: "mt-10" }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          label: "Looking For Jobs",
                          color: isCompany.value ? "secondary" : "info",
                          onClick: ($event) => isCompany.value = false
                        }, null, 8, ["color", "onClick"]),
                        createVNode(BaseButtonLink, {
                          label: "Looking To Hire",
                          color: isCompany.value ? "info" : "secondary",
                          onClick: ($event) => isCompany.value = true
                        }, null, 8, ["color", "onClick"])
                      ]),
                      _: 1
                    }),
                    createVNode(CardBox, {
                      class: [cardClass, "mb-24 mt-4"],
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormField, {
                          label: "Name",
                          "label-for": "name",
                          help: "Please enter your name"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).name,
                              "onUpdate:modelValue": ($event) => unref(form).name = $event,
                              id: "name",
                              icon: "fas fa-user",
                              autocomplete: "name",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        isCompany.value ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                          createVNode(FormField, {
                            label: "Company Name",
                            "label-for": "company-name",
                            help: "Please enter your company name"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).company_name,
                                "onUpdate:modelValue": ($event) => unref(form).company_name = $event,
                                id: "company-name",
                                icon: "fas fa-user",
                                autocomplete: "company_name",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Description",
                            "label-for": "description",
                            help: "Please enter your company description"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).description,
                                "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                id: "description",
                                icon: "fas fa-info",
                                autocomplete: "description",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Company type" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).company_type,
                                "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                                icon: "fas fa-list",
                                options: companyTypes
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Address",
                            "label-for": "address",
                            help: "Please enter your company address"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).address,
                                "onUpdate:modelValue": ($event) => unref(form).address = $event,
                                id: "address",
                                icon: "fas fa-map-marker",
                                autocomplete: "address",
                                type: "address",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Phone Number",
                            "label-for": "phone",
                            help: "Please enter your company phone"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).phone,
                                "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                id: "phone",
                                icon: "fas fa-phone",
                                autocomplete: "phone",
                                type: "tel",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Company Size" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).company_size,
                                "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                                icon: "fas fa-list",
                                options: companySize
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Website",
                            "label-for": "website",
                            help: "Please enter company website"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).website,
                                "onUpdate:modelValue": ($event) => unref(form).website = $event,
                                id: "website",
                                icon: "fas fa-globe",
                                type: "url",
                                autocomplete: "website"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          })
                        ], 64)) : createCommentVNode("", true),
                        createVNode(FormField, {
                          label: "Email",
                          "label-for": "email",
                          help: "Please enter your email"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).email,
                              "onUpdate:modelValue": ($event) => unref(form).email = $event,
                              id: "email",
                              icon: "fas fa-envelope",
                              autocomplete: "email",
                              type: "email",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Password",
                          "label-for": "password",
                          help: "Please enter new password"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).password,
                              "onUpdate:modelValue": ($event) => unref(form).password = $event,
                              id: "password",
                              icon: "fas fa-key",
                              type: "password",
                              autocomplete: "new-password",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Confirm Password",
                          "label-for": "password_confirmation",
                          help: "Please confirm your password"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).password_confirmation,
                              "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                              id: "password_confirmation",
                              icon: "fas fa-key",
                              type: "password",
                              autocomplete: "new-password",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        hasTermsAndPrivacyPolicyFeature.value ? (openBlock(), createBlock(FormCheckRadioGroup, {
                          key: 1,
                          modelValue: unref(form).terms,
                          "onUpdate:modelValue": ($event) => unref(form).terms = $event,
                          name: "remember",
                          options: { agree: "I agree to the Terms" },
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])) : createCommentVNode("", true),
                        createVNode(BaseDivider),
                        createVNode(BaseButtons, null, {
                          default: withCtx(() => [
                            createVNode(BaseButtonLink, {
                              type: "submit",
                              color: "info",
                              label: "Register",
                              class: { "opacity-25": unref(form).processing },
                              disabled: unref(form).processing
                            }, null, 8, ["class", "disabled"]),
                            createVNode(BaseButtonLink, {
                              "route-name": "login",
                              color: "info",
                              outline: "",
                              label: "Already Have Account ? Login"
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 2
                    }, 1032, ["class"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Register" }),
              createVNode(_sfc_main$2, {
                class: "flex-col",
                bg: "purplePink"
              }, {
                default: withCtx(({ cardClass }) => [
                  createVNode(BaseButtons, { class: "mt-10" }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        label: "Looking For Jobs",
                        color: isCompany.value ? "secondary" : "info",
                        onClick: ($event) => isCompany.value = false
                      }, null, 8, ["color", "onClick"]),
                      createVNode(BaseButtonLink, {
                        label: "Looking To Hire",
                        color: isCompany.value ? "info" : "secondary",
                        onClick: ($event) => isCompany.value = true
                      }, null, 8, ["color", "onClick"])
                    ]),
                    _: 1
                  }),
                  createVNode(CardBox, {
                    class: [cardClass, "mb-24 mt-4"],
                    "is-form": "",
                    onSubmit: withModifiers(submit, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(FormValidationErrors),
                      createVNode(FormField, {
                        label: "Name",
                        "label-for": "name",
                        help: "Please enter your name"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            id: "name",
                            icon: "fas fa-user",
                            autocomplete: "name",
                            type: "text",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      isCompany.value ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                        createVNode(FormField, {
                          label: "Company Name",
                          "label-for": "company-name",
                          help: "Please enter your company name"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).company_name,
                              "onUpdate:modelValue": ($event) => unref(form).company_name = $event,
                              id: "company-name",
                              icon: "fas fa-user",
                              autocomplete: "company_name",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Description",
                          "label-for": "description",
                          help: "Please enter your company description"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).description,
                              "onUpdate:modelValue": ($event) => unref(form).description = $event,
                              id: "description",
                              icon: "fas fa-info",
                              autocomplete: "description",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, { label: "Company type" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).company_type,
                              "onUpdate:modelValue": ($event) => unref(form).company_type = $event,
                              icon: "fas fa-list",
                              options: companyTypes
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Address",
                          "label-for": "address",
                          help: "Please enter your company address"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).address,
                              "onUpdate:modelValue": ($event) => unref(form).address = $event,
                              id: "address",
                              icon: "fas fa-map-marker",
                              autocomplete: "address",
                              type: "address",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Phone Number",
                          "label-for": "phone",
                          help: "Please enter your company phone"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).phone,
                              "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                              id: "phone",
                              icon: "fas fa-phone",
                              autocomplete: "phone",
                              type: "tel",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, { label: "Company Size" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).company_size,
                              "onUpdate:modelValue": ($event) => unref(form).company_size = $event,
                              icon: "fas fa-list",
                              options: companySize
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Website",
                          "label-for": "website",
                          help: "Please enter company website"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).website,
                              "onUpdate:modelValue": ($event) => unref(form).website = $event,
                              id: "website",
                              icon: "fas fa-globe",
                              type: "url",
                              autocomplete: "website"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        })
                      ], 64)) : createCommentVNode("", true),
                      createVNode(FormField, {
                        label: "Email",
                        "label-for": "email",
                        help: "Please enter your email"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            id: "email",
                            icon: "fas fa-envelope",
                            autocomplete: "email",
                            type: "email",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(FormField, {
                        label: "Password",
                        "label-for": "password",
                        help: "Please enter new password"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).password,
                            "onUpdate:modelValue": ($event) => unref(form).password = $event,
                            id: "password",
                            icon: "fas fa-key",
                            type: "password",
                            autocomplete: "new-password",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(FormField, {
                        label: "Confirm Password",
                        "label-for": "password_confirmation",
                        help: "Please confirm your password"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).password_confirmation,
                            "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                            id: "password_confirmation",
                            icon: "fas fa-key",
                            type: "password",
                            autocomplete: "new-password",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      hasTermsAndPrivacyPolicyFeature.value ? (openBlock(), createBlock(FormCheckRadioGroup, {
                        key: 1,
                        modelValue: unref(form).terms,
                        "onUpdate:modelValue": ($event) => unref(form).terms = $event,
                        name: "remember",
                        options: { agree: "I agree to the Terms" },
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])) : createCommentVNode("", true),
                      createVNode(BaseDivider),
                      createVNode(BaseButtons, null, {
                        default: withCtx(() => [
                          createVNode(BaseButtonLink, {
                            type: "submit",
                            color: "info",
                            label: "Register",
                            class: { "opacity-25": unref(form).processing },
                            disabled: unref(form).processing
                          }, null, 8, ["class", "disabled"]),
                          createVNode(BaseButtonLink, {
                            "route-name": "login",
                            color: "info",
                            outline: "",
                            label: "Already Have Account ? Login"
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 2
                  }, 1032, ["class"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Auth/Register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
