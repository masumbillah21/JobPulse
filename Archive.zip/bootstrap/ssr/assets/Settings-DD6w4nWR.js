import { defineComponent, ref, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { S as SectionTitle } from "./SectionTitle-qF5u6qV8.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { F as FormFilePicker } from "./FormFilePicker-BtfvB5iT.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./IconRounded-RF1xkXym.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Settings",
  __ssrInlineRender: true,
  setup(__props) {
    const settingList = usePage().props.settingList ?? null;
    const homePages = usePage().props.homePages;
    const blogPages = usePage().props.blogPages;
    const contactPages = usePage().props.contactPages;
    const jobPages = usePage().props.jobPages;
    const homeList = [
      {
        id: "",
        label: "Select Page"
      }
    ];
    homeList.push(...homePages);
    const blogList = [
      {
        id: "",
        label: "Select Page"
      }
    ];
    blogList.push(...blogPages);
    const contactList = [
      {
        id: "",
        label: "Select Page"
      }
    ];
    contactList.push(...contactPages);
    const jobList = [
      {
        id: "",
        label: "Select Page"
      }
    ];
    jobList.push(...jobPages);
    const urls = usePage().props.urls;
    const storage = urls.storeUrl;
    const form = useForm({
      logo: "",
      home: "",
      blog: "",
      contact: "",
      job: "",
      catebg: ""
    });
    const logoUrl = ref("");
    const cateBgUrl = ref("");
    if (settingList) {
      settingList.forEach((item) => {
        if (item.name == "logo") {
          logoUrl.value = storage + "/" + item.value;
        }
        if (item.name == "home") {
          form.home = item.value;
        }
        if (item.name == "blog") {
          form.blog = item.value;
        }
        if (item.name == "contact") {
          form.contact = item.value;
        }
        if (item.name == "job") {
          form.job = item.value;
        }
        if (item.name == "catebg") {
          cateBgUrl.value = item.value;
        }
      });
    }
    const submit = () => {
      form.post(route("admin.settings.store"));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Settings" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitle, {
                    icon: "fas fa-arrow-circle-right",
                    title: "Settings",
                    main: ""
                  }, null, _parent3, _scopeId2));
                  _push3(`<div class="flex justify-center items-center"${_scopeId2}>`);
                  _push3(ssrRenderComponent(CardBox, {
                    class: "my-24 w-9/12",
                    "is-form": "",
                    onSubmit: submit
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormSuccess, null, null, _parent4, _scopeId3));
                        if (logoUrl.value) {
                          _push4(`<img class="mb-2"${ssrRenderAttr("src", logoUrl.value)} alt="logo" width="300"${_scopeId3}>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(ssrRenderComponent(FormField, {
                          label: "Logo",
                          help: "Max 500kb"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormFilePicker, {
                                label: "Upload Logo",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).logo = $event
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormFilePicker, {
                                  label: "Upload Logo",
                                  color: "success",
                                  "onUpdate:modelValue": ($event) => unref(form).logo = $event
                                }, null, 8, ["onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, { label: "Home Page" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).home,
                                "onUpdate:modelValue": ($event) => unref(form).home = $event,
                                options: homeList
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).home,
                                  "onUpdate:modelValue": ($event) => unref(form).home = $event,
                                  options: homeList
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, { label: "Job Page" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).job,
                                "onUpdate:modelValue": ($event) => unref(form).job = $event,
                                options: jobList
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).job,
                                  "onUpdate:modelValue": ($event) => unref(form).job = $event,
                                  options: jobList
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, { label: "Blog Page" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).blog,
                                "onUpdate:modelValue": ($event) => unref(form).blog = $event,
                                options: blogList
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).blog,
                                  "onUpdate:modelValue": ($event) => unref(form).blog = $event,
                                  options: blogList
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, { label: "Contact Page" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).contact,
                                "onUpdate:modelValue": ($event) => unref(form).contact = $event,
                                options: contactList
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).contact,
                                  "onUpdate:modelValue": ($event) => unref(form).contact = $event,
                                  options: contactList
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        if (cateBgUrl.value) {
                          _push4(`<img class="mb-2"${ssrRenderAttr("src", `${unref(storage)}/${cateBgUrl.value}`)} alt="Category Bg" width="300"${_scopeId3}>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(ssrRenderComponent(FormField, {
                          label: "Category Titlebar Background Image",
                          help: "Max 500kb"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormFilePicker, {
                                label: "Upload image",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).catebg = $event
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormFilePicker, {
                                  label: "Upload image",
                                  color: "success",
                                  "onUpdate:modelValue": ($event) => unref(form).catebg = $event
                                }, null, 8, ["onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtons, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(BaseButtonLink, {
                                icon: "far fa-save",
                                type: "submit",
                                color: "info",
                                label: "Save",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(BaseButtonLink, {
                                  icon: "far fa-save",
                                  type: "submit",
                                  color: "info",
                                  label: "Save",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["class", "disabled"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          logoUrl.value ? (openBlock(), createBlock("img", {
                            key: 0,
                            class: "mb-2",
                            src: logoUrl.value,
                            alt: "logo",
                            width: "300"
                          }, null, 8, ["src"])) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Logo",
                            help: "Max 500kb"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormFilePicker, {
                                label: "Upload Logo",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).logo = $event
                              }, null, 8, ["onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(FormField, { label: "Home Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).home,
                                "onUpdate:modelValue": ($event) => unref(form).home = $event,
                                options: homeList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Job Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job,
                                "onUpdate:modelValue": ($event) => unref(form).job = $event,
                                options: jobList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Blog Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).blog,
                                "onUpdate:modelValue": ($event) => unref(form).blog = $event,
                                options: blogList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Contact Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).contact,
                                "onUpdate:modelValue": ($event) => unref(form).contact = $event,
                                options: contactList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          cateBgUrl.value ? (openBlock(), createBlock("img", {
                            key: 1,
                            class: "mb-2",
                            src: `${unref(storage)}/${cateBgUrl.value}`,
                            alt: "Category Bg",
                            width: "300"
                          }, null, 8, ["src"])) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Category Titlebar Background Image",
                            help: "Max 500kb"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormFilePicker, {
                                label: "Upload image",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).catebg = $event
                              }, null, 8, ["onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                icon: "far fa-save",
                                type: "submit",
                                color: "info",
                                label: "Save",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["class", "disabled"])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitle, {
                      icon: "fas fa-arrow-circle-right",
                      title: "Settings",
                      main: ""
                    }),
                    createVNode("div", { class: "flex justify-center items-center" }, [
                      createVNode(CardBox, {
                        class: "my-24 w-9/12",
                        "is-form": "",
                        onSubmit: withModifiers(submit, ["prevent"])
                      }, {
                        default: withCtx(() => [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          logoUrl.value ? (openBlock(), createBlock("img", {
                            key: 0,
                            class: "mb-2",
                            src: logoUrl.value,
                            alt: "logo",
                            width: "300"
                          }, null, 8, ["src"])) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Logo",
                            help: "Max 500kb"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormFilePicker, {
                                label: "Upload Logo",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).logo = $event
                              }, null, 8, ["onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(FormField, { label: "Home Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).home,
                                "onUpdate:modelValue": ($event) => unref(form).home = $event,
                                options: homeList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Job Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job,
                                "onUpdate:modelValue": ($event) => unref(form).job = $event,
                                options: jobList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Blog Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).blog,
                                "onUpdate:modelValue": ($event) => unref(form).blog = $event,
                                options: blogList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, { label: "Contact Page" }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).contact,
                                "onUpdate:modelValue": ($event) => unref(form).contact = $event,
                                options: contactList
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          cateBgUrl.value ? (openBlock(), createBlock("img", {
                            key: 1,
                            class: "mb-2",
                            src: `${unref(storage)}/${cateBgUrl.value}`,
                            alt: "Category Bg",
                            width: "300"
                          }, null, 8, ["src"])) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Category Titlebar Background Image",
                            help: "Max 500kb"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormFilePicker, {
                                label: "Upload image",
                                color: "success",
                                "onUpdate:modelValue": ($event) => unref(form).catebg = $event
                              }, null, 8, ["onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                icon: "far fa-save",
                                type: "submit",
                                color: "info",
                                label: "Save",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["class", "disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Settings" }),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitle, {
                    icon: "fas fa-arrow-circle-right",
                    title: "Settings",
                    main: ""
                  }),
                  createVNode("div", { class: "flex justify-center items-center" }, [
                    createVNode(CardBox, {
                      class: "my-24 w-9/12",
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormSuccess),
                        logoUrl.value ? (openBlock(), createBlock("img", {
                          key: 0,
                          class: "mb-2",
                          src: logoUrl.value,
                          alt: "logo",
                          width: "300"
                        }, null, 8, ["src"])) : createCommentVNode("", true),
                        createVNode(FormField, {
                          label: "Logo",
                          help: "Max 500kb"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormFilePicker, {
                              label: "Upload Logo",
                              color: "success",
                              "onUpdate:modelValue": ($event) => unref(form).logo = $event
                            }, null, 8, ["onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(BaseDivider),
                        createVNode(FormField, { label: "Home Page" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).home,
                              "onUpdate:modelValue": ($event) => unref(form).home = $event,
                              options: homeList
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, { label: "Job Page" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).job,
                              "onUpdate:modelValue": ($event) => unref(form).job = $event,
                              options: jobList
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, { label: "Blog Page" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).blog,
                              "onUpdate:modelValue": ($event) => unref(form).blog = $event,
                              options: blogList
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, { label: "Contact Page" }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).contact,
                              "onUpdate:modelValue": ($event) => unref(form).contact = $event,
                              options: contactList
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        cateBgUrl.value ? (openBlock(), createBlock("img", {
                          key: 1,
                          class: "mb-2",
                          src: `${unref(storage)}/${cateBgUrl.value}`,
                          alt: "Category Bg",
                          width: "300"
                        }, null, 8, ["src"])) : createCommentVNode("", true),
                        createVNode(FormField, {
                          label: "Category Titlebar Background Image",
                          help: "Max 500kb"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormFilePicker, {
                              label: "Upload image",
                              color: "success",
                              "onUpdate:modelValue": ($event) => unref(form).catebg = $event
                            }, null, 8, ["onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(BaseDivider),
                        createVNode(BaseButtons, null, {
                          default: withCtx(() => [
                            createVNode(BaseButtonLink, {
                              icon: "far fa-save",
                              type: "submit",
                              color: "info",
                              label: "Save",
                              class: { "opacity-25": unref(form).processing },
                              disabled: unref(form).processing
                            }, null, 8, ["class", "disabled"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Settings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
