import { defineComponent, withCtx, unref, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { F as FormSuccess } from "./FormSuccess-CqNI5DHV.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { i as isSystemUser } from "./isSystemUser-D-zJOoLX.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./IconRounded-RF1xkXym.js";
import "./NotificationBarInCard-Dg146C8Q.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  setup(__props) {
    const jobData = usePage().props.jobData ?? null;
    const jobCateLists = usePage().props.jobCateLists ?? null;
    const jobTypes = [
      { id: "", label: "Select Job Type" },
      { id: "Full Time", label: "Full Time" },
      { id: "Part Time", label: "Part Time" },
      { id: "Contract", label: "Contract" }
    ];
    const jobLevel = [
      { id: "", label: "Select Experience Level" },
      { id: "Beginner", label: "Beginner" },
      { id: "Intermiddiate", label: "Intermidiate" },
      { id: "Advanced", label: "Advanced" }
    ];
    const workType = [
      { id: "", label: "Select a type" },
      { id: "Remote", label: "Remote" },
      { id: "On Site", label: "On Site" },
      { id: "Hybrid", label: "Hybrid" }
    ];
    const jobCates = [
      { id: 0, label: "Select a category" }
    ];
    if (jobCateLists) {
      jobCates.push(...jobCateLists);
    }
    const form = useForm({
      id: 0,
      title: "",
      location: "",
      job_type: jobTypes[0].id,
      job_level: jobLevel[0].id,
      job_category_id: jobCates[0].id,
      work_type: workType[0].id,
      description: "",
      requirements: "",
      responsibilities: "",
      salary: "",
      facilities: "",
      skills: "",
      closing_date: "",
      status: "",
      _method: "post"
    });
    if (jobData !== null) {
      form.id = jobData.id;
      form.title = jobData.title;
      form.location = jobData.location;
      form.job_type = jobData.job_type;
      form.job_level = jobData.job_level;
      form.job_category_id = jobData.job_category_id;
      form.work_type = jobData.work_type;
      form.description = jobData.description;
      form.requirements = jobData.requirements;
      form.responsibilities = jobData.responsibilities;
      form.salary = jobData.salary;
      form.facilities = jobData.facilities;
      form.skills = jobData.skills;
      form.status = jobData.status;
      form._method = "put";
    }
    const submit = () => {
      if (jobData !== null) {
        update();
      } else {
        create();
      }
    };
    const create = () => {
      const routeName = isSystemUser() ? "admin.jobs.store" : "jobs.store";
      form.post(route(routeName), {
        onSuccess: () => form.reset()
      });
    };
    const update = () => {
      const routeName = isSystemUser() ? "admin.jobs.update" : "jobs.update";
      form.post(route(routeName, form.id));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(jobData) !== null ? "Edit job" : "Create job"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(jobData) !== null ? "Edit job" : "Create job",
                    main: ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "jobs.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(BaseButtonLink, {
                            icon: "far fa-arrow-alt-circle-left",
                            label: "Back",
                            routeName: "jobs.index",
                            color: "contrast",
                            "rounded-full": "",
                            small: ""
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="flex justify-center items-center"${_scopeId2}>`);
                  _push3(ssrRenderComponent(CardBox, {
                    class: "my-24 w-1/2",
                    "is-form": "",
                    onSubmit: submit
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormSuccess, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Title",
                          "label-for": "title",
                          help: "Please enter job title"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).title,
                                "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                id: "title",
                                icon: "fas fa-pencil-alt",
                                type: "text",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).title,
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  id: "title",
                                  icon: "fas fa-pencil-alt",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Job Category",
                          help: "Please select a category"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).job_category_id,
                                "onUpdate:modelValue": ($event) => unref(form).job_category_id = $event,
                                icon: "fas fa-list-alt",
                                options: jobCates
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).job_category_id,
                                  "onUpdate:modelValue": ($event) => unref(form).job_category_id = $event,
                                  icon: "fas fa-list-alt",
                                  options: jobCates
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Location",
                          "label-for": "location",
                          help: "Please enter job location"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).location,
                                "onUpdate:modelValue": ($event) => unref(form).location = $event,
                                id: "location",
                                icon: "fas fa-map-marker",
                                type: "text",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).location,
                                  "onUpdate:modelValue": ($event) => unref(form).location = $event,
                                  id: "location",
                                  icon: "fas fa-map-marker",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Job Type",
                          help: "Please select job type"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).job_type,
                                "onUpdate:modelValue": ($event) => unref(form).job_type = $event,
                                icon: "fas fa-list-alt",
                                options: jobTypes
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).job_type,
                                  "onUpdate:modelValue": ($event) => unref(form).job_type = $event,
                                  icon: "fas fa-list-alt",
                                  options: jobTypes
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Experience Level",
                          help: "Please select one"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).job_level,
                                "onUpdate:modelValue": ($event) => unref(form).job_level = $event,
                                icon: "fas fa-list-alt",
                                options: jobLevel
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).job_level,
                                  "onUpdate:modelValue": ($event) => unref(form).job_level = $event,
                                  icon: "fas fa-list-alt",
                                  options: jobLevel
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Work Place",
                          help: "Please select one"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).work_type,
                                "onUpdate:modelValue": ($event) => unref(form).work_type = $event,
                                icon: "fas fa-list-alt",
                                options: workType
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).work_type,
                                  "onUpdate:modelValue": ($event) => unref(form).work_type = $event,
                                  icon: "fas fa-list-alt",
                                  options: workType
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Description",
                          "label-for": "description",
                          help: "Please enter job description"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).description,
                                "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                id: "description",
                                type: "textarea",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).description,
                                  "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                  id: "description",
                                  type: "textarea",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Requirements",
                          "label-for": "requirements",
                          help: "Please enter job requirements"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).requirements,
                                "onUpdate:modelValue": ($event) => unref(form).requirements = $event,
                                id: "requirements",
                                type: "textarea",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).requirements,
                                  "onUpdate:modelValue": ($event) => unref(form).requirements = $event,
                                  id: "requirements",
                                  type: "textarea",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Responsibilities",
                          "label-for": "responsibilities",
                          help: "Please enter job responsibilities"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).responsibilities,
                                "onUpdate:modelValue": ($event) => unref(form).responsibilities = $event,
                                id: "responsibilities",
                                type: "textarea",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).responsibilities,
                                  "onUpdate:modelValue": ($event) => unref(form).responsibilities = $event,
                                  id: "responsibilities",
                                  type: "textarea",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Salary",
                          "label-for": "salary",
                          help: "Please enter job salary"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).salary,
                                "onUpdate:modelValue": ($event) => unref(form).salary = $event,
                                id: "salary",
                                icon: "fas fa-dollar-sign",
                                type: "number",
                                step: "0.01",
                                min: "1",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).salary,
                                  "onUpdate:modelValue": ($event) => unref(form).salary = $event,
                                  id: "salary",
                                  icon: "fas fa-dollar-sign",
                                  type: "number",
                                  step: "0.01",
                                  min: "1",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Facilities",
                          "label-for": "facilities",
                          help: "Please enter job facilities"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).facilities,
                                "onUpdate:modelValue": ($event) => unref(form).facilities = $event,
                                id: "facilities",
                                type: "textarea",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).facilities,
                                  "onUpdate:modelValue": ($event) => unref(form).facilities = $event,
                                  id: "facilities",
                                  type: "textarea",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Skills",
                          "label-for": "skills",
                          help: "Write skill sets seprated by comma"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).skills,
                                "onUpdate:modelValue": ($event) => unref(form).skills = $event,
                                id: "skills",
                                type: "text",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).skills,
                                  "onUpdate:modelValue": ($event) => unref(form).skills = $event,
                                  id: "skills",
                                  type: "text",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        if (unref(jobData) && unref(jobData).closing_date) {
                          _push4(`<p class="text-red-500"${_scopeId3}>Closing Date: ${ssrInterpolate(unref(jobData).closing_date)}</p>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(ssrRenderComponent(FormField, {
                          label: "Closing date",
                          "label-for": "closing-date",
                          help: "Please enter job closing date"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).closing_date,
                                "onUpdate:modelValue": ($event) => unref(form).closing_date = $event,
                                id: "closing-date",
                                type: "date"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).closing_date,
                                  "onUpdate:modelValue": ($event) => unref(form).closing_date = $event,
                                  id: "closing-date",
                                  type: "date"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormCheckRadioGroup, {
                          modelValue: unref(form).status,
                          "onUpdate:modelValue": ($event) => unref(form).status = $event,
                          name: "status",
                          type: "radio",
                          options: { "1": "Active", "0": "Inactive" }
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtons, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: unref(jobData) !== null ? "Update" : "Create",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(BaseButtonLink, {
                                  type: "submit",
                                  color: "info",
                                  label: unref(jobData) !== null ? "Update" : "Create",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["label", "class", "disabled"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          createVNode(FormField, {
                            label: "Title",
                            "label-for": "title",
                            help: "Please enter job title"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).title,
                                "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                id: "title",
                                icon: "fas fa-pencil-alt",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Job Category",
                            help: "Please select a category"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job_category_id,
                                "onUpdate:modelValue": ($event) => unref(form).job_category_id = $event,
                                icon: "fas fa-list-alt",
                                options: jobCates
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Location",
                            "label-for": "location",
                            help: "Please enter job location"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).location,
                                "onUpdate:modelValue": ($event) => unref(form).location = $event,
                                id: "location",
                                icon: "fas fa-map-marker",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Job Type",
                            help: "Please select job type"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job_type,
                                "onUpdate:modelValue": ($event) => unref(form).job_type = $event,
                                icon: "fas fa-list-alt",
                                options: jobTypes
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Experience Level",
                            help: "Please select one"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job_level,
                                "onUpdate:modelValue": ($event) => unref(form).job_level = $event,
                                icon: "fas fa-list-alt",
                                options: jobLevel
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Work Place",
                            help: "Please select one"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).work_type,
                                "onUpdate:modelValue": ($event) => unref(form).work_type = $event,
                                icon: "fas fa-list-alt",
                                options: workType
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Description",
                            "label-for": "description",
                            help: "Please enter job description"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).description,
                                "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                id: "description",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Requirements",
                            "label-for": "requirements",
                            help: "Please enter job requirements"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).requirements,
                                "onUpdate:modelValue": ($event) => unref(form).requirements = $event,
                                id: "requirements",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Responsibilities",
                            "label-for": "responsibilities",
                            help: "Please enter job responsibilities"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).responsibilities,
                                "onUpdate:modelValue": ($event) => unref(form).responsibilities = $event,
                                id: "responsibilities",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Salary",
                            "label-for": "salary",
                            help: "Please enter job salary"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).salary,
                                "onUpdate:modelValue": ($event) => unref(form).salary = $event,
                                id: "salary",
                                icon: "fas fa-dollar-sign",
                                type: "number",
                                step: "0.01",
                                min: "1",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Facilities",
                            "label-for": "facilities",
                            help: "Please enter job facilities"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).facilities,
                                "onUpdate:modelValue": ($event) => unref(form).facilities = $event,
                                id: "facilities",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Skills",
                            "label-for": "skills",
                            help: "Write skill sets seprated by comma"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).skills,
                                "onUpdate:modelValue": ($event) => unref(form).skills = $event,
                                id: "skills",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          unref(jobData) && unref(jobData).closing_date ? (openBlock(), createBlock("p", {
                            key: 0,
                            class: "text-red-500"
                          }, "Closing Date: " + toDisplayString(unref(jobData).closing_date), 1)) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Closing date",
                            "label-for": "closing-date",
                            help: "Please enter job closing date"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).closing_date,
                                "onUpdate:modelValue": ($event) => unref(form).closing_date = $event,
                                id: "closing-date",
                                type: "date"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormCheckRadioGroup, {
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            name: "status",
                            type: "radio",
                            options: { "1": "Active", "0": "Inactive" }
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: unref(jobData) !== null ? "Update" : "Create",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["label", "class", "disabled"])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: unref(jobData) !== null ? "Edit job" : "Create job",
                      main: ""
                    }, {
                      default: withCtx(() => [
                        createVNode(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "jobs.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        })
                      ]),
                      _: 1
                    }, 8, ["title"]),
                    createVNode("div", { class: "flex justify-center items-center" }, [
                      createVNode(CardBox, {
                        class: "my-24 w-1/2",
                        "is-form": "",
                        onSubmit: withModifiers(submit, ["prevent"])
                      }, {
                        default: withCtx(() => [
                          createVNode(FormValidationErrors),
                          createVNode(FormSuccess),
                          createVNode(FormField, {
                            label: "Title",
                            "label-for": "title",
                            help: "Please enter job title"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).title,
                                "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                id: "title",
                                icon: "fas fa-pencil-alt",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Job Category",
                            help: "Please select a category"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job_category_id,
                                "onUpdate:modelValue": ($event) => unref(form).job_category_id = $event,
                                icon: "fas fa-list-alt",
                                options: jobCates
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Location",
                            "label-for": "location",
                            help: "Please enter job location"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).location,
                                "onUpdate:modelValue": ($event) => unref(form).location = $event,
                                id: "location",
                                icon: "fas fa-map-marker",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Job Type",
                            help: "Please select job type"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job_type,
                                "onUpdate:modelValue": ($event) => unref(form).job_type = $event,
                                icon: "fas fa-list-alt",
                                options: jobTypes
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Experience Level",
                            help: "Please select one"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).job_level,
                                "onUpdate:modelValue": ($event) => unref(form).job_level = $event,
                                icon: "fas fa-list-alt",
                                options: jobLevel
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Work Place",
                            help: "Please select one"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).work_type,
                                "onUpdate:modelValue": ($event) => unref(form).work_type = $event,
                                icon: "fas fa-list-alt",
                                options: workType
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Description",
                            "label-for": "description",
                            help: "Please enter job description"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).description,
                                "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                id: "description",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Requirements",
                            "label-for": "requirements",
                            help: "Please enter job requirements"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).requirements,
                                "onUpdate:modelValue": ($event) => unref(form).requirements = $event,
                                id: "requirements",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Responsibilities",
                            "label-for": "responsibilities",
                            help: "Please enter job responsibilities"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).responsibilities,
                                "onUpdate:modelValue": ($event) => unref(form).responsibilities = $event,
                                id: "responsibilities",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Salary",
                            "label-for": "salary",
                            help: "Please enter job salary"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).salary,
                                "onUpdate:modelValue": ($event) => unref(form).salary = $event,
                                id: "salary",
                                icon: "fas fa-dollar-sign",
                                type: "number",
                                step: "0.01",
                                min: "1",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Facilities",
                            "label-for": "facilities",
                            help: "Please enter job facilities"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).facilities,
                                "onUpdate:modelValue": ($event) => unref(form).facilities = $event,
                                id: "facilities",
                                type: "textarea",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Skills",
                            "label-for": "skills",
                            help: "Write skill sets seprated by comma"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).skills,
                                "onUpdate:modelValue": ($event) => unref(form).skills = $event,
                                id: "skills",
                                type: "text",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          unref(jobData) && unref(jobData).closing_date ? (openBlock(), createBlock("p", {
                            key: 0,
                            class: "text-red-500"
                          }, "Closing Date: " + toDisplayString(unref(jobData).closing_date), 1)) : createCommentVNode("", true),
                          createVNode(FormField, {
                            label: "Closing date",
                            "label-for": "closing-date",
                            help: "Please enter job closing date"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).closing_date,
                                "onUpdate:modelValue": ($event) => unref(form).closing_date = $event,
                                id: "closing-date",
                                type: "date"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormCheckRadioGroup, {
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            name: "status",
                            type: "radio",
                            options: { "1": "Active", "0": "Inactive" }
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(BaseDivider),
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: unref(jobData) !== null ? "Update" : "Create",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["label", "class", "disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(jobData) !== null ? "Edit job" : "Create job"
              }, null, 8, ["title"]),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: unref(jobData) !== null ? "Edit job" : "Create job",
                    main: ""
                  }, {
                    default: withCtx(() => [
                      createVNode(BaseButtonLink, {
                        icon: "far fa-arrow-alt-circle-left",
                        label: "Back",
                        routeName: "jobs.index",
                        color: "contrast",
                        "rounded-full": "",
                        small: ""
                      })
                    ]),
                    _: 1
                  }, 8, ["title"]),
                  createVNode("div", { class: "flex justify-center items-center" }, [
                    createVNode(CardBox, {
                      class: "my-24 w-1/2",
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        createVNode(FormSuccess),
                        createVNode(FormField, {
                          label: "Title",
                          "label-for": "title",
                          help: "Please enter job title"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).title,
                              "onUpdate:modelValue": ($event) => unref(form).title = $event,
                              id: "title",
                              icon: "fas fa-pencil-alt",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Job Category",
                          help: "Please select a category"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).job_category_id,
                              "onUpdate:modelValue": ($event) => unref(form).job_category_id = $event,
                              icon: "fas fa-list-alt",
                              options: jobCates
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Location",
                          "label-for": "location",
                          help: "Please enter job location"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).location,
                              "onUpdate:modelValue": ($event) => unref(form).location = $event,
                              id: "location",
                              icon: "fas fa-map-marker",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Job Type",
                          help: "Please select job type"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).job_type,
                              "onUpdate:modelValue": ($event) => unref(form).job_type = $event,
                              icon: "fas fa-list-alt",
                              options: jobTypes
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Experience Level",
                          help: "Please select one"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).job_level,
                              "onUpdate:modelValue": ($event) => unref(form).job_level = $event,
                              icon: "fas fa-list-alt",
                              options: jobLevel
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Work Place",
                          help: "Please select one"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).work_type,
                              "onUpdate:modelValue": ($event) => unref(form).work_type = $event,
                              icon: "fas fa-list-alt",
                              options: workType
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Description",
                          "label-for": "description",
                          help: "Please enter job description"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).description,
                              "onUpdate:modelValue": ($event) => unref(form).description = $event,
                              id: "description",
                              type: "textarea",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Requirements",
                          "label-for": "requirements",
                          help: "Please enter job requirements"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).requirements,
                              "onUpdate:modelValue": ($event) => unref(form).requirements = $event,
                              id: "requirements",
                              type: "textarea",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Responsibilities",
                          "label-for": "responsibilities",
                          help: "Please enter job responsibilities"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).responsibilities,
                              "onUpdate:modelValue": ($event) => unref(form).responsibilities = $event,
                              id: "responsibilities",
                              type: "textarea",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Salary",
                          "label-for": "salary",
                          help: "Please enter job salary"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).salary,
                              "onUpdate:modelValue": ($event) => unref(form).salary = $event,
                              id: "salary",
                              icon: "fas fa-dollar-sign",
                              type: "number",
                              step: "0.01",
                              min: "1",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Facilities",
                          "label-for": "facilities",
                          help: "Please enter job facilities"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).facilities,
                              "onUpdate:modelValue": ($event) => unref(form).facilities = $event,
                              id: "facilities",
                              type: "textarea",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Skills",
                          "label-for": "skills",
                          help: "Write skill sets seprated by comma"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).skills,
                              "onUpdate:modelValue": ($event) => unref(form).skills = $event,
                              id: "skills",
                              type: "text",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        unref(jobData) && unref(jobData).closing_date ? (openBlock(), createBlock("p", {
                          key: 0,
                          class: "text-red-500"
                        }, "Closing Date: " + toDisplayString(unref(jobData).closing_date), 1)) : createCommentVNode("", true),
                        createVNode(FormField, {
                          label: "Closing date",
                          "label-for": "closing-date",
                          help: "Please enter job closing date"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).closing_date,
                              "onUpdate:modelValue": ($event) => unref(form).closing_date = $event,
                              id: "closing-date",
                              type: "date"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormCheckRadioGroup, {
                          modelValue: unref(form).status,
                          "onUpdate:modelValue": ($event) => unref(form).status = $event,
                          name: "status",
                          type: "radio",
                          options: { "1": "Active", "0": "Inactive" }
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(BaseDivider),
                        createVNode(BaseButtons, null, {
                          default: withCtx(() => [
                            createVNode(BaseButtonLink, {
                              type: "submit",
                              color: "info",
                              label: unref(jobData) !== null ? "Update" : "Create",
                              class: { "opacity-25": unref(form).processing },
                              disabled: unref(form).processing
                            }, null, 8, ["label", "class", "disabled"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Jobs/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
