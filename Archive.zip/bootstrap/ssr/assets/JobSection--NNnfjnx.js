import { defineComponent, ref, computed, mergeProps, withCtx, createVNode, unref, toDisplayString, createTextVNode, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { Link } from "@inertiajs/vue3";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "JobSection",
  __ssrInlineRender: true,
  props: {
    jobList: {
      type: [Object, Array],
      required: true
    },
    allJobs: {
      type: [Object, Array],
      required: true
    },
    displayTotal: {
      type: Number,
      default: 5
    }
  },
  setup(__props) {
    const props = __props;
    const searchQuery = ref("");
    const filterdJobList = computed(() => {
      var _a;
      if (!searchQuery.value)
        return props.jobList.slice(0, props.displayTotal);
      const query = searchQuery.value.toLowerCase();
      return (_a = props.allJobs) == null ? void 0 : _a.filter((item) => {
        for (const key in item) {
          if (Object.prototype.hasOwnProperty.call(item, key)) {
            const value = item[key];
            if (typeof value === "string" && value.toLowerCase().includes(query)) {
              return true;
            }
          }
        }
        return false;
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mt-1 mb-10 w-full" }, _attrs))}>`);
      _push(ssrRenderComponent(FormField, { help: "Search your job" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(FormControl, {
              inputClass: "dark:bg-white dark:text-black",
              modelValue: searchQuery.value,
              "onUpdate:modelValue": ($event) => searchQuery.value = $event,
              id: "name",
              icon: "fas fa-search",
              autocomplete: "name",
              type: "text",
              placeholder: "Search....",
              required: ""
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(FormControl, {
                inputClass: "dark:bg-white dark:text-black",
                modelValue: searchQuery.value,
                "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                id: "name",
                icon: "fas fa-search",
                autocomplete: "name",
                type: "text",
                placeholder: "Search....",
                required: ""
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(filterdJobList.value, (job, index) => {
        _push(`<div class="border rounded mb-2 p-3 shadow-sm shadow-slate-300 py-6 px-3">`);
        _push(ssrRenderComponent(unref(Link), {
          class: "flex items-center justify-between",
          href: _ctx.route("job.show", job.slug)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}><p${_scopeId}><span class="text-xl font-bold"${_scopeId}>${ssrInterpolate(job.title)}</span> | <span class="inline-block bg-blue-950 rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2"${_scopeId}>${ssrInterpolate(job.job_type)}</span> | <span class="inline-block bg-green-800 rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2"${_scopeId}>${ssrInterpolate(job.work_type)}</span> | <span class="inline-block bg-black rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2"${_scopeId}>${ssrInterpolate(job.company.name)}</span></p><p${_scopeId}>${ssrInterpolate(job.description.split(" ").slice(0, 20).join(" "))}</p><!--[-->`);
              ssrRenderList(job.skills.split(","), (skill) => {
                _push2(`<p class="mt-4 inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"${_scopeId}>${ssrInterpolate(skill)}</p>`);
              });
              _push2(`<!--]--></div><div class="text-right"${_scopeId}><span class="inline-block bg-red-700 rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2"${_scopeId}>Deadline: ${ssrInterpolate(job.closing_date)}</span><p class="pr-2"${_scopeId}>$${ssrInterpolate(job.salary)}</p></div>`);
            } else {
              return [
                createVNode("div", null, [
                  createVNode("p", null, [
                    createVNode("span", { class: "text-xl font-bold" }, toDisplayString(job.title), 1),
                    createTextVNode(" | "),
                    createVNode("span", { class: "inline-block bg-blue-950 rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2" }, toDisplayString(job.job_type), 1),
                    createTextVNode(" | "),
                    createVNode("span", { class: "inline-block bg-green-800 rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2" }, toDisplayString(job.work_type), 1),
                    createTextVNode(" | "),
                    createVNode("span", { class: "inline-block bg-black rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2" }, toDisplayString(job.company.name), 1)
                  ]),
                  createVNode("p", null, toDisplayString(job.description.split(" ").slice(0, 20).join(" ")), 1),
                  (openBlock(true), createBlock(Fragment, null, renderList(job.skills.split(","), (skill) => {
                    return openBlock(), createBlock("p", { class: "mt-4 inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2" }, toDisplayString(skill), 1);
                  }), 256))
                ]),
                createVNode("div", { class: "text-right" }, [
                  createVNode("span", { class: "inline-block bg-red-700 rounded-full px-3 py-1 text-sm font-semibold text-white mr-2 mb-2" }, "Deadline: " + toDisplayString(job.closing_date), 1),
                  createVNode("p", { class: "pr-2" }, "$" + toDisplayString(job.salary), 1)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/JobSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
