import { withCtx, unref, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { _ as _sfc_main$2 } from "./SectionFullScreen-CGqGp5K0.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { F as FormCheckRadioGroup } from "./FormCheckRadioGroup-DODJ5NkM.js";
import { F as FormField } from "./FormField-ePZgxXzs.js";
import { F as FormControl } from "./FormControl-DwHkIb1m.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { B as BaseButtons } from "./BaseButtons-6cEMRrBZ.js";
import { F as FormValidationErrors } from "./FormValidationErrors-CmqgJHc6.js";
import { _ as _sfc_main$3 } from "./NotificationBarInCard-Dg146C8Q.js";
import { _ as _sfc_main$4 } from "./BaseLevel-D_z-LHoc.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./colors-K3EOgMMA.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./main-C5vGb8af.js";
import "./BaseIcon-C4zrUKd9.js";
const _sfc_main = {
  __name: "Login",
  __ssrInlineRender: true,
  props: {
    canResetPassword: Boolean,
    status: {
      type: String,
      default: null
    }
  },
  setup(__props) {
    const form = useForm({
      email: "",
      password: "",
      remember: []
    });
    const submit = () => {
      form.transform((data) => ({
        ...data,
        remember: form.remember && form.remember.length ? "on" : ""
      })).post(route("admin.login"), {
        onFinish: () => form.reset("password")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "System Login" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, { bg: "purplePink" }, {
              default: withCtx(({ cardClass }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(CardBox, {
                    class: cardClass,
                    "is-form": "",
                    onSubmit: submit
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(FormValidationErrors, null, null, _parent4, _scopeId3));
                        if (__props.status) {
                          _push4(ssrRenderComponent(_sfc_main$3, { color: "info" }, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`${ssrInterpolate(__props.status)}`);
                              } else {
                                return [
                                  createTextVNode(toDisplayString(__props.status), 1)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`<h3 class="text-center text-4xl font-bold"${_scopeId3}>System User Login</h3>`);
                        _push4(ssrRenderComponent(FormField, {
                          label: "Email",
                          "label-for": "email",
                          help: "Please enter your email"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).email,
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                icon: "fas fa-user",
                                id: "email",
                                autocomplete: "email",
                                type: "email",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).email,
                                  "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                  icon: "fas fa-user",
                                  id: "email",
                                  autocomplete: "email",
                                  type: "email",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormField, {
                          label: "Password",
                          "label-for": "password",
                          help: "Please enter your password"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(FormControl, {
                                modelValue: unref(form).password,
                                "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                icon: "fas fa-key",
                                type: "password",
                                id: "password",
                                autocomplete: "current-password",
                                required: ""
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(FormControl, {
                                  modelValue: unref(form).password,
                                  "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                  icon: "fas fa-key",
                                  type: "password",
                                  id: "password",
                                  autocomplete: "current-password",
                                  required: ""
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(FormCheckRadioGroup, {
                          modelValue: unref(form).remember,
                          "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                          name: "remember",
                          options: { remember: "Remember" }
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_sfc_main$4, null, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(BaseButtons, null, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(BaseButtonLink, {
                                      type: "submit",
                                      color: "info",
                                      label: "Login",
                                      class: { "opacity-25": unref(form).processing },
                                      disabled: unref(form).processing
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(BaseButtonLink, {
                                        type: "submit",
                                        color: "info",
                                        label: "Login",
                                        class: { "opacity-25": unref(form).processing },
                                        disabled: unref(form).processing
                                      }, null, 8, ["class", "disabled"])
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(BaseButtons, null, {
                                  default: withCtx(() => [
                                    createVNode(BaseButtonLink, {
                                      type: "submit",
                                      color: "info",
                                      label: "Login",
                                      class: { "opacity-25": unref(form).processing },
                                      disabled: unref(form).processing
                                    }, null, 8, ["class", "disabled"])
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(FormValidationErrors),
                          __props.status ? (openBlock(), createBlock(_sfc_main$3, {
                            key: 0,
                            color: "info"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(__props.status), 1)
                            ]),
                            _: 1
                          })) : createCommentVNode("", true),
                          createVNode("h3", { class: "text-center text-4xl font-bold" }, "System User Login"),
                          createVNode(FormField, {
                            label: "Email",
                            "label-for": "email",
                            help: "Please enter your email"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).email,
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                icon: "fas fa-user",
                                id: "email",
                                autocomplete: "email",
                                type: "email",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormField, {
                            label: "Password",
                            "label-for": "password",
                            help: "Please enter your password"
                          }, {
                            default: withCtx(() => [
                              createVNode(FormControl, {
                                modelValue: unref(form).password,
                                "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                icon: "fas fa-key",
                                type: "password",
                                id: "password",
                                autocomplete: "current-password",
                                required: ""
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          }),
                          createVNode(FormCheckRadioGroup, {
                            modelValue: unref(form).remember,
                            "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                            name: "remember",
                            options: { remember: "Remember" }
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(BaseDivider),
                          createVNode(_sfc_main$4, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtons, null, {
                                default: withCtx(() => [
                                  createVNode(BaseButtonLink, {
                                    type: "submit",
                                    color: "info",
                                    label: "Login",
                                    class: { "opacity-25": unref(form).processing },
                                    disabled: unref(form).processing
                                  }, null, 8, ["class", "disabled"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(CardBox, {
                      class: cardClass,
                      "is-form": "",
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(FormValidationErrors),
                        __props.status ? (openBlock(), createBlock(_sfc_main$3, {
                          key: 0,
                          color: "info"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(__props.status), 1)
                          ]),
                          _: 1
                        })) : createCommentVNode("", true),
                        createVNode("h3", { class: "text-center text-4xl font-bold" }, "System User Login"),
                        createVNode(FormField, {
                          label: "Email",
                          "label-for": "email",
                          help: "Please enter your email"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).email,
                              "onUpdate:modelValue": ($event) => unref(form).email = $event,
                              icon: "fas fa-user",
                              id: "email",
                              autocomplete: "email",
                              type: "email",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormField, {
                          label: "Password",
                          "label-for": "password",
                          help: "Please enter your password"
                        }, {
                          default: withCtx(() => [
                            createVNode(FormControl, {
                              modelValue: unref(form).password,
                              "onUpdate:modelValue": ($event) => unref(form).password = $event,
                              icon: "fas fa-key",
                              type: "password",
                              id: "password",
                              autocomplete: "current-password",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }),
                        createVNode(FormCheckRadioGroup, {
                          modelValue: unref(form).remember,
                          "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                          name: "remember",
                          options: { remember: "Remember" }
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(BaseDivider),
                        createVNode(_sfc_main$4, null, {
                          default: withCtx(() => [
                            createVNode(BaseButtons, null, {
                              default: withCtx(() => [
                                createVNode(BaseButtonLink, {
                                  type: "submit",
                                  color: "info",
                                  label: "Login",
                                  class: { "opacity-25": unref(form).processing },
                                  disabled: unref(form).processing
                                }, null, 8, ["class", "disabled"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 2
                    }, 1032, ["class"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "System Login" }),
              createVNode(_sfc_main$2, { bg: "purplePink" }, {
                default: withCtx(({ cardClass }) => [
                  createVNode(CardBox, {
                    class: cardClass,
                    "is-form": "",
                    onSubmit: withModifiers(submit, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(FormValidationErrors),
                      __props.status ? (openBlock(), createBlock(_sfc_main$3, {
                        key: 0,
                        color: "info"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(__props.status), 1)
                        ]),
                        _: 1
                      })) : createCommentVNode("", true),
                      createVNode("h3", { class: "text-center text-4xl font-bold" }, "System User Login"),
                      createVNode(FormField, {
                        label: "Email",
                        "label-for": "email",
                        help: "Please enter your email"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            icon: "fas fa-user",
                            id: "email",
                            autocomplete: "email",
                            type: "email",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(FormField, {
                        label: "Password",
                        "label-for": "password",
                        help: "Please enter your password"
                      }, {
                        default: withCtx(() => [
                          createVNode(FormControl, {
                            modelValue: unref(form).password,
                            "onUpdate:modelValue": ($event) => unref(form).password = $event,
                            icon: "fas fa-key",
                            type: "password",
                            id: "password",
                            autocomplete: "current-password",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(FormCheckRadioGroup, {
                        modelValue: unref(form).remember,
                        "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                        name: "remember",
                        options: { remember: "Remember" }
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(BaseDivider),
                      createVNode(_sfc_main$4, null, {
                        default: withCtx(() => [
                          createVNode(BaseButtons, null, {
                            default: withCtx(() => [
                              createVNode(BaseButtonLink, {
                                type: "submit",
                                color: "info",
                                label: "Login",
                                class: { "opacity-25": unref(form).processing },
                                disabled: unref(form).processing
                              }, null, 8, ["class", "disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 2
                  }, 1032, ["class"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/System/Auth/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
