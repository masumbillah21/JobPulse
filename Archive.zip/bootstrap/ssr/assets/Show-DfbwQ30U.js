import { defineComponent, withCtx, unref, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { _ as _sfc_main$1 } from "./LayoutGuest-BQseC_Y5.js";
import { Head, Link } from "@inertiajs/vue3";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    post: Object,
    recentPosts: Object,
    postCategories: Object,
    postTags: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: ((_a = __props.post) == null ? void 0 : _a.title) ?? "Blog"
            }, null, _parent2, _scopeId));
            if (__props.post) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                bgImage: (_b = __props.post) == null ? void 0 : _b.image
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  var _a2, _b2;
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      title: (_a2 = __props.post) == null ? void 0 : _a2.title
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$3, {
                        title: (_b2 = __props.post) == null ? void 0 : _b2.title
                      }, null, 8, ["title"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<section class="relative py-20 bg-gray-200"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="flex flex-row"${_scopeId}><div class="w-full lg:w-9/12 p-4 ml-auto mr-auto text-stone-900 bg-white rounded shadow"${_scopeId}><h2 class="text-4xl mb-2 font-semibold"${_scopeId}>${ssrInterpolate((_c = __props.post) == null ? void 0 : _c.title)}</h2><p class="text-lg mb-2 font-semibold"${_scopeId}>Posted: ${ssrInterpolate((_d = __props.post) == null ? void 0 : _d.created_at)} | By: ${ssrInterpolate((_f = (_e = __props.post) == null ? void 0 : _e.user) == null ? void 0 : _f.name)}</p><hr class="mb-5"${_scopeId}><div class="text-lg text-justify"${_scopeId}>${(_g = __props.post) == null ? void 0 : _g.body}</div><p class="mt-5"${_scopeId}><span class="font-bold"${_scopeId}>Categories:</span> <!--[-->`);
              ssrRenderList((_h = __props.post) == null ? void 0 : _h.categories, (category, index) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: index,
                  href: _ctx.route("blog.category", category.slug),
                  class: "inline-block bg-slate-200 rounded-full px-3 py-1 text-sm font-semibold text-slate-700 mr-2 mb-2"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(category.name)}`);
                    } else {
                      return [
                        createTextVNode(toDisplayString(category.name), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></p><p class="mt-5"${_scopeId}><span class="font-bold"${_scopeId}>Tags:</span> <!--[-->`);
              ssrRenderList((_i = __props.post) == null ? void 0 : _i.tags, (tag, index) => {
                _push2(ssrRenderComponent(unref(Link), {
                  key: index,
                  href: _ctx.route("blog.tag", tag.slug),
                  class: "inline-block bg-slate-200 rounded-full px-3 py-1 text-sm font-semibold text-slate-700 mr-2 mb-2"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(tag.name)}`);
                    } else {
                      return [
                        createTextVNode(toDisplayString(tag.name), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]--></p></div><div class="w-full lg:w-3/12 px-4 ml-5 mr-auto text-stone-900"${_scopeId}><div class="bg-white rounded shadow p-4 mb-4"${_scopeId}><h4 class="text-2xl font-semibold"${_scopeId}> Recent Posts </h4><hr${_scopeId}><ul class="mt-3"${_scopeId}><!--[-->`);
              ssrRenderList(__props.recentPosts, (recentPost, index) => {
                _push2(`<li class="py-1 border-b"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  class: "py-2",
                  href: _ctx.route("blog.show", recentPost.slug)
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(recentPost.title)}`);
                    } else {
                      return [
                        createTextVNode(toDisplayString(recentPost.title), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</li>`);
              });
              _push2(`<!--]--></ul></div><div class="bg-white rounded shadow p-4 mb-3"${_scopeId}><h4 class="text-2xl font-semibold"${_scopeId}> Categories </h4><hr${_scopeId}><ul class="mt-3"${_scopeId}><!--[-->`);
              ssrRenderList(__props.postCategories, (category, index) => {
                _push2(`<li class="py-1 border-b"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  class: "py-2",
                  href: _ctx.route("blog.category", category.slug)
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(category.name)} (${ssrInterpolate(category.blogs_count)}) `);
                    } else {
                      return [
                        createTextVNode(toDisplayString(category.name) + " (" + toDisplayString(category.blogs_count) + ") ", 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</li>`);
              });
              _push2(`<!--]--></ul></div><div class="bg-white rounded shadow p-4"${_scopeId}><h4 class="text-2xl font-semibold"${_scopeId}> Tags </h4><hr${_scopeId}><ul class="mt-3"${_scopeId}><!--[-->`);
              ssrRenderList(__props.postTags, (tag, index) => {
                _push2(`<li class="inline-block p-2"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  class: "py-2",
                  href: _ctx.route("blog.tag", tag.slug)
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<span class="inline-block bg-slate-200 rounded-full px-3 py-1 text-sm font-semibold text-slate-700"${_scopeId2}>${ssrInterpolate(tag.name)}</span>`);
                    } else {
                      return [
                        createVNode("span", { class: "inline-block bg-slate-200 rounded-full px-3 py-1 text-sm font-semibold text-slate-700" }, toDisplayString(tag.name), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</li>`);
              });
              _push2(`<!--]--></ul></div></div></div></div></section></main>`);
            } else {
              _push2(`<main class="mt-40"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="items-center justify-center flex flex-wrap"${_scopeId}><div class="w-full ml-auto mr-auto px-4"${_scopeId}><h3 class="text-4xl font-semibold"${_scopeId}>Not Found</h3></div></div></div></main>`);
            }
          } else {
            return [
              createVNode(unref(Head), {
                title: ((_j = __props.post) == null ? void 0 : _j.title) ?? "Blog"
              }, null, 8, ["title"]),
              __props.post ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(_sfc_main$2, {
                  bgImage: (_k = __props.post) == null ? void 0 : _k.image
                }, {
                  default: withCtx(() => {
                    var _a2;
                    return [
                      createVNode(_sfc_main$3, {
                        title: (_a2 = __props.post) == null ? void 0 : _a2.title
                      }, null, 8, ["title"])
                    ];
                  }),
                  _: 1
                }, 8, ["bgImage"]),
                createVNode("section", { class: "relative py-20 bg-gray-200" }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "flex flex-row" }, [
                      createVNode("div", { class: "w-full lg:w-9/12 p-4 ml-auto mr-auto text-stone-900 bg-white rounded shadow" }, [
                        createVNode("h2", { class: "text-4xl mb-2 font-semibold" }, toDisplayString((_l = __props.post) == null ? void 0 : _l.title), 1),
                        createVNode("p", { class: "text-lg mb-2 font-semibold" }, "Posted: " + toDisplayString((_m = __props.post) == null ? void 0 : _m.created_at) + " | By: " + toDisplayString((_o = (_n = __props.post) == null ? void 0 : _n.user) == null ? void 0 : _o.name), 1),
                        createVNode("hr", { class: "mb-5" }),
                        createVNode("div", {
                          class: "text-lg text-justify",
                          innerHTML: (_p = __props.post) == null ? void 0 : _p.body
                        }, null, 8, ["innerHTML"]),
                        createVNode("p", { class: "mt-5" }, [
                          createVNode("span", { class: "font-bold" }, "Categories:"),
                          createTextVNode(),
                          (openBlock(true), createBlock(Fragment, null, renderList((_q = __props.post) == null ? void 0 : _q.categories, (category, index) => {
                            return openBlock(), createBlock(unref(Link), {
                              key: index,
                              href: _ctx.route("blog.category", category.slug),
                              class: "inline-block bg-slate-200 rounded-full px-3 py-1 text-sm font-semibold text-slate-700 mr-2 mb-2"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(category.name), 1)
                              ]),
                              _: 2
                            }, 1032, ["href"]);
                          }), 128))
                        ]),
                        createVNode("p", { class: "mt-5" }, [
                          createVNode("span", { class: "font-bold" }, "Tags:"),
                          createTextVNode(),
                          (openBlock(true), createBlock(Fragment, null, renderList((_r = __props.post) == null ? void 0 : _r.tags, (tag, index) => {
                            return openBlock(), createBlock(unref(Link), {
                              key: index,
                              href: _ctx.route("blog.tag", tag.slug),
                              class: "inline-block bg-slate-200 rounded-full px-3 py-1 text-sm font-semibold text-slate-700 mr-2 mb-2"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(tag.name), 1)
                              ]),
                              _: 2
                            }, 1032, ["href"]);
                          }), 128))
                        ])
                      ]),
                      createVNode("div", { class: "w-full lg:w-3/12 px-4 ml-5 mr-auto text-stone-900" }, [
                        createVNode("div", { class: "bg-white rounded shadow p-4 mb-4" }, [
                          createVNode("h4", { class: "text-2xl font-semibold" }, " Recent Posts "),
                          createVNode("hr"),
                          createVNode("ul", { class: "mt-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.recentPosts, (recentPost, index) => {
                              return openBlock(), createBlock("li", {
                                key: index,
                                class: "py-1 border-b"
                              }, [
                                createVNode(unref(Link), {
                                  class: "py-2",
                                  href: _ctx.route("blog.show", recentPost.slug)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(recentPost.title), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]);
                            }), 128))
                          ])
                        ]),
                        createVNode("div", { class: "bg-white rounded shadow p-4 mb-3" }, [
                          createVNode("h4", { class: "text-2xl font-semibold" }, " Categories "),
                          createVNode("hr"),
                          createVNode("ul", { class: "mt-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.postCategories, (category, index) => {
                              return openBlock(), createBlock("li", {
                                key: index,
                                class: "py-1 border-b"
                              }, [
                                createVNode(unref(Link), {
                                  class: "py-2",
                                  href: _ctx.route("blog.category", category.slug)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(category.name) + " (" + toDisplayString(category.blogs_count) + ") ", 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]);
                            }), 128))
                          ])
                        ]),
                        createVNode("div", { class: "bg-white rounded shadow p-4" }, [
                          createVNode("h4", { class: "text-2xl font-semibold" }, " Tags "),
                          createVNode("hr"),
                          createVNode("ul", { class: "mt-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.postTags, (tag, index) => {
                              return openBlock(), createBlock("li", {
                                key: index,
                                class: "inline-block p-2"
                              }, [
                                createVNode(unref(Link), {
                                  class: "py-2",
                                  href: _ctx.route("blog.tag", tag.slug)
                                }, {
                                  default: withCtx(() => [
                                    createVNode("span", { class: "inline-block bg-slate-200 rounded-full px-3 py-1 text-sm font-semibold text-slate-700" }, toDisplayString(tag.name), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]);
                            }), 128))
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])) : (openBlock(), createBlock("main", {
                key: 1,
                class: "mt-40"
              }, [
                createVNode("div", { class: "container mx-auto px-4" }, [
                  createVNode("div", { class: "items-center justify-center flex flex-wrap" }, [
                    createVNode("div", { class: "w-full ml-auto mr-auto px-4" }, [
                      createVNode("h3", { class: "text-4xl font-semibold" }, "Not Found")
                    ])
                  ])
                ])
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Blog/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
