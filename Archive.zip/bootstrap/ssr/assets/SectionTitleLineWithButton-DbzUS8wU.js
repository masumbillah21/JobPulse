import { computed, useSlots, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderSlot } from "vue/server-renderer";
import { _ as _sfc_main$2 } from "./BaseIcon-C4zrUKd9.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { _ as _sfc_main$1 } from "./IconRounded-RF1xkXym.js";
const _sfc_main = {
  __name: "SectionTitleLineWithButton",
  __ssrInlineRender: true,
  props: {
    icon: {
      type: String,
      default: null
    },
    title: {
      type: String,
      required: true
    },
    main: Boolean
  },
  setup(__props) {
    const hasSlot = computed(() => useSlots().default);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: [{ "pt-6": !__props.main }, "mb-6 flex items-center justify-between"]
      }, _attrs))}><div class="flex items-center justify-start">`);
      if (__props.icon && __props.main) {
        _push(ssrRenderComponent(_sfc_main$1, {
          icon: __props.icon,
          color: "light",
          class: "mr-3",
          bg: ""
        }, null, _parent));
      } else if (__props.icon) {
        _push(ssrRenderComponent(_sfc_main$2, {
          path: __props.icon,
          class: "mr-2",
          size: "20"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<h1 class="${ssrRenderClass([__props.main ? "text-3xl" : "text-2xl", "leading-tight"])}">${ssrInterpolate(__props.title)}</h1></div>`);
      if (hasSlot.value) {
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      } else {
        _push(ssrRenderComponent(BaseButtonLink, {
          icon: "fas fa-cog",
          color: "whiteDark"
        }, null, _parent));
      }
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/SectionTitleLineWithButton.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const SectionTitleLineWithButton = _sfc_main;
export {
  SectionTitleLineWithButton as S
};
