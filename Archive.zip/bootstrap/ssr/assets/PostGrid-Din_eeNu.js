import { defineComponent, unref, mergeProps, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { Link } from "@inertiajs/vue3";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PostGrid",
  __ssrInlineRender: true,
  props: {
    post: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(ssrRenderComponent(unref(Link), mergeProps({
        href: _ctx.route("blog.show", (_a = __props.post) == null ? void 0 : _a.slug),
        class: "bg-white shadow rounded mb-3"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b, _c, _d, _e, _f, _g, _h;
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", (_a2 = __props.post) == null ? void 0 : _a2.image)} class="rounded h-60 w-full"${ssrRenderAttr("alt", (_b = __props.post) == null ? void 0 : _b.title)}${_scopeId}><div class="p-4 text-slate-900"${_scopeId}><h1 class="font-semibold text-xl"${_scopeId}>${(_c = __props.post) == null ? void 0 : _c.title.substring(0, 40)}</h1><div class="text-sm text-ellipsis text-left mt-2"${_scopeId}>${((_d = __props.post) == null ? void 0 : _d.body.substring(0, 160)) + ".."}</div><p class="text-right mt-2 text-slate-800 font-semibold"${_scopeId}> Read More <i class="fas fa-angle-double-right"${_scopeId}></i></p></div>`);
          } else {
            return [
              createVNode("img", {
                src: (_e = __props.post) == null ? void 0 : _e.image,
                class: "rounded h-60 w-full",
                alt: (_f = __props.post) == null ? void 0 : _f.title
              }, null, 8, ["src", "alt"]),
              createVNode("div", { class: "p-4 text-slate-900" }, [
                createVNode("h1", {
                  innerHTML: (_g = __props.post) == null ? void 0 : _g.title.substring(0, 40),
                  class: "font-semibold text-xl"
                }, null, 8, ["innerHTML"]),
                createVNode("div", {
                  innerHTML: ((_h = __props.post) == null ? void 0 : _h.body.substring(0, 160)) + "..",
                  class: "text-sm text-ellipsis text-left mt-2"
                }, null, 8, ["innerHTML"]),
                createVNode("p", { class: "text-right mt-2 text-slate-800 font-semibold" }, [
                  createTextVNode(" Read More "),
                  createVNode("i", { class: "fas fa-angle-double-right" })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/PostGrid.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
