import { defineComponent, withCtx, unref, createVNode, toDisplayString, createTextVNode, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { usePage, Head } from "@inertiajs/vue3";
import { L as LayoutAuthenticated, S as SectionMain } from "./LayoutAuthenticated-DwQaEU0a.js";
import { S as SectionTitleLineWithButton } from "./SectionTitleLineWithButton-DbzUS8wU.js";
import { B as BaseButtonLink } from "./BaseButtonLink-BG-sFKCn.js";
import { C as CardBox } from "./CardBox-BXS3nXKj.js";
import { B as BaseDivider } from "./BaseDivider-uk-eaHSj.js";
import { c as capitalize } from "./capitalize-BVVELPrI.js";
import "./darkMode-Dj6n3w0i.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
import "./colors-K3EOgMMA.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./BaseLevel-D_z-LHoc.js";
import "./isSystemUser-D-zJOoLX.js";
import "./IconRounded-RF1xkXym.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  setup(__props) {
    const resumeData = usePage().props.resumeData;
    const authUser = usePage().props.auth.user;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(LayoutAuthenticated, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(authUser).name
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(SectionMain, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: "Resume",
                    main: ""
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div${_scopeId3}>`);
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          class: "mr-1",
                          icon: "fas fa-edit",
                          label: "Edit",
                          color: "info",
                          routeName: "resume.index",
                          "rounded-full": "",
                          small: ""
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "resume.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", null, [
                            createVNode(BaseButtonLink, {
                              class: "mr-1",
                              icon: "fas fa-edit",
                              label: "Edit",
                              color: "info",
                              routeName: "resume.index",
                              "rounded-full": "",
                              small: ""
                            }),
                            createVNode(BaseButtonLink, {
                              icon: "far fa-arrow-alt-circle-left",
                              label: "Back",
                              routeName: "resume.index",
                              color: "contrast",
                              "rounded-full": "",
                              small: ""
                            })
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="flex"${_scopeId2}>`);
                  _push3(ssrRenderComponent(CardBox, { class: "w-1/3 mr-2 flex flex-col items-center" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="flex flex-col items-center justify-center"${_scopeId3}><img class="rounded-full"${ssrRenderAttr("src", unref(resumeData).resume.image)} alt=""${_scopeId3}><p class="text-xl font-bold"${_scopeId3}>${ssrInterpolate(unref(authUser).name)}</p><p class="text-sm"${_scopeId3}>${ssrInterpolate(unref(authUser).email)}</p><p class="text-sm"${_scopeId3}>+88 ${ssrInterpolate(unref(resumeData).resume.phone)}</p><p class="text-sm"${_scopeId3}>${ssrInterpolate(unref(resumeData).resume.address)}</p></div>`);
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        _push4(`<p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>Father Name:</span> ${ssrInterpolate(unref(resumeData).resume.father_name)}</p><p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>Mother Name:</span> ${ssrInterpolate(unref(resumeData).resume.mother_name)}</p><p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>DOB:</span> ${ssrInterpolate(unref(resumeData).resume.dob)}</p><p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>Marital Status:</span> ${ssrInterpolate(unref(resumeData).resume.marital_status)}</p><p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>Religion:</span> ${ssrInterpolate(unref(resumeData).resume.religion)}</p><p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>Present Address:</span> ${ssrInterpolate(unref(resumeData).resume.present_address)}</p><p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>Permanent Address:</span> ${ssrInterpolate(unref(resumeData).resume.permanent_address)}</p><p class="mb-1"${_scopeId3}><span class="font-semibold"${_scopeId3}>Nationality:</span> ${ssrInterpolate(unref(resumeData).resume.nationality)}</p>`);
                      } else {
                        return [
                          createVNode("div", { class: "flex flex-col items-center justify-center" }, [
                            createVNode("img", {
                              class: "rounded-full",
                              src: unref(resumeData).resume.image,
                              alt: ""
                            }, null, 8, ["src"]),
                            createVNode("p", { class: "text-xl font-bold" }, toDisplayString(unref(authUser).name), 1),
                            createVNode("p", { class: "text-sm" }, toDisplayString(unref(authUser).email), 1),
                            createVNode("p", { class: "text-sm" }, "+88 " + toDisplayString(unref(resumeData).resume.phone), 1),
                            createVNode("p", { class: "text-sm" }, toDisplayString(unref(resumeData).resume.address), 1)
                          ]),
                          createVNode(BaseDivider),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Father Name:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.father_name), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Mother Name:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.mother_name), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "DOB:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.dob), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Marital Status:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.marital_status), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Religion:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.religion), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Present Address:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.present_address), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Permanent Address:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.permanent_address), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Nationality:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.nationality), 1)
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(CardBox, { class: "w-2/3" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<p class="text-3xl font-bold mb-1"${_scopeId3}>Educations</p>`);
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        if (unref(resumeData).education) {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(resumeData).education, (education) => {
                            _push4(`<div${_scopeId3}><div class="flex flex-row justify-between mb-1"${_scopeId3}><p class="text-xl font-semibold"${_scopeId3}>${ssrInterpolate(education.degree)}</p><div class="text-right"${_scopeId3}><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Institution:</span> ${ssrInterpolate(education.institute)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Board/University: </span> ${ssrInterpolate(education.board_university)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Passing year: </span> ${ssrInterpolate(education.passing_year)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>${ssrInterpolate(unref(capitalize)(education.result_type))}:</span> ${ssrInterpolate(education.result)}</p></div></div>`);
                            _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`<p class="text-3xl font-semibold"${_scopeId3}>Trainings</p>`);
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        if (unref(resumeData).training) {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(resumeData).training, (training) => {
                            _push4(`<div${_scopeId3}><div class="flex flex-row justify-between mb-1"${_scopeId3}><div${_scopeId3}><p class="text-xl font-semibold"${_scopeId3}>${ssrInterpolate(training.title)}</p><p${_scopeId3}>${ssrInterpolate(training.description)}</p></div><div class="text-right"${_scopeId3}><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Organization:</span>${ssrInterpolate(training.organization)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Location:</span>${ssrInterpolate(training.location)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Start Date:</span>${ssrInterpolate(training.start_date)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>End Date:</span>${ssrInterpolate(training.end_date)}</p></div></div>`);
                            _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`<p class="text-3xl font-semibold"${_scopeId3}>Experiences</p>`);
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        if (unref(resumeData).experience) {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(resumeData).experience, (experience) => {
                            _push4(`<div${_scopeId3}><div class="flex flex-row justify-between mb-1"${_scopeId3}><div${_scopeId3}><p class="text-xl font-semibold"${_scopeId3}>${ssrInterpolate(experience.title)}</p><p${_scopeId3}>${ssrInterpolate(experience.description)}</p></div><div class="text-right"${_scopeId3}><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Company:</span>${ssrInterpolate(experience.company)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Location:</span>${ssrInterpolate(experience.location)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Start Date:</span>${ssrInterpolate(experience.start_date)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>End Date:</span>${ssrInterpolate(experience.end_date)}</p></div></div>`);
                            _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`<p class="text-3xl font-semibold"${_scopeId3}>References</p>`);
                        _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                        if (unref(resumeData).reference) {
                          _push4(`<!--[-->`);
                          ssrRenderList(unref(resumeData).reference, (reference) => {
                            _push4(`<div${_scopeId3}><div class="flex flex-row justify-between mb-1"${_scopeId3}><div${_scopeId3}><p class="text-xl font-semibold"${_scopeId3}>${ssrInterpolate(reference.name)}</p><p${_scopeId3}>${ssrInterpolate(reference.organization)}</p></div><div class="text-right"${_scopeId3}><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Phone:</span>${ssrInterpolate(reference.phone)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Email:</span>${ssrInterpolate(reference.email)}</p><p${_scopeId3}><span class="font-semibold"${_scopeId3}>Relationship:</span>${ssrInterpolate(reference.relationship)}</p></div></div>`);
                            _push4(ssrRenderComponent(BaseDivider, null, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          });
                          _push4(`<!--]-->`);
                        } else {
                          _push4(`<!---->`);
                        }
                      } else {
                        return [
                          createVNode("p", { class: "text-3xl font-bold mb-1" }, "Educations"),
                          createVNode(BaseDivider),
                          unref(resumeData).education ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(resumeData).education, (education) => {
                            return openBlock(), createBlock("div", {
                              key: education.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(education.degree), 1),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Institution:"),
                                    createTextVNode(" " + toDisplayString(education.institute), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Board/University: "),
                                    createTextVNode(" " + toDisplayString(education.board_university), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Passing year: "),
                                    createTextVNode(" " + toDisplayString(education.passing_year), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, toDisplayString(unref(capitalize)(education.result_type)) + ":", 1),
                                    createTextVNode(" " + toDisplayString(education.result), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          createVNode("p", { class: "text-3xl font-semibold" }, "Trainings"),
                          createVNode(BaseDivider),
                          unref(resumeData).training ? (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(resumeData).training, (training) => {
                            return openBlock(), createBlock("div", {
                              key: training.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("div", null, [
                                  createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(training.title), 1),
                                  createVNode("p", null, toDisplayString(training.description), 1)
                                ]),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Organization:"),
                                    createTextVNode(toDisplayString(training.organization), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Location:"),
                                    createTextVNode(toDisplayString(training.location), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Start Date:"),
                                    createTextVNode(toDisplayString(training.start_date), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "End Date:"),
                                    createTextVNode(toDisplayString(training.end_date), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          createVNode("p", { class: "text-3xl font-semibold" }, "Experiences"),
                          createVNode(BaseDivider),
                          unref(resumeData).experience ? (openBlock(true), createBlock(Fragment, { key: 2 }, renderList(unref(resumeData).experience, (experience) => {
                            return openBlock(), createBlock("div", {
                              key: experience.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("div", null, [
                                  createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(experience.title), 1),
                                  createVNode("p", null, toDisplayString(experience.description), 1)
                                ]),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Company:"),
                                    createTextVNode(toDisplayString(experience.company), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Location:"),
                                    createTextVNode(toDisplayString(experience.location), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Start Date:"),
                                    createTextVNode(toDisplayString(experience.start_date), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "End Date:"),
                                    createTextVNode(toDisplayString(experience.end_date), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          createVNode("p", { class: "text-3xl font-semibold" }, "References"),
                          createVNode(BaseDivider),
                          unref(resumeData).reference ? (openBlock(true), createBlock(Fragment, { key: 3 }, renderList(unref(resumeData).reference, (reference) => {
                            return openBlock(), createBlock("div", {
                              key: reference.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("div", null, [
                                  createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(reference.name), 1),
                                  createVNode("p", null, toDisplayString(reference.organization), 1)
                                ]),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Phone:"),
                                    createTextVNode(toDisplayString(reference.phone), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Email:"),
                                    createTextVNode(toDisplayString(reference.email), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Relationship:"),
                                    createTextVNode(toDisplayString(reference.relationship), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode(SectionTitleLineWithButton, {
                      icon: "far fa-arrow-alt-circle-right",
                      title: "Resume",
                      main: ""
                    }, {
                      default: withCtx(() => [
                        createVNode("div", null, [
                          createVNode(BaseButtonLink, {
                            class: "mr-1",
                            icon: "fas fa-edit",
                            label: "Edit",
                            color: "info",
                            routeName: "resume.index",
                            "rounded-full": "",
                            small: ""
                          }),
                          createVNode(BaseButtonLink, {
                            icon: "far fa-arrow-alt-circle-left",
                            label: "Back",
                            routeName: "resume.index",
                            color: "contrast",
                            "rounded-full": "",
                            small: ""
                          })
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "flex" }, [
                      createVNode(CardBox, { class: "w-1/3 mr-2 flex flex-col items-center" }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "flex flex-col items-center justify-center" }, [
                            createVNode("img", {
                              class: "rounded-full",
                              src: unref(resumeData).resume.image,
                              alt: ""
                            }, null, 8, ["src"]),
                            createVNode("p", { class: "text-xl font-bold" }, toDisplayString(unref(authUser).name), 1),
                            createVNode("p", { class: "text-sm" }, toDisplayString(unref(authUser).email), 1),
                            createVNode("p", { class: "text-sm" }, "+88 " + toDisplayString(unref(resumeData).resume.phone), 1),
                            createVNode("p", { class: "text-sm" }, toDisplayString(unref(resumeData).resume.address), 1)
                          ]),
                          createVNode(BaseDivider),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Father Name:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.father_name), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Mother Name:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.mother_name), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "DOB:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.dob), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Marital Status:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.marital_status), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Religion:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.religion), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Present Address:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.present_address), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Permanent Address:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.permanent_address), 1)
                          ]),
                          createVNode("p", { class: "mb-1" }, [
                            createVNode("span", { class: "font-semibold" }, "Nationality:"),
                            createTextVNode(" " + toDisplayString(unref(resumeData).resume.nationality), 1)
                          ])
                        ]),
                        _: 1
                      }),
                      createVNode(CardBox, { class: "w-2/3" }, {
                        default: withCtx(() => [
                          createVNode("p", { class: "text-3xl font-bold mb-1" }, "Educations"),
                          createVNode(BaseDivider),
                          unref(resumeData).education ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(resumeData).education, (education) => {
                            return openBlock(), createBlock("div", {
                              key: education.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(education.degree), 1),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Institution:"),
                                    createTextVNode(" " + toDisplayString(education.institute), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Board/University: "),
                                    createTextVNode(" " + toDisplayString(education.board_university), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Passing year: "),
                                    createTextVNode(" " + toDisplayString(education.passing_year), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, toDisplayString(unref(capitalize)(education.result_type)) + ":", 1),
                                    createTextVNode(" " + toDisplayString(education.result), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          createVNode("p", { class: "text-3xl font-semibold" }, "Trainings"),
                          createVNode(BaseDivider),
                          unref(resumeData).training ? (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(resumeData).training, (training) => {
                            return openBlock(), createBlock("div", {
                              key: training.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("div", null, [
                                  createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(training.title), 1),
                                  createVNode("p", null, toDisplayString(training.description), 1)
                                ]),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Organization:"),
                                    createTextVNode(toDisplayString(training.organization), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Location:"),
                                    createTextVNode(toDisplayString(training.location), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Start Date:"),
                                    createTextVNode(toDisplayString(training.start_date), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "End Date:"),
                                    createTextVNode(toDisplayString(training.end_date), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          createVNode("p", { class: "text-3xl font-semibold" }, "Experiences"),
                          createVNode(BaseDivider),
                          unref(resumeData).experience ? (openBlock(true), createBlock(Fragment, { key: 2 }, renderList(unref(resumeData).experience, (experience) => {
                            return openBlock(), createBlock("div", {
                              key: experience.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("div", null, [
                                  createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(experience.title), 1),
                                  createVNode("p", null, toDisplayString(experience.description), 1)
                                ]),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Company:"),
                                    createTextVNode(toDisplayString(experience.company), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Location:"),
                                    createTextVNode(toDisplayString(experience.location), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Start Date:"),
                                    createTextVNode(toDisplayString(experience.start_date), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "End Date:"),
                                    createTextVNode(toDisplayString(experience.end_date), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          createVNode("p", { class: "text-3xl font-semibold" }, "References"),
                          createVNode(BaseDivider),
                          unref(resumeData).reference ? (openBlock(true), createBlock(Fragment, { key: 3 }, renderList(unref(resumeData).reference, (reference) => {
                            return openBlock(), createBlock("div", {
                              key: reference.id
                            }, [
                              createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                                createVNode("div", null, [
                                  createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(reference.name), 1),
                                  createVNode("p", null, toDisplayString(reference.organization), 1)
                                ]),
                                createVNode("div", { class: "text-right" }, [
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Phone:"),
                                    createTextVNode(toDisplayString(reference.phone), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Email:"),
                                    createTextVNode(toDisplayString(reference.email), 1)
                                  ]),
                                  createVNode("p", null, [
                                    createVNode("span", { class: "font-semibold" }, "Relationship:"),
                                    createTextVNode(toDisplayString(reference.relationship), 1)
                                  ])
                                ])
                              ]),
                              createVNode(BaseDivider)
                            ]);
                          }), 128)) : createCommentVNode("", true)
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(authUser).name
              }, null, 8, ["title"]),
              createVNode(SectionMain, null, {
                default: withCtx(() => [
                  createVNode(SectionTitleLineWithButton, {
                    icon: "far fa-arrow-alt-circle-right",
                    title: "Resume",
                    main: ""
                  }, {
                    default: withCtx(() => [
                      createVNode("div", null, [
                        createVNode(BaseButtonLink, {
                          class: "mr-1",
                          icon: "fas fa-edit",
                          label: "Edit",
                          color: "info",
                          routeName: "resume.index",
                          "rounded-full": "",
                          small: ""
                        }),
                        createVNode(BaseButtonLink, {
                          icon: "far fa-arrow-alt-circle-left",
                          label: "Back",
                          routeName: "resume.index",
                          color: "contrast",
                          "rounded-full": "",
                          small: ""
                        })
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "flex" }, [
                    createVNode(CardBox, { class: "w-1/3 mr-2 flex flex-col items-center" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "flex flex-col items-center justify-center" }, [
                          createVNode("img", {
                            class: "rounded-full",
                            src: unref(resumeData).resume.image,
                            alt: ""
                          }, null, 8, ["src"]),
                          createVNode("p", { class: "text-xl font-bold" }, toDisplayString(unref(authUser).name), 1),
                          createVNode("p", { class: "text-sm" }, toDisplayString(unref(authUser).email), 1),
                          createVNode("p", { class: "text-sm" }, "+88 " + toDisplayString(unref(resumeData).resume.phone), 1),
                          createVNode("p", { class: "text-sm" }, toDisplayString(unref(resumeData).resume.address), 1)
                        ]),
                        createVNode(BaseDivider),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "Father Name:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.father_name), 1)
                        ]),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "Mother Name:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.mother_name), 1)
                        ]),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "DOB:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.dob), 1)
                        ]),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "Marital Status:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.marital_status), 1)
                        ]),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "Religion:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.religion), 1)
                        ]),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "Present Address:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.present_address), 1)
                        ]),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "Permanent Address:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.permanent_address), 1)
                        ]),
                        createVNode("p", { class: "mb-1" }, [
                          createVNode("span", { class: "font-semibold" }, "Nationality:"),
                          createTextVNode(" " + toDisplayString(unref(resumeData).resume.nationality), 1)
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(CardBox, { class: "w-2/3" }, {
                      default: withCtx(() => [
                        createVNode("p", { class: "text-3xl font-bold mb-1" }, "Educations"),
                        createVNode(BaseDivider),
                        unref(resumeData).education ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(resumeData).education, (education) => {
                          return openBlock(), createBlock("div", {
                            key: education.id
                          }, [
                            createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                              createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(education.degree), 1),
                              createVNode("div", { class: "text-right" }, [
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Institution:"),
                                  createTextVNode(" " + toDisplayString(education.institute), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Board/University: "),
                                  createTextVNode(" " + toDisplayString(education.board_university), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Passing year: "),
                                  createTextVNode(" " + toDisplayString(education.passing_year), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, toDisplayString(unref(capitalize)(education.result_type)) + ":", 1),
                                  createTextVNode(" " + toDisplayString(education.result), 1)
                                ])
                              ])
                            ]),
                            createVNode(BaseDivider)
                          ]);
                        }), 128)) : createCommentVNode("", true),
                        createVNode("p", { class: "text-3xl font-semibold" }, "Trainings"),
                        createVNode(BaseDivider),
                        unref(resumeData).training ? (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(unref(resumeData).training, (training) => {
                          return openBlock(), createBlock("div", {
                            key: training.id
                          }, [
                            createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                              createVNode("div", null, [
                                createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(training.title), 1),
                                createVNode("p", null, toDisplayString(training.description), 1)
                              ]),
                              createVNode("div", { class: "text-right" }, [
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Organization:"),
                                  createTextVNode(toDisplayString(training.organization), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Location:"),
                                  createTextVNode(toDisplayString(training.location), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Start Date:"),
                                  createTextVNode(toDisplayString(training.start_date), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "End Date:"),
                                  createTextVNode(toDisplayString(training.end_date), 1)
                                ])
                              ])
                            ]),
                            createVNode(BaseDivider)
                          ]);
                        }), 128)) : createCommentVNode("", true),
                        createVNode("p", { class: "text-3xl font-semibold" }, "Experiences"),
                        createVNode(BaseDivider),
                        unref(resumeData).experience ? (openBlock(true), createBlock(Fragment, { key: 2 }, renderList(unref(resumeData).experience, (experience) => {
                          return openBlock(), createBlock("div", {
                            key: experience.id
                          }, [
                            createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                              createVNode("div", null, [
                                createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(experience.title), 1),
                                createVNode("p", null, toDisplayString(experience.description), 1)
                              ]),
                              createVNode("div", { class: "text-right" }, [
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Company:"),
                                  createTextVNode(toDisplayString(experience.company), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Location:"),
                                  createTextVNode(toDisplayString(experience.location), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Start Date:"),
                                  createTextVNode(toDisplayString(experience.start_date), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "End Date:"),
                                  createTextVNode(toDisplayString(experience.end_date), 1)
                                ])
                              ])
                            ]),
                            createVNode(BaseDivider)
                          ]);
                        }), 128)) : createCommentVNode("", true),
                        createVNode("p", { class: "text-3xl font-semibold" }, "References"),
                        createVNode(BaseDivider),
                        unref(resumeData).reference ? (openBlock(true), createBlock(Fragment, { key: 3 }, renderList(unref(resumeData).reference, (reference) => {
                          return openBlock(), createBlock("div", {
                            key: reference.id
                          }, [
                            createVNode("div", { class: "flex flex-row justify-between mb-1" }, [
                              createVNode("div", null, [
                                createVNode("p", { class: "text-xl font-semibold" }, toDisplayString(reference.name), 1),
                                createVNode("p", null, toDisplayString(reference.organization), 1)
                              ]),
                              createVNode("div", { class: "text-right" }, [
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Phone:"),
                                  createTextVNode(toDisplayString(reference.phone), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Email:"),
                                  createTextVNode(toDisplayString(reference.email), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("span", { class: "font-semibold" }, "Relationship:"),
                                  createTextVNode(toDisplayString(reference.relationship), 1)
                                ])
                              ])
                            ]),
                            createVNode(BaseDivider)
                          ]);
                        }), 128)) : createCommentVNode("", true)
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Resume/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
