import { defineComponent, mergeProps, useSSRContext, resolveComponent, withCtx, unref, createVNode, openBlock, createBlock, createTextVNode, toDisplayString } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrRenderStyle, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$2 } from "./LayoutGuest-BQseC_Y5.js";
import { Head } from "@inertiajs/vue3";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Shape",
  __ssrInlineRender: true,
  props: {
    polygonClass: {
      type: String,
      default: "text-gray-100"
    },
    sectionClass: {
      type: String,
      default: "bottom-auto top-0 "
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: [__props.sectionClass, "left-0 right-0 w-full absolute pointer-events-none overflow-hidden -mt-20"],
        style: { "height": "80px" }
      }, _attrs))}><svg class="absolute bottom-0 overflow-hidden" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" version="1.1" viewBox="0 0 2560 100" x="0" y="0"><polygon class="${ssrRenderClass([__props.polygonClass, "fill-current"])}" points="2560 0 2560 100 0 100"></polygon></svg></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/Shape.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    blogData: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_prev = resolveComponent("prev");
      _push(ssrRenderComponent(_sfc_main$2, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Blog" }, null, _parent2, _scopeId));
            if (__props.blogData) {
              _push2(`<main${_scopeId}><div class="relative pt-16 pb-32 flex content-center items-center justify-center" style="${ssrRenderStyle({ "min-height": "45vh" })}"${_scopeId}><div class="absolute top-0 w-full h-full bg-center bg-cover" style="${ssrRenderStyle("background-image: url(" + ((_a = __props.blogData) == null ? void 0 : _a.image) + ");")}"${_scopeId}>&quot; <span id="blackOverlay" class="w-full h-full absolute opacity-75 bg-black"${_scopeId}></span></div><div class="container relative mx-auto"${_scopeId}><div class="items-center flex flex-wrap"${_scopeId}><div class="w-full lg:w-6/12 px-4 ml-auto mr-auto text-center"${_scopeId}><div class="pr-12"${_scopeId}><h1 class="text-white font-semibold text-5xl"${_scopeId}>${ssrInterpolate((_b = __props.blogData) == null ? void 0 : _b.title)}</h1></div></div></div></div>`);
              _push2(ssrRenderComponent(_sfc_main$1, { sectionClass: "top-auto bottom-0" }, null, _parent2, _scopeId));
              _push2(`</div><section class="relative py-20 bg-white"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$1, { polygonClass: "text-white" }, null, _parent2, _scopeId));
              _push2(`<div class="container mx-auto px-4"${_scopeId}><div class="flex flex-row"${_scopeId}><div class="w-full lg:w-9/12 px-4 ml-auto mr-auto text-stone-900"${_scopeId}><h2 class="text-4xl mb-2 font-semibold"${_scopeId}>${ssrInterpolate((_c = __props.blogData) == null ? void 0 : _c.title)}</h2><p class="text-lg mb-2 font-semibold"${_scopeId}>Date: ${ssrInterpolate((_d = __props.blogData) == null ? void 0 : _d.created_at)}</p><hr class="mb-5"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_prev, { class: "text-lg text-justify" }, null, _parent2, _scopeId));
              _push2(`</div></div></div></section></main>`);
            } else {
              _push2(`<main class="mt-40"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="items-center justify-center flex flex-wrap"${_scopeId}><div class="w-full ml-auto mr-auto px-4"${_scopeId}><h3 class="text-4xl font-semibold"${_scopeId}>Not Found</h3></div></div></div></main>`);
            }
          } else {
            return [
              createVNode(unref(Head), { title: "Blog" }),
              __props.blogData ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode("div", {
                  class: "relative pt-16 pb-32 flex content-center items-center justify-center",
                  style: { "min-height": "45vh" }
                }, [
                  createVNode("div", {
                    class: "absolute top-0 w-full h-full bg-center bg-cover",
                    style: "background-image: url(" + ((_e = __props.blogData) == null ? void 0 : _e.image) + ");"
                  }, [
                    createTextVNode('" '),
                    createVNode("span", {
                      id: "blackOverlay",
                      class: "w-full h-full absolute opacity-75 bg-black"
                    })
                  ], 4),
                  createVNode("div", { class: "container relative mx-auto" }, [
                    createVNode("div", { class: "items-center flex flex-wrap" }, [
                      createVNode("div", { class: "w-full lg:w-6/12 px-4 ml-auto mr-auto text-center" }, [
                        createVNode("div", { class: "pr-12" }, [
                          createVNode("h1", { class: "text-white font-semibold text-5xl" }, toDisplayString((_f = __props.blogData) == null ? void 0 : _f.title), 1)
                        ])
                      ])
                    ])
                  ]),
                  createVNode(_sfc_main$1, { sectionClass: "top-auto bottom-0" })
                ]),
                createVNode("section", { class: "relative py-20 bg-white" }, [
                  createVNode(_sfc_main$1, { polygonClass: "text-white" }),
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "flex flex-row" }, [
                      createVNode("div", { class: "w-full lg:w-9/12 px-4 ml-auto mr-auto text-stone-900" }, [
                        createVNode("h2", { class: "text-4xl mb-2 font-semibold" }, toDisplayString((_g = __props.blogData) == null ? void 0 : _g.title), 1),
                        createVNode("p", { class: "text-lg mb-2 font-semibold" }, "Date: " + toDisplayString((_h = __props.blogData) == null ? void 0 : _h.created_at), 1),
                        createVNode("hr", { class: "mb-5" }),
                        createVNode(_component_prev, {
                          class: "text-lg text-justify",
                          innerHTML: (_i = __props.blogData) == null ? void 0 : _i.body
                        }, null, 8, ["innerHTML"])
                      ])
                    ])
                  ])
                ])
              ])) : (openBlock(), createBlock("main", {
                key: 1,
                class: "mt-40"
              }, [
                createVNode("div", { class: "container mx-auto px-4" }, [
                  createVNode("div", { class: "items-center justify-center flex flex-wrap" }, [
                    createVNode("div", { class: "w-full ml-auto mr-auto px-4" }, [
                      createVNode("h3", { class: "text-4xl font-semibold" }, "Not Found")
                    ])
                  ])
                ])
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Blog/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
