import { defineComponent, ref, onMounted, mergeProps, unref, withCtx, createVNode, useSSRContext, toDisplayString, openBlock, createBlock, Fragment, renderList, createCommentVNode } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrRenderStyle, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$4 } from "./LayoutGuest-BQseC_Y5.js";
import { usePage, Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./BannerSection-sa6zvZtU.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import { _ as _sfc_main$5 } from "./JobSection--NNnfjnx.js";
import { C as ComingSoon } from "./ComingSoon-DuRr8gR7.js";
import "./ApplicationLogo-DFQaU58l.js";
import "./isSystemUser-D-zJOoLX.js";
import "./FormField-ePZgxXzs.js";
import "./FormControl-DwHkIb1m.js";
import "./main-C5vGb8af.js";
import "pinia";
import "./BaseIcon-C4zrUKd9.js";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Slider",
  __ssrInlineRender: true,
  props: {
    sliderData: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const urls = usePage().props.urls;
    const props = __props;
    const active = ref(0);
    onMounted(() => {
      let i = 0;
      setInterval(() => {
        if (i > props.sliderData.length - 1) {
          i = 0;
        }
        active.value = i;
        i++;
      }, 5e3);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative slide" }, _attrs))} data-v-4f2282e9><div class="carousel-indicators absolute bottom-0 flex bg-stone-800 h-24 w-full justify-center items-center" data-v-4f2282e9><ol class="z-50 flex w-4/12 justify-center" data-v-4f2282e9><!--[-->`);
      ssrRenderList(__props.sliderData, (_, i) => {
        _push(`<li class="${ssrRenderClass([`${active.value === i ? "bg-slate-800 dark:bg-gray-600" : ""}`, "md:w-4 md:h-4 bg-gray-300 rounded-full cursor-pointer mx-2"])}" data-v-4f2282e9></li>`);
      });
      _push(`<!--]--></ol></div><div class="carousel-inner relative overflow-hidden w-full" data-v-4f2282e9><!--[-->`);
      ssrRenderList(__props.sliderData, (slider, i) => {
        _push(`<div class="${ssrRenderClass([{ "active": active.value === i }, "carousel-item inset-0 absolute w-full opacity-0 transition-opacity duration-500 ease-linear"])}" style="${ssrRenderStyle([`background-image: url( ${unref(urls).storeUrl}/${slider.image})`, { "background-position": "center", "background-size": "cover" }])}" data-v-4f2282e9>`);
        _push(ssrRenderComponent(_sfc_main$2, {
          bgImage: slider.image,
          banerHeight: "70vh"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_sfc_main$3, {
                title: slider.title,
                subtitle: slider.subtitle,
                description: slider.description
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_sfc_main$3, {
                  title: slider.title,
                  subtitle: slider.subtitle,
                  description: slider.description
                }, null, 8, ["title", "subtitle", "description"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Frontend/Slider.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Slider = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-4f2282e9"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Home",
  __ssrInlineRender: true,
  props: {
    storageUrl: String
  },
  setup(__props) {
    const homePageData = usePage().props.homePageData ?? null;
    const jobList = usePage().props.jobList ?? null;
    const jobCategories = usePage().props.jobCategories ?? null;
    const companies = usePage().props.companies ?? null;
    const homeConents = {
      slider: [],
      logo: "",
      job_category: "",
      jobs: ""
    };
    if (homePageData) {
      homePageData.contents.forEach((item) => {
        if (item.slug === "slider") {
          item.data.forEach((sliderItem) => {
            homeConents.slider.push(sliderItem);
          });
        }
        if (item.slug === "logo") {
          homeConents.logo = item.data[0];
        }
        if (item.slug === "job_category") {
          homeConents.job_category = item.data[0];
        }
        if (item.slug === "jobs") {
          homeConents.jobs = item.data[0];
        }
      });
    }
    const numbers = ref([]);
    for (let i = 1; i <= 8; i++) {
      numbers.value.push(i);
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$4, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: unref(homePageData).title ?? "Home"
            }, null, _parent2, _scopeId));
            if (unref(homePageData)) {
              _push2(`<main${_scopeId}>`);
              _push2(ssrRenderComponent(Slider, {
                sliderData: homeConents.slider
              }, null, _parent2, _scopeId));
              if (homeConents.logo) {
                _push2(`<section class="relative py-20 bg-gray-100 text-slate-800"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="items-center justify-center flex flex-wrap"${_scopeId}><div class="w-1/2 ml-auto mr-auto px-4"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$3, {
                  title: homeConents.logo.title,
                  description: homeConents.logo.description,
                  subtitle: homeConents.logo.subtitle
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="mt-1 mb-10"${_scopeId}>`);
                if (unref(companies)) {
                  _push2(`<div class="grid grid-cols-4 gap-4"${_scopeId}><!--[-->`);
                  ssrRenderList(unref(companies), (compnay) => {
                    _push2(`<div class="rounded shadow-sm p-2 shadow-slate-300 m-3 flex items-center flex-col bg-white"${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(Link), {
                      href: _ctx.route("job.by.company", compnay.slug)
                    }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(`<img class="mx-auto max-w-40"${ssrRenderAttr("src", compnay.logo)}${ssrRenderAttr("alt", compnay.name)}${_scopeId2}><p class="text-center text-sm font-semibold mt-1"${_scopeId2}>${ssrInterpolate(compnay.name)}</p>`);
                        } else {
                          return [
                            createVNode("img", {
                              class: "mx-auto max-w-40",
                              src: compnay.logo,
                              alt: compnay.name
                            }, null, 8, ["src", "alt"]),
                            createVNode("p", { class: "text-center text-sm font-semibold mt-1" }, toDisplayString(compnay.name), 1)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                    _push2(`</div>`);
                  });
                  _push2(`<!--]--></div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div></div></div></section>`);
              } else {
                _push2(`<!---->`);
              }
              if (homeConents.job_category) {
                _push2(`<section class="relative py-20 bg-slate-800 text-gray-100"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="flex justify-center flex-col items-center"${_scopeId}><div class="w-1/2 ml-auto mr-auto px-4 py-6"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$3, {
                  title: homeConents.job_category.title,
                  description: homeConents.job_category.description,
                  subtitle: homeConents.job_category.subtitle
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="mt-1 mb-10"${_scopeId}><div class="grid grid-cols-5 gap-4"${_scopeId}>`);
                if (unref(jobCategories)) {
                  _push2(`<!--[-->`);
                  ssrRenderList(unref(jobCategories), (category) => {
                    _push2(`<div class="text-center rounded shadow-sm p-2 text-stone-900 bg-white shadow-slate-300 m-3 w-full"${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(Link), {
                      href: _ctx.route("job.by.category", category.slug)
                    }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(`<img class="mx-auto max-w-40"${ssrRenderAttr("src", category.logo)} alt=""${_scopeId2}><p class="text-center text-lg font-semibold mt-3"${_scopeId2}>${ssrInterpolate(category.name)}</p>`);
                        } else {
                          return [
                            createVNode("img", {
                              class: "mx-auto max-w-40",
                              src: category.logo,
                              alt: ""
                            }, null, 8, ["src"]),
                            createVNode("p", { class: "text-center text-lg font-semibold mt-3" }, toDisplayString(category.name), 1)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                    _push2(`</div>`);
                  });
                  _push2(`<!--]-->`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div></div></div></div></section>`);
              } else {
                _push2(`<!---->`);
              }
              if (homeConents.jobs) {
                _push2(`<section class="relative py-20 bg-gray-100 text-slate-800"${_scopeId}><div class="container mx-auto px-4"${_scopeId}><div class="items-center justify-center flex flex-wrap"${_scopeId}><div class="w-1/2 ml-auto mr-auto px-4"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$3, {
                  title: homeConents.jobs.title,
                  description: homeConents.jobs.description,
                  subtitle: homeConents.jobs.subtitle
                }, null, _parent2, _scopeId));
                _push2(`<div class="mt-12"${_scopeId}></div></div>`);
                _push2(ssrRenderComponent(_sfc_main$5, {
                  jobList: unref(jobList),
                  allJobs: unref(jobList)
                }, null, _parent2, _scopeId));
                _push2(`</div></div></section>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</main>`);
            } else {
              _push2(ssrRenderComponent(ComingSoon, null, null, _parent2, _scopeId));
            }
          } else {
            return [
              createVNode(unref(Head), {
                title: unref(homePageData).title ?? "Home"
              }, null, 8, ["title"]),
              unref(homePageData) ? (openBlock(), createBlock("main", { key: 0 }, [
                createVNode(Slider, {
                  sliderData: homeConents.slider
                }, null, 8, ["sliderData"]),
                homeConents.logo ? (openBlock(), createBlock("section", {
                  key: 0,
                  class: "relative py-20 bg-gray-100 text-slate-800"
                }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "items-center justify-center flex flex-wrap" }, [
                      createVNode("div", { class: "w-1/2 ml-auto mr-auto px-4" }, [
                        createVNode(_sfc_main$3, {
                          title: homeConents.logo.title,
                          description: homeConents.logo.description,
                          subtitle: homeConents.logo.subtitle
                        }, null, 8, ["title", "description", "subtitle"])
                      ]),
                      createVNode("div", { class: "mt-1 mb-10" }, [
                        unref(companies) ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "grid grid-cols-4 gap-4"
                        }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(companies), (compnay) => {
                            return openBlock(), createBlock("div", { class: "rounded shadow-sm p-2 shadow-slate-300 m-3 flex items-center flex-col bg-white" }, [
                              createVNode(unref(Link), {
                                href: _ctx.route("job.by.company", compnay.slug)
                              }, {
                                default: withCtx(() => [
                                  createVNode("img", {
                                    class: "mx-auto max-w-40",
                                    src: compnay.logo,
                                    alt: compnay.name
                                  }, null, 8, ["src", "alt"]),
                                  createVNode("p", { class: "text-center text-sm font-semibold mt-1" }, toDisplayString(compnay.name), 1)
                                ]),
                                _: 2
                              }, 1032, ["href"])
                            ]);
                          }), 256))
                        ])) : createCommentVNode("", true)
                      ])
                    ])
                  ])
                ])) : createCommentVNode("", true),
                homeConents.job_category ? (openBlock(), createBlock("section", {
                  key: 1,
                  class: "relative py-20 bg-slate-800 text-gray-100"
                }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "flex justify-center flex-col items-center" }, [
                      createVNode("div", { class: "w-1/2 ml-auto mr-auto px-4 py-6" }, [
                        createVNode(_sfc_main$3, {
                          title: homeConents.job_category.title,
                          description: homeConents.job_category.description,
                          subtitle: homeConents.job_category.subtitle
                        }, null, 8, ["title", "description", "subtitle"])
                      ]),
                      createVNode("div", { class: "mt-1 mb-10" }, [
                        createVNode("div", { class: "grid grid-cols-5 gap-4" }, [
                          unref(jobCategories) ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(jobCategories), (category) => {
                            return openBlock(), createBlock("div", { class: "text-center rounded shadow-sm p-2 text-stone-900 bg-white shadow-slate-300 m-3 w-full" }, [
                              createVNode(unref(Link), {
                                href: _ctx.route("job.by.category", category.slug)
                              }, {
                                default: withCtx(() => [
                                  createVNode("img", {
                                    class: "mx-auto max-w-40",
                                    src: category.logo,
                                    alt: ""
                                  }, null, 8, ["src"]),
                                  createVNode("p", { class: "text-center text-lg font-semibold mt-3" }, toDisplayString(category.name), 1)
                                ]),
                                _: 2
                              }, 1032, ["href"])
                            ]);
                          }), 256)) : createCommentVNode("", true)
                        ])
                      ])
                    ])
                  ])
                ])) : createCommentVNode("", true),
                homeConents.jobs ? (openBlock(), createBlock("section", {
                  key: 2,
                  class: "relative py-20 bg-gray-100 text-slate-800"
                }, [
                  createVNode("div", { class: "container mx-auto px-4" }, [
                    createVNode("div", { class: "items-center justify-center flex flex-wrap" }, [
                      createVNode("div", { class: "w-1/2 ml-auto mr-auto px-4" }, [
                        createVNode(_sfc_main$3, {
                          title: homeConents.jobs.title,
                          description: homeConents.jobs.description,
                          subtitle: homeConents.jobs.subtitle
                        }, null, 8, ["title", "description", "subtitle"]),
                        createVNode("div", { class: "mt-12" })
                      ]),
                      createVNode(_sfc_main$5, {
                        jobList: unref(jobList),
                        allJobs: unref(jobList)
                      }, null, 8, ["jobList", "allJobs"])
                    ])
                  ])
                ])) : createCommentVNode("", true)
              ])) : (openBlock(), createBlock(ComingSoon, { key: 1 }))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Home.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
