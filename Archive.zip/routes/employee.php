<?php 

use App\Http\Controllers\Backend\RoleController;
use App\Http\Controllers\Backend\EmployeeController;


Route::resource('employee', EmployeeController::class);