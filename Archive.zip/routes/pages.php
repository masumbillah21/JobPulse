<?php 

use App\Http\Controllers\Backend\PageController;

Route::resource('pages', PageController::class)->except('show');