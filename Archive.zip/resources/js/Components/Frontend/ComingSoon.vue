<script setup lang='ts'>
</script>

<template>

    <main class="mt-40">
        <div class="container mx-auto px-4">
        <div class="items-center justify-center flex flex-wrap">
            <div class="w-full ml-auto mr-auto px-4 text-center">
                <h3 class="text-4xl font-semibold">Coming Soon</h3>
            </div>
        </div>
        </div>
    </main>

</template>