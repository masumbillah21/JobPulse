<template>
  <div class="text-center py-24 text-gray-500 dark:text-slate-400">
    <p>Nothing's here…</p>
  </div>
</template>
