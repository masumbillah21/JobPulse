export const UserTypeEnum = {
    SYSTEM: 'system',
    COMPANY: 'company',
    CANDIDATE: 'candidate'
};