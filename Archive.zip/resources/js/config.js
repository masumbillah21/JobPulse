export const containerMaxW = 'xl:max-w-screen xl:mx-auto'

